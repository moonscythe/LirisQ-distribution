/* Skin registry. Each package registers itself before app.js starts. */
window.LIRISQ_SKIN_PACKAGES = {};
