/* Copy this folder, rename it, then change SKIN_ID and all asset paths. */
window.LIRISQ_SKIN_PACKAGES.SKIN_ID = {
  name: 'MY SKIN',
  image: 'skins/SKIN_ID/assets/player-background.webp',
  queueImage: 'skins/SKIN_ID/assets/queue-background.webp',
  player: { aspectRatio: '3 / 2', animation: { name: 'none', duration: '0s' } },
  queue: { asset: 'skins/SKIN_ID/assets/queue-background.webp', font: 'My Skin Font' },
  theme: { ink: '#ffffff', muted: '#aab2c5', accent: '#ff3e80', panel: '#121724', line: '#2a3348' },
  fonts: { source: 'local', stylesheet: 'skins/SKIN_ID/fonts.css', families: ['My Skin Font'] },
  positions: {
    show: { x: 50, y: 18 }, song: { x: 50, y: 34 }, artist: { x: 50, y: 47 },
    leftReel: { x: 28, y: 45 }, rightReel: { x: 72, y: 45 },
    vipTitle: { x: 18, y: 22 }, standardTitle: { x: 18, y: 55 }, manualEntry: { x: 50, y: 90 }
  },
  typography: {
    show: { font: 'My Skin Font, sans-serif', size: 18, color: '#ffffff' },
    song: { font: 'My Skin Font, sans-serif', size: 42, color: '#ffffff' },
    artist: { font: 'My Skin Font, sans-serif', size: 22, color: '#aab2c5' },
    vipTitle: { font: 'My Skin Font, sans-serif', size: 28, color: '#ff3e80' },
    standardTitle: { font: 'My Skin Font, sans-serif', size: 28, color: '#ffffff' },
    manualEntry: { font: 'My Skin Font, sans-serif', size: 14, color: '#ffffff' }
  }
};
