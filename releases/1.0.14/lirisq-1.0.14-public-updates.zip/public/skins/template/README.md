# LirisQ custom skin template

## Easy 1–2–3 in the test build

Open **Skin Maker**, choose **Create Basic Skin Pack — Easy 1–2–3**, then:

1. Name the skin and add the Player background. Choose a Google Font and color, then drag the Show, Song, and Artist labels over that Player background.
2. Switch to **Queue** and add the Queue background. Choose its Google Font and color, then drag VIP Queue, Standard Queue, and Manual Entry over that Queue background.
3. Save. The browser-local package is available in **Configuration** as **My Basic Skin Pack**.

The test build stores this starter package locally in the browser. For a distributable installable skin, use the folder package below.

1. Copy `skins/template` to `skins/<your-skin-id>`.
2. Put Player art and Queue art in `assets/` and update `package.template.js` paths.
3. Rename `package.template.js` to `package.js`, replace every `SKIN_ID`, and give the skin a unique name.
4. Use the Skin Maker to refine the placement coordinates and typography.
5. For custom fonts, add the font file under `fonts/` and declare it in `fonts.css`. Google-hosted fonts may instead be listed as an external source in the package manifest.
6. Load the package script after `skins/registry.js` to make the skin available in Configuration and Skin Maker.

The package owns all visual data: Player/Queue assets, palette, font source, typography, positions, and animation metadata. It must never alter queue state or MGB playback behavior.
