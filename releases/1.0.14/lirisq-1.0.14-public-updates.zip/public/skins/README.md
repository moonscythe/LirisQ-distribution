# LirisQ skin packages

Each subdirectory is a self-contained visual skin package:

- `package.js` registers its name, independent semantic `version`, Player and Queue assets, Store preview assets (`previews.player` and `previews.queue`), optional Store preview layers (`previews.playerLayers`) for composited skins, complete palette (`theme`), typography for each text field (font, pixel size, color), animation contract, aspect ratio, and default placement map (`positions`).
- `assets/` holds only that package's artwork and animation overlays.
- `defaults.json` is package-owned placement and typography data. It is the source of truth for user-saved Player and Queue defaults, and must travel with the package.

`registry.js` deliberately contains no skin design data. It creates the registry used by the package files that follow it. Add a skin by creating a new folder with this same contract, then loading its `package.js` after `registry.js`.

Fonts may use `source: 'google'` with a documented external stylesheet, or `source: 'local'` with `fonts.css` and font files in the package. Custom or licensed fonts must use the local form.

Start a creator-owned package from `skins/template/`.

The bundled `vhs/` package supplies a Player VHS-spine-label surface and a separate CRT Queue surface. Its Google-font stylesheet and all artwork are owned by that package.

Installable bundles live under `skins/packs/`. A pack manifest declares a version and the complete skin entrypoints it installs. `lirisq-original-pack-01` is the first bundled example.

Skin package versions and bundle versions are intentionally independent. Increment a skin version for a skin-only change; increment its bundle version only when the shipped bundle contents or bundle metadata changes. When running the test server, Skin Maker writes an edited pack's `defaults.json`; direct file-mode users can export the same sidecar and replace it in the package before moving it.
