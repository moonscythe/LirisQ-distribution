window.LIRISQ_SKIN_PACKAGES.vhs = {
  name: 'VHS / CRT NIGHT', version: '1.0.4',
  assets: {
    playerBackground: 'skins/vhs/assets/vhs-player.webp',
    queueBackground: 'skins/vhs/assets/vhs-crt-queue.webp'
  },
  previews: { player: 'skins/vhs/assets/vhs-player.webp', queue: 'skins/vhs/assets/vhs-crt-queue.webp' },
  player: { aspectRatio: '3 / 2', animation: { name: 'vhs-tracking', duration: '3.6s' } },
  queue: { asset: 'skins/vhs/assets/vhs-crt-queue.webp', font: 'VT323' },
  theme: { ink: '#c9f7ff', muted: '#78b9c7', accent: '#ff7a9b', panel: '#061015', line: '#236775', cardBackground: '#071217' },
  editor: { ink: '#d8fbff', labelBackground: '#031519cf', grid: '#51d9ee66', outline: '#83f3ff' },
  fonts: { source: 'google', stylesheet: 'skins/vhs/fonts.css', families: ['Pacifico', 'VT323'] },
  positions: {
    show: { x: 49, y: 43 }, song: { x: 49, y: 47 }, artist: { x: 49, y: 53 },
    leftReel: { x: 28, y: 45 }, rightReel: { x: 72, y: 45 },
    vipTitle: { x: 12, y: 18 }, standardTitle: { x: 12, y: 54 }, manualEntry: { x: 50, y: 89 }
  },
  defaults: { positions: {
    show: { x: 49, y: 43 }, song: { x: 49, y: 47 }, artist: { x: 49, y: 53 },
    leftReel: { x: 28, y: 45 }, rightReel: { x: 72, y: 45 },
    vipTitle: { x: 12, y: 18 }, standardTitle: { x: 12, y: 54 }, manualEntry: { x: 50, y: 89 }
  } },
  typography: {
    show: { font: "Pacifico, cursive", size: 13, color: '#4a2214', shadow: '0 1px 0 #f1c991' },
    song: { font: "Pacifico, cursive", size: 29, color: '#25150e', shadow: '0 1px 0 #f1c991' },
    artist: { font: "Pacifico, cursive", size: 16, color: '#4a2214', shadow: '0 1px 0 #f1c991' },
    vipTitle: { font: "VT323, monospace", size: 32, color: '#ff8fa7' },
    standardTitle: { font: "VT323, monospace", size: 32, color: '#bff6ff' },
    manualEntry: { font: "VT323, monospace", size: 20, color: '#bff6ff' }
  }
};
