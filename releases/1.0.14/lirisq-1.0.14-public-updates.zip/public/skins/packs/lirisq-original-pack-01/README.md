# LirisQ Original Skin Pack #1

Version 1.2.2 · First-party pack

Includes the Cassette, Record, Jukebox, and VHS skins. Each included skin remains independently editable in Skin Maker, but the pack is installed and versioned as one unit. Every skin includes its own `defaults.json` with its default layout and typography.

`package.js` is the install manifest. A future downloadable pack follows this same contract: a pack manifest lists its skin entrypoints, then Configuration installs the full pack and records its version locally.
