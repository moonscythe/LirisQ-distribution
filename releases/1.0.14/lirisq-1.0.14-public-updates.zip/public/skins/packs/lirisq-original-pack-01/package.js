/* First-party, installable bundle of complete LirisQ visual skins. */
window.LIRISQ_SKIN_PACKS ||= {};
window.LIRISQ_SKIN_PACKS['lirisq-original-pack-01'] = {
  id: 'lirisq-original-pack-01',
  name: 'LIRISQ ORIGINAL SKIN PACK #1',
  version: '1.2.5',
  publisher: 'LirisQ',
  thumbnail: 'skins/cassette/assets/cassette-skin.webp',
  skins: ['cassette', 'record', 'jukebox', 'vhs'],
  install: { type: 'bundled', entrypoints: ['skins/cassette/package.js', 'skins/record/package.js', 'skins/jukebox/package.js', 'skins/vhs/package.js'] }
};
