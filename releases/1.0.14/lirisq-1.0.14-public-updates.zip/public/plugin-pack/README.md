# LirisQ Plugin Pack

This pack documents the optional plugins implemented in LirisQ. Machine-readable metadata is in [manifest.json](manifest.json). Plugins are loaded as trusted local JavaScript modules and enabled explicitly in LirisQ.

## X Show Announcer (v1.0.0)

Creates editable X announcements from saved shows. Includes recurring show occurrence selection, no-show exclusions, reusable links, announcement presets, browser-local template and time-zone settings, a character counter, viewer-local time conversion links, and a user-confirmed X composer. **LirisQ does not automatically publish to X** and does not request X credentials. Publishing requires the user to review and post on X. Time-zone selection must match the saved show's intended local time.

Entry: `examples/x-show-announcer/plugin.js`. Permission scope: none. Settings are browser-local.

## Show Calendar Export (v1.0.0)

Creates portable iCalendar `.ics` downloads for a show or up to 12 upcoming occurrences. Handles weekly, biweekly, monthly and one-time schedules, excludes no-show dates, converts selected local show times to UTC event instants, and includes configurable event duration and reminders. It does not access external calendar accounts or synchronize events automatically.

Entry: `examples/show-calendar-export/plugin.js`. Permission scope: none. Downloaded files are imported by the user into their calendar app.

## Stream Notifications (v1.0.0)

The single browser-local source of notification drafts and delivery state for LirisQ. Watches saved show schedule changes, removed shows, song request additions and queue promotions. Creates configurable pre-show reminders using Calendar Export's time-zone conversion, and supports custom manual announcements.

The Notifications page includes opt-in automatic reminder **draft preparation** every minute while the tab is open, adjustable reminder offsets, an upcoming reminder preview, time-zone settings, per-event enable/disable controls, manual draft creation, outbox status filters, JSON history export, and explicit history clearing. The outbox supports approve/cancel, copying, X manual composer handoff, and confirmed manual delivery marking.

**Discord connector:** An approved draft can be explicitly sent via the existing Discord Integration plugin and server-configured webhook. Failures remain in the outbox for deliberate retry. If the browser is interrupted while sending, an in-progress item is marked failed when the plugin next starts; verify whether Discord received it before retrying.

**Delivery policy:** No automatic external publishing. The in-tab scheduler only creates drafts, not posts. A closed browser cannot prepare reminders; no server-side or push scheduler is provided. Discord, X, verified go-live status and individual viewer messaging have separate authentication/delivery requirements.

Entry: `examples/stream-notifications/plugin.js`. Permission scope: none. Preferences, draft history and delivery state are stored in the current browser; exported JSON is for user records and is not an import/synchronization mechanism.

## Bot Core, Chatbot, and integration suite

All Bot Core, Chatbot, platform-adapter, bot-feature, and system-integration modules are opt-in plugins managed through **Configuration → Chat Bot**. The general Plugin Manager likewise exposes every bundled plugin. Bot Core is a single event coordinator; adapters are separate modules, not separate bot identities. Enabling an adapter does not authenticate or establish a platform connection.

| Plugin | Scope | Live connection |
|---|---|---|
| Bot Core | Central opt-in local event bus and hook registry; no network service. | Not configured |
| Twitch Live Adapter | Normalized Twitch events and offline replay; signed local EventSub intake is available. | **DEV** — needs public HTTPS callback, authorization, subscriptions, and outbound chat |
| YouTube Live Adapter | Normalized YouTube Live events and offline replay. | Live transport not configured |
| TikTok LIVE Adapter | Normalized TikTok LIVE events and offline replay. | Live transport not configured |
| Douyin LIVE Adapter | Normalized Douyin LIVE events and offline replay. | Live transport not configured |
| Bilibili LIVE Adapter | Normalized Bilibili LIVE events and offline replay. | Live transport not configured |
| Kick Live Adapter | Normalized Kick events and offline replay. | Live transport not configured |
| X Live Adapter | Normalized X events and offline replay. | Live transport not configured |
| Discord Platform Plugin | One Discord installation for webhook announcements and approved delivery. | **DEV** — server-configured webhook; no Discord bot OAuth/chat transport |
| Stream Status Monitor | Combines incoming Twitch and YouTube live/offline signals from enabled adapters. | Not configured |
| Stream Notifications Bot Hook | Exposes approved notification drafts to Bot Core without publishing them. | Not configured |
| Viewer Notification Preferences | Browser-local opt-in channel preferences; remote subscriptions and delivery pending. | Not configured |
| Notification Health Monitor | Read-only snapshot of bot and notification delivery errors. | Not configured |
| OBS Integration | OBS scene event contract; obs-websocket transport pending. | Not configured |

**Operational boundaries:** Twitch OAuth/EventSub, YouTube OAuth/live-chat polling, and OBS WebSocket are not yet implemented. Stream Status Monitor can only consume events once a connected platform adapter supplies them. Viewer preferences are local only and do not send viewer messages. Bot Core does not auto-post; existing Stream Notifications approvals remain authoritative. Browser behavior and external services remain unverified.

## Verification status

Browser behavior, external X composer behavior, time-zone edge cases and calendar-client compatibility remain **not tested**. MGB broker pairing is implemented, while its live trusted-session handoff remains incomplete.


## Platform adapter layer (v0.2.0)

The seven platform adapters are now represented as offline-capable normalized adapters: Twitch, YouTube Live, TikTok LIVE, Douyin LIVE, Bilibili LIVE, Kick, and X. They validate bounded events, deduplicate by platform plus external event ID, and replay fixtures deterministically. They do not claim live authentication or automatically publish. See [docs/PLATFORM-ADAPTERS.md](../docs/PLATFORM-ADAPTERS.md).

Bot Core includes the shared platform-chat router. It receives normalized chat and queue-request events, preserves streamer approval and queue limits, and returns platform-aware responses without creating separate bots.
