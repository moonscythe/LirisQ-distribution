# LirisQ PHP installer

1. Upload and extract this folder. Set your PHP host's website web directory to its **public** folder.
2. Rename **public/install.php.example** to **public/install.php** only when
   you are ready to perform the one-time setup, then open **/install.php**.
3. Enter the database values and HTTPS URL. After success, delete **install.php**.

The current deployment serves LirisQ's browser app and checks the PHP/MySQL companion requirements. Browser state remains local until the hosted-workspace migration is complete.
