<?php
declare(strict_types=1);

// PHP2Shell fixes: CVE-2026-109618 and CVE-2026-109619.
function lirisq_require_secure_php(): void {
    $fixed = (PHP_MAJOR_VERSION === 8) && (
        (PHP_MINOR_VERSION === 2 && version_compare(PHP_VERSION, '8.2.35', '>=')) ||
        (PHP_MINOR_VERSION === 3 && version_compare(PHP_VERSION, '8.3.36', '>=')) ||
        (PHP_MINOR_VERSION === 4 && version_compare(PHP_VERSION, '8.4.27', '>=')) ||
        (PHP_MINOR_VERSION === 5 && version_compare(PHP_VERSION, '8.5.12', '>='))
    );
    if ($fixed) return;
    http_response_code(503);
    header('content-type: application/json; charset=utf-8');
    header('cache-control: no-store');
    exit(json_encode(['error' => 'LirisQ requires a PHP release patched for CVE-2026-109618 and CVE-2026-109619. Update PHP with your host before enabling this endpoint.']));
}
