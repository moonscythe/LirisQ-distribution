# Twitch OAuth on a DreamHost LirisQ installation

1. Sign in at the [Twitch Developer Console](https://dev.twitch.tv/console/apps)
   with the broadcaster’s Twitch account and select **Register Your Application**.
   Give it a clear name such as `LirisQ`, select **Website Integration**, and set
   **Client Type** to **Confidential**. LirisQ’s PHP companion retains the client
   secret privately on your server; do not use Public for this installation.

2. Add this exact OAuth redirect URL in the application registration, replacing
   the example domain with the public HTTPS address where LirisQ is installed:

   `https://your-domain.example/twitch/twitch.php?action=callback`

   Save the application, then open it and copy its **Client ID** and generate/copy
   its **Client Secret**. Keep both private.

3. Copy `private/lirisq-twitch-config.php.example` to
   `private/lirisq-twitch-config.php`. Enter the Client ID, Client Secret, that
   exact redirect URL, the EventSub callback URL below, and a random 32+
   character EventSub secret.

   `https://your-domain.example/twitch/twitch.php?action=eventsub`

4. In DreamHost phpMyAdmin, import the package-root `schema.sql` into the same
   LirisQ database. It uses `CREATE TABLE IF NOT EXISTS`, so it safely adds the
   Twitch tables without deleting existing LirisQ data. Do not rerun the generic
   installer solely to add Twitch.

5. In LirisQ, open **Configuration → Main**, designate the streamer profile,
   open **Twitch Plugin Configuration**, and select **Connect Twitch**. Twitch
   will show its authorization screen and return to LirisQ when approved.

6. Select **Activate EventSub** after the connection succeeds. Twitch must be
   able to reach the public HTTPS callback URL above.

7. To send chatbot replies from a separate account, first remain signed in to
   LirisQ as the streamer. In **Twitch Plugin Configuration**, select
   **Connect Twitch Bot**, then sign in to and approve the separate bot account
   on Twitch. Back in your Twitch channel, run `/mod BOT_ACCOUNT_NAME`. LirisQ
   keeps the bot token encrypted on the server and continues to use the
   broadcaster identity for EventSub.

Never put the Client Secret or EventSub secret in browser settings, source
control, or `public/`.
