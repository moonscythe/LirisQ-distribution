CREATE TABLE IF NOT EXISTS lirisq_workspace (
  workspace_id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  revision BIGINT UNSIGNED NOT NULL DEFAULT 0,
  state_json MEDIUMTEXT NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lirisq_administrator (
  singleton TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  password_hash VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lirisq_twitch_authorization (
  singleton TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  broadcaster_user_id VARCHAR(64) NOT NULL,
  broadcaster_login VARCHAR(64) NOT NULL,
  scopes_json TEXT NOT NULL,
  token_nonce BINARY(12) NOT NULL,
  token_tag BINARY(16) NOT NULL,
  token_ciphertext MEDIUMBLOB NOT NULL,
  expires_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Exactly one Twitch identity owns the hosted LirisQ installation. This is
-- separate from EventSub tokens so visitors cannot become administrators.
CREATE TABLE IF NOT EXISTS lirisq_server_owner (
  singleton TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  twitch_user_id VARCHAR(64) NOT NULL,
  twitch_login VARCHAR(100) NOT NULL,
  claimed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Twitch identities allowed to read the protected development update channel.
CREATE TABLE IF NOT EXISTS lirisq_development_update_collaborator (
  twitch_user_id VARCHAR(64) NOT NULL PRIMARY KEY,
  twitch_login VARCHAR(100) NOT NULL,
  granted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lirisq_release_installation (
  singleton TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  version VARCHAR(32) NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lirisq_release_migration (
  migration_id VARCHAR(160) NOT NULL PRIMARY KEY,
  release_version VARCHAR(32) NOT NULL,
  applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lirisq_twitch_eventsub (
  subscription_id VARCHAR(80) NOT NULL PRIMARY KEY,
  subscription_type VARCHAR(100) NOT NULL,
  status VARCHAR(80) NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lirisq_twitch_events (
  sequence BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  message_id VARCHAR(128) NOT NULL UNIQUE,
  subscription_type VARCHAR(100) NOT NULL,
  payload_json MEDIUMTEXT NOT NULL,
  received_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (sequence)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Viewer data is keyed to the verified Twitch identity, never to a browser
-- supplied display name.  Artists and request activity are deleted together
-- when the viewer deletes their profile.
CREATE TABLE IF NOT EXISTS lirisq_viewer_artist (
  twitch_user_id VARCHAR(64) NOT NULL,
  artist_name VARCHAR(160) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (twitch_user_id, artist_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lirisq_viewer_song_activity (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  twitch_user_id VARCHAR(64) NOT NULL,
  song_title VARCHAR(300) NOT NULL,
  artist_name VARCHAR(160) NOT NULL,
  song_url VARCHAR(1000) NOT NULL,
  activity ENUM('submitted','played') NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (twitch_user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
