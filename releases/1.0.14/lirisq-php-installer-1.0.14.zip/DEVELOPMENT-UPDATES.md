# Private development updates

LirisQ production releases stay on the public `LirisQ-distribution` channel.
Development manifests and ZIPs are kept outside the public web root and are
served only after a Twitch-backed LirisQ streamer or collaborator session.

## Server deployment

Upload `public/updates/development.php` and the paired `public/twitch/` files
with the normal PHP package. Keep the
development files outside the web root:

```text
private/development-updates/manifest.json
private/development-updates/artifacts/<development-package>.zip
```

Set a development build's update source to:

```text
https://your-lirisq-host.example/updates/channel.php?channel=development
```

An unauthenticated browser receives `403`; no GitHub token is stored or sent to
the browser.

## Collaborators

The streamer owner always has access. To grant a collaborator after they have
used **Connect Twitch** once, insert their Twitch numeric user ID and login in
the LirisQ MySQL database:

```sql
INSERT INTO lirisq_development_update_collaborator (twitch_user_id, twitch_login)
VALUES ('TWITCH_NUMERIC_USER_ID', 'twitch_login');
```

To revoke access:

```sql
DELETE FROM lirisq_development_update_collaborator
WHERE twitch_user_id = 'TWITCH_NUMERIC_USER_ID';
```

`LirisQ-distribution-dev` can remain private and be used as the publishing
source. A CI publisher or manual secure upload copies only reviewed ZIPs and
their manifest to this private server directory. Never copy GitHub tokens,
source code, private configuration, or database data to a public distribution
repository.

## Channels

Development and Beta use separate private directories but the same verification
and authorization policy:

```text
private/development-updates/
private/beta-updates/
```

Use `channel=beta` only after a reviewed beta manifest and artifacts have been
published. Public releases continue to use the public distribution repository.
