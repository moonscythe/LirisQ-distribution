# LirisQ PHP installation on DreamHost

This guide installs the LirisQ PHP package on a DreamHost **Custom Setup**
website. It does not install Node.js or use DreamHost's WordPress installer.

## Before you start

- A DreamHost website configured for **Custom Setup**.
- A domain with HTTPS enabled.
- A new MySQL database and database user.
- The `lirisq-php-installer-<version>.zip` package.

Choose PHP 8.5 in DreamHost Website Settings. The LirisQ installer checks that
the installed PHP patch level is secure and that `pdo_mysql`, `openssl`, `curl`,
and `json` are available. Do not continue if its server-check screen reports a
failure.

## 1. Configure the website

In DreamHost, open **Manage Websites**, add or manage the domain, and select
**Custom Setup**. Under **Advanced Settings**, choose a web directory such as:

```text
example.com/lirisq/public
```

The directory must exist before DreamHost can use it. If the website already
exists, use **Manage → Settings → Directories** to change its Web directory.

## 2. Create the database

Open **More → MySQL Databases**, create a new database, and create a new user
for that database. Keep the following values available for the installer:

- MySQL hostname
- Database name
- Database username
- Database password

Use the MySQL hostname shown in DreamHost's panel, not the public website
domain. Do not reuse a database user from another application.

## 3. Upload the package

Extract the LirisQ ZIP and upload its contents so the web directory from step 1
is the extracted `public` folder:

```text
example.com/lirisq/
├── private/
├── public/          ← DreamHost web directory
│   ├── index.html
│   └── install.php.example
├── runtime-guard.php
├── README.md
└── DREAMHOST.md
```

`private/` and `runtime-guard.php` must remain outside `public/`.

## 4. Enable and run the one-time installer

The installer is deliberately inactive after extraction. In `public/`, rename
`install.php.example` to `install.php`. Do this only when you are ready to set
up the site; normal updates never include or modify `install.php`.

Open:

```text
https://your-domain.example/install.php
```

After every server check is green, enter the MySQL hostname, database name,
database user, database password, and the exact public HTTPS origin, such as:

```text
https://lirisq.example.com
```

Select **Verify and install**. It creates the LirisQ database tables and writes
its private configuration under `private/`.

## 5. Finish safely

After the installer says **Installed**, delete `public/install.php`.
Then open the normal LirisQ URL. Never leave the installer available publicly.

## Live show links

After signing in as the streamer, select a show and choose **Start Active Show
Live**. LirisQ then publishes two stable, viewer-safe links:

```text
https://your-domain.example/live
https://your-domain.example/live/queue
```

The first shows the active show; the second shows its current queue. Both show
**No Show** until the streamer starts a show. The database record is created
automatically by the Twitch PHP companion, so this feature needs no separate
SQL import after a normal LirisQ PHP installation.

## DreamHost references

- [Add a website with Custom Setup](https://help.dreamhost.com/hc/en-us/articles/360049378932-Adding-a-website-and-hosting)
- [Change a website web directory](https://help.dreamhost.com/hc/en-us/articles/360041534491-Changing-the-web-directory-assigned-to-a-domain)
- [Create a MySQL database](https://help.dreamhost.com/hc/en-us/articles/221691727-Creating-a-MySQL-database)
- [DreamHost PHP versions](https://help.dreamhost.com/hc/en-us/articles/215082337-What-versions-of-PHP-are-available-at-DreamHost)
