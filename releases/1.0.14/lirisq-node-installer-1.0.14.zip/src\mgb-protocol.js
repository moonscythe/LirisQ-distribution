/* Versioned LirisQ <-> MGB playback message contract.
   Transport-agnostic. Authentication and origin checks belong to the bridge.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQMGBProtocol = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const SCHEMA = 'lirisq.mgb-event/v1';
  const EVENTS = new Set(['playback.started', 'playback.finished', 'playback.paused', 'playback.resumed']);
  const ID = /^[a-zA-Z0-9._:-]{1,128}$/;
  function parse(input) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Message must be an object');
    if (input.schema !== SCHEMA || input.kind !== 'event' || !EVENTS.has(input.event)) throw new Error('Unsupported MGB event');
    if (typeof input.messageId !== 'string' || !ID.test(input.messageId)) throw new Error('Invalid message ID');
    if (typeof input.sessionId !== 'string' || !ID.test(input.sessionId)) throw new Error('Invalid session ID');
    if (typeof input.sentAt !== 'number' || !Number.isFinite(input.sentAt) || input.sentAt <= 0) throw new Error('Invalid timestamp');
    if (input.payload === null || typeof input.payload !== 'object' || Array.isArray(input.payload)) throw new Error('Invalid payload');
    if (input.event === 'playback.started' || input.event === 'playback.finished') {
      if (input.payload.songId != null && (typeof input.payload.songId !== 'string' || !ID.test(input.payload.songId))) throw new Error('Invalid song ID');
      if (typeof input.payload.title !== 'string' || input.payload.title.length > 300) throw new Error('Invalid song title');
      if (typeof input.payload.artist !== 'string' || input.payload.artist.length > 300) throw new Error('Invalid artist');
    }
    return Object.freeze({ ...input, payload: Object.freeze({ ...input.payload }) });
  }
  function event(event, payload, { sessionId, messageId, now = Date.now() }) {
    return parse({ schema: SCHEMA, kind: 'event', event, payload, sessionId, messageId, sentAt: now });
  }
  return Object.freeze({ SCHEMA, parse, event });
});
