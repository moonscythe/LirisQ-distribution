import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import path from 'node:path';
import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';

const schemaVersion = 1;
const maximumSnapshotBytes = 2 * 1024 * 1024;

// A single streamer-owned deployment has one workspace. SQLite keeps that
// workspace private to the LirisQ data volume without requiring a database
// service or any database administration.
export function openWorkspaceStore(dataDirectory) {
  mkdirSync(dataDirectory, { recursive: true, mode: 0o700 });
  const file = path.join(dataDirectory, 'lirisq.sqlite');
  const database = new DatabaseSync(file);
  database.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  database.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      applied_at INTEGER NOT NULL
    ) STRICT;
    CREATE TABLE IF NOT EXISTS workspace_snapshots (
      workspace_id TEXT PRIMARY KEY NOT NULL,
      revision INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      state_json TEXT NOT NULL
    ) STRICT;
    CREATE TABLE IF NOT EXISTS administrator (
      id INTEGER PRIMARY KEY CHECK (id = 1), salt TEXT NOT NULL, password_hash TEXT NOT NULL, created_at INTEGER NOT NULL
    ) STRICT;
    CREATE TABLE IF NOT EXISTS administrator_sessions (
      token_hash TEXT PRIMARY KEY NOT NULL, csrf_token TEXT NOT NULL, expires_at INTEGER NOT NULL
    ) STRICT;
  `);
  database.prepare('INSERT OR IGNORE INTO schema_migrations (version, applied_at) VALUES (?, ?)').run(schemaVersion, Date.now());

  const read = database.prepare('SELECT revision, updated_at AS updatedAt, state_json AS stateJson FROM workspace_snapshots WHERE workspace_id = ?');
  const write = database.prepare(`
    INSERT INTO workspace_snapshots (workspace_id, revision, updated_at, state_json)
    VALUES (?, 1, ?, ?)
    ON CONFLICT(workspace_id) DO UPDATE SET
      revision = workspace_snapshots.revision + 1,
      updated_at = excluded.updated_at,
      state_json = excluded.state_json
  `);
  const admin = database.prepare('SELECT salt, password_hash AS passwordHash FROM administrator WHERE id = 1');
  const session = database.prepare('SELECT csrf_token AS csrfToken FROM administrator_sessions WHERE token_hash = ? AND expires_at > ?');

  return Object.freeze({
    file,
    schemaVersion,
    status() {
      return { engine: 'sqlite', schemaVersion, file: path.basename(file) };
    },
    read(workspaceId = 'default') {
      const row = read.get(workspaceId);
      if (!row) return null;
      try { return { revision: row.revision, updatedAt: row.updatedAt, state: JSON.parse(row.stateJson) }; }
      catch { throw new Error('Saved workspace data is invalid'); }
    },
    write(workspaceId = 'default', state) {
      const stateJson = JSON.stringify(state);
      if (!stateJson || Buffer.byteLength(stateJson, 'utf8') > maximumSnapshotBytes) throw new Error('Workspace snapshot is too large');
      write.run(workspaceId, Date.now(), stateJson);
      return this.read(workspaceId);
    },
    administratorReady() { return Boolean(admin.get()); },
    bootstrapAdministrator(password) {
      if (this.administratorReady()) throw new Error('Administrator is already configured');
      if (typeof password !== 'string' || password.length < 12 || password.length > 256) throw new Error('Administrator password must be 12–256 characters');
      const salt = randomBytes(16).toString('base64url'); const passwordHash = scryptSync(password, salt, 32).toString('base64url');
      database.prepare('INSERT INTO administrator (id, salt, password_hash, created_at) VALUES (1, ?, ?, ?)').run(salt, passwordHash, Date.now());
    },
    createAdministratorSession(password) {
      const record = admin.get(); if (!record) throw new Error('Administrator is not configured');
      const expected = Buffer.from(record.passwordHash, 'base64url'); const supplied = scryptSync(password, record.salt, 32);
      if (expected.length !== supplied.length || !timingSafeEqual(expected, supplied)) throw new Error('Invalid administrator credentials');
      const token = randomBytes(32).toString('base64url'); const csrfToken = randomBytes(24).toString('base64url'); const expiresAt = Date.now() + 12 * 60 * 60 * 1000;
      database.prepare('DELETE FROM administrator_sessions WHERE expires_at <= ?').run(Date.now());
      database.prepare('INSERT INTO administrator_sessions (token_hash, csrf_token, expires_at) VALUES (?, ?, ?)').run(scryptSync(token, 'lirisq-admin-session', 32).toString('base64url'), csrfToken, expiresAt);
      return { token, csrfToken, expiresAt };
    },
    administratorSession(token) { return token ? session.get(scryptSync(token, 'lirisq-admin-session', 32).toString('base64url'), Date.now()) || null : null; },
    close() { database.close(); }
  });
}
