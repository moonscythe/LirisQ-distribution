(function (root) {
  'use strict';
  let active = null;
  root.LirisQMGBSessions = Object.freeze({
    status() { return { connected: Boolean(active), sessionId: active ? active.sessionId : null }; },
    async connectTrusted(options) {
      if (active) throw new Error('MGB session already active');
      if (!options || !options.pluginHost || typeof options.pluginHost.emit !== 'function') throw new Error('Trusted plugin host required');
      if (options.modelImprovementOptIn !== true) throw new Error('Streamer model-improvement opt-in is required');
      let session;
      const connector = await root.LirisQMGBConnector.connect({ ...options, onDisconnect: error => {
        session?.close();
        options.onDisconnect?.(error);
      } });
      session = { sessionId: options.sessionId, close() {
        if (active === session) active = null;
        connector.close();
      } };
      active = session;
      return session;
    },
    disconnect() { if (!active) return false; active.close(); return true; }
  });
})(globalThis);
