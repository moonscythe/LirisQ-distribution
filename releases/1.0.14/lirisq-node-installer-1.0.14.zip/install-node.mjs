#!/usr/bin/env node
import { chmod, mkdir, readFile, writeFile } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const configPath = path.join(root, 'lirisq.config.json');
const version = (await readFile(path.join(root, 'VERSION'), 'utf8')).trim();
const major = Number(process.versions.node.split('.')[0]);
if (!Number.isInteger(major) || major < 22) throw new Error('LirisQ requires Node.js 22 or newer. Install Node 22+ and run this installer again.');
let configuration = {};
try { configuration = JSON.parse(await readFile(configPath, 'utf8')); } catch (error) { if (error.code !== 'ENOENT') throw new Error('Existing lirisq.config.json is not valid JSON. Fix it before upgrading.'); }
const dataDirectory = path.resolve(String(configuration.dataDirectory || process.env.LIRISQ_DATA_DIR || '.lirisq-data'));
await mkdir(dataDirectory, { recursive:true });
const next = {
  ...configuration,
  schema: 'lirisq-node-config/v1',
  releaseVersion: version,
  dataDirectory,
  tokenEncryptionKey: configuration.tokenEncryptionKey || process.env.LIRISQ_TOKEN_ENCRYPTION_KEY || randomBytes(32).toString('hex')
};
await writeFile(configPath, `${JSON.stringify(next, null, 2)}\n`, { mode:0o600 });
try { await chmod(configPath, 0o600); } catch (_) { /* Windows does not expose POSIX file modes. */ }
console.log(`LirisQ ${version} is installed. Configuration and data were ${Object.keys(configuration).length ? 'preserved' : 'created'}.`);
console.log('Start LirisQ with: node start.mjs');
