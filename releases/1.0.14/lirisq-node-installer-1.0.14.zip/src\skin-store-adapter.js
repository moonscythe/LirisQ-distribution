/* Non-destructive adapter for existing Skin Maker exports.
   Legacy drafts have no verified artifact and must never be installable. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQSkinStoreAdapter = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const idPattern = /^[a-z0-9][a-z0-9._-]{2,127}$/;
  const versionPattern = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/;
  function fromLegacyDraft(input, options = {}) {
    if (!input || input.schema !== 'mgbstore-skin-manifest/v1' || !input.package || typeof input.package !== 'object') throw new Error('Expected legacy Skin Maker export');
    const pkg = input.package;
    if (typeof pkg.name !== 'string' || !pkg.name.trim()) throw new Error('Skin name required');
    const version = pkg.version || '0.1.0';
    if (!versionPattern.test(version)) throw new Error('Invalid skin version');
    const publisherId = options.publisherId;
    if (typeof publisherId !== 'string' || !idPattern.test(publisherId)) throw new Error('Publisher ID required');
    const slug = pkg.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0,80);
    const id = options.id || (publisherId + '.' + slug);
    if (!idPattern.test(id)) throw new Error('Invalid skin ID');
    const price = Number(pkg.store?.price || 0);
    if (!Number.isFinite(price) || price < 0) throw new Error('Invalid skin price');
    return {
      status: 'draft', installable: false,
      catalogDraft: {
        schema: 'lirisq-extension/v1', id, type: 'skin', host: 'lirisq',
        name: pkg.name.trim(), version, publisherId, apiVersion: options.apiVersion || '1.0.0',
        priceModel: price > 0 ? 'paid-draft' : 'free'
      },
      legacyManifest: input,
      missing: ['packaged artifact', 'HTTPS artifact URL', 'SHA-256 digest', 'trusted publisher verification']
    };
  }
  function attachVerifiedArtifact(draft, artifact, validator) {
    if (!draft || draft.status !== 'draft' || !draft.catalogDraft) throw new Error('Expected adapted draft');
    if (draft.catalogDraft.priceModel !== 'free') throw new Error('Paid publication not yet supported');
    if (typeof validator !== 'function') throw new Error('Manifest validator required');
    return validator({ ...draft.catalogDraft, artifact });
  }
  return Object.freeze({ fromLegacyDraft, attachVerifiedArtifact });
});
