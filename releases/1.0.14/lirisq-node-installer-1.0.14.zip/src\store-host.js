/* Browser host adapter: verified Store packages are staged, not activated.
   IndexedDB stores artifact bytes; no localStorage ID is treated as proof of install. */
(function (root, factory) {
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQStoreHost = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (root) {
  'use strict';
  function createIndexedDbStorage(indexedDBApi = root.indexedDB) {
    if (!indexedDBApi) throw new Error('IndexedDB unavailable');
    function open() {
      return new Promise((resolve, reject) => {
        const req = indexedDBApi.open('lirisq-verified-extensions-v1', 1);
        req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains('extensions')) req.result.createObjectStore('extensions'); };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    }
    async function operation(mode, callback) {
      const db = await open();
      try {
        return await new Promise((resolve, reject) => {
          const tx = db.transaction('extensions', mode);
          const store = tx.objectStore('extensions');
          let value;
          let req;
          try { req = callback(store); } catch (err) { reject(err); return; }
          if (req) {
            req.onsuccess = () => { value = req.result; };
            req.onerror = () => reject(req.error);
          }
          tx.oncomplete = () => resolve(value);
          tx.onerror = () => reject(tx.error);
          tx.onabort = () => reject(tx.error || new Error('Storage transaction aborted'));
        });
      } finally { db.close(); }
    }
    return {
      get: key => operation('readonly', store => store.get(key)),
      put: (key, value) => operation('readwrite', store => store.put(value, key)),
      remove: key => operation('readwrite', store => store.delete(key)),
      keys: async prefix => (await operation('readonly', store => store.getAllKeys())).filter(key => typeof key === 'string' && key.startsWith(prefix))
    };
  }
  function createStoreHost({ catalog, installerModule, storage, fetchImpl = root.fetch, approve, trustPublisher, crypto = root.crypto }) {
    if (!catalog || !installerModule) throw new Error('Store catalog and installer module required');
    if (typeof fetchImpl !== 'function' || typeof approve !== 'function' || typeof trustPublisher !== 'function') throw new Error('Explicit fetch, approval and trust callbacks required');
    const installer = installerModule.createInstaller({
      storage: storage || createIndexedDbStorage(),
      authorize: approve, trustPublisher,
      fetchBytes: async (url, maxBytes) => {
        const parsed = new URL(url);
        if (parsed.protocol !== 'https:' || parsed.username || parsed.password) throw new Error('Unsafe artifact URL');
        const response = await fetchImpl(url, { credentials: 'omit', redirect: 'error', cache: 'no-store' });
        if (!response.ok) throw new Error('Artifact download failed');
        const length = Number(response.headers.get('content-length'));
        if (Number.isFinite(length) && length > maxBytes) throw new Error('Artifact too large');
        // Streaming limit prevents unbounded downloads even when content-length is absent.
        if (!response.body || !response.body.getReader) throw new Error('Streaming response required');
        const reader = response.body.getReader();
        const chunks = []; let total = 0;
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            total += value.byteLength;
            if (total > maxBytes) throw new Error('Artifact too large');
            chunks.push(value);
          }
        } catch (error) { await reader.cancel().catch(() => {}); throw error; }
        const bytes = new Uint8Array(total); let offset = 0;
        for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
        return bytes;
      }
    });
    return Object.freeze({
      products: packages => catalog.catalogForHost(packages, 'lirisq', item => installer.install(item), 1),
      install: item => installer.install(item),
      inventory: id => installer.inventory(id),
      rollback: id => installer.rollback(id),
      uninstall: id => installer.uninstall(id)
    });
  }
  return Object.freeze({ createStoreHost, createIndexedDbStorage });
});
