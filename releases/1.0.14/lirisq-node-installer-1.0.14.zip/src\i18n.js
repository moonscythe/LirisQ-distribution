(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQI18n = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const DEFAULT_LOCALE = 'en';
  const isRecord = value => Boolean(value) && typeof value === 'object' && !Array.isArray(value);
  const normalizeLocale = value => String(value || '').trim().replace(/_/g, '-').toLowerCase();
  const localeCandidates = locale => { const normalized = normalizeLocale(locale); return [...new Set([normalized, normalized.split('-')[0]].filter(Boolean))]; };
  const readKey = (messages, key) => {
    if (isRecord(messages) && Object.hasOwn(messages, key)) return messages[key];
    return String(key).split('.').reduce((value, part) => isRecord(value) ? value[part] : undefined, messages);
  };
  const interpolate = (message, parameters) => String(message).replace(/\{([A-Za-z0-9_.-]+)\}/g, (match, name) => Object.hasOwn(parameters, name) ? String(parameters[name]) : match);
  function createI18n(options = {}) {
    const packs = new Map(); const missing = new Set();
    let fallbackLocale = normalizeLocale(options.fallbackLocale) || DEFAULT_LOCALE;
    let locale = normalizeLocale(options.locale) || fallbackLocale;
    const onMissing = typeof options.onMissing === 'function' ? options.onMissing : () => {};
    const resolve = (key, requestedLocale = locale) => {
      for (const candidate of [...localeCandidates(requestedLocale), ...localeCandidates(fallbackLocale)]) {
        const value = readKey(packs.get(candidate), key); if (typeof value === 'string') return value;
      }
      return undefined;
    };
    return Object.freeze({
      register(language, messages) { const normalized = normalizeLocale(language); if (!normalized || !isRecord(messages)) throw new TypeError('A locale and a message object are required.'); packs.set(normalized, Object.freeze({ ...(packs.get(normalized) || {}), ...messages })); return normalized; },
      setLocale(nextLocale) { locale = normalizeLocale(nextLocale) || fallbackLocale; return locale; },
      getLocale: () => locale,
      availableLocales: () => [...packs.keys()].sort(),
      missingKeys: () => [...missing].sort(),
      clearMissing: () => missing.clear(),
      t(key, parameters = {}) { const message = resolve(key); if (typeof message !== 'string') { const missingKey = String(key); if (!missing.has(missingKey)) { missing.add(missingKey); onMissing({ key: missingKey, locale }); } return missingKey; } return interpolate(message, isRecord(parameters) ? parameters : {}); }
    });
  }
  return Object.freeze({ DEFAULT_LOCALE, normalizeLocale, createI18n });
});
