/* Shared LirisQ extension manifest contract v1. No plugin execution here. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQExtensionContract = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const types = new Set(['skin', 'plugin']);
  const hosts = new Set(['lirisq', 'mgb']);
  const idPattern = /^[a-z0-9][a-z0-9._-]{2,127}$/;
  const versionPattern = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/;
  const digestPattern = /^sha256:[a-f0-9]{64}$/;
  const own = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
  function validate(manifest) {
    if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) throw new TypeError('Manifest must be an object');
    if (manifest.schema !== 'lirisq-extension/v1') throw new Error('Unsupported manifest schema');
    if (typeof manifest.id !== 'string' || !idPattern.test(manifest.id)) throw new Error('Invalid extension ID');
    if (!types.has(manifest.type)) throw new Error('Invalid extension type');
    if (!hosts.has(manifest.host)) throw new Error('Invalid extension host');
    if (typeof manifest.name !== 'string' || !manifest.name.trim() || manifest.name.length > 120) throw new Error('Invalid extension name');
    if (typeof manifest.version !== 'string' || !versionPattern.test(manifest.version)) throw new Error('Invalid extension version');
    if (typeof manifest.publisherId !== 'string' || !idPattern.test(manifest.publisherId)) throw new Error('Invalid publisher ID');
    if (typeof manifest.apiVersion !== 'string' || !versionPattern.test(manifest.apiVersion)) throw new Error('Invalid host API version');
    if (!manifest.artifact || typeof manifest.artifact !== 'object' || !digestPattern.test(manifest.artifact.digest)) throw new Error('SHA-256 artifact digest required');
    if (typeof manifest.artifact.url !== 'string') throw new Error('Artifact URL required');
    let url;
    try { url = new URL(manifest.artifact.url); } catch { throw new Error('Invalid artifact URL'); }
    if (url.protocol !== 'https:' || url.username || url.password) throw new Error('Artifact must use HTTPS without embedded credentials');
    if (manifest.type === 'skin') {
      if (own(manifest, 'permissions') && (!Array.isArray(manifest.permissions) || manifest.permissions.length)) throw new Error('Skins cannot request permissions');
    } else if (!Array.isArray(manifest.permissions) || !manifest.permissions.every(p => typeof p === 'string' && /^[a-z][a-z0-9.:-]{1,79}$/.test(p))) {
      throw new Error('Plugins must declare permissions');
    }
    if (manifest.priceModel !== undefined && manifest.priceModel !== 'free') throw new Error('Paid entitlement support not implemented');
    return Object.freeze({ ...manifest, permissions: manifest.type === 'skin' ? [] : [...manifest.permissions], priceModel: 'free' });
  }
  function compatible(manifest, host, supportedMajor) {
    const pkg = validate(manifest);
    return pkg.host === host && Number(pkg.apiVersion.split('.')[0]) === supportedMajor;
  }
  return Object.freeze({ validate, compatible });
});
