/* Authenticated inbound MGB playback bridge for the trusted LirisQ plugin host.
   Caller MUST establish sender identity, origin and session authentication.
   This module never accepts arbitrary window message events by itself.
 */
(function (root, factory) {
  const api = factory(typeof module === 'object' && module.exports ? require('./mgb-protocol.js') : root.LirisQMGBProtocol, root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQMGBBridge = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (protocol, root) {
  'use strict';
  const mapping = Object.freeze({
    'playback.started': 'song.started',
    'playback.finished': 'song.finished',
    'playback.paused': 'queue.paused',
    'playback.resumed': 'queue.resumed'
  });
  function createBridge({ emit, authenticate, sessionId, now = () => Date.now(), maxSkewMs = 60000 }) {
    if (typeof emit !== 'function' || typeof authenticate !== 'function') throw new Error('Event emitter and authenticator required');
    if (typeof sessionId !== 'string' || !sessionId) throw new Error('Session ID required');
    const seen = new Set();
    async function receive(raw, context) {
      if (await authenticate(context, raw) !== true) throw new Error('MGB sender not authenticated');
      const message = protocol.parse(raw);
      if (message.sessionId !== sessionId) throw new Error('MGB session mismatch');
      if (Math.abs(now() - message.sentAt) > maxSkewMs) throw new Error('Stale MGB message');
      if (seen.has(message.messageId)) return false;
      seen.add(message.messageId);
      if (seen.size > 2048) seen.delete(seen.values().next().value);
      const payload = message.payload;
      if (message.event === 'playback.started') {
        root.LIRISQ_MGB_CAPTURE?.setCurrent({ id: payload.songId || null, title: payload.title || '', artist: payload.artist || '', url: payload.url || payload.songUrl || '', artistUrl: payload.artistUrl || '' });
        return true;
      }
      if (message.event === 'playback.finished') {
        root.LIRISQ_MGB_CAPTURE?.setCurrent(null);
        return true;
      }
      emit(mapping[message.event], {
        id: payload.songId || null,
        title: payload.title || '',
        artist: payload.artist || '',
        source: 'mgb'
      });
      return true;
    }
    return Object.freeze({ receive });
  }
  return Object.freeze({ createBridge });
});
