import { createServer } from 'node:http';
import { createCipheriv, createDecipheriv, createHash, createHmac, createVerify, randomBytes, timingSafeEqual } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { openWorkspaceStore } from './server/workspace-store.mjs';

const port = Number(process.env.PORT || 4317);
const bindHost = String(process.env.LIRISQ_BIND_HOST || '127.0.0.1').trim() || '127.0.0.1';
const root = new URL('./', import.meta.url);
const dataDirectory = path.resolve(String(process.env.LIRISQ_DATA_DIR || '.lirisq-data').trim() || '.lirisq-data');
const workspaceStore = openWorkspaceStore(dataDirectory);
const configuredPublicOrigin = String(process.env.LIRISQ_PUBLIC_ORIGIN || '').trim().replace(/\/$/, '');
const routes = new Set(['/', '/player', '/obs-player', '/obs-queue', '/shows', '/configuration', '/setup', '/skin-maker', '/skins-store', '/profile', '/analytics', '/song-history', '/discord', '/x-shows', '/calendar-export', '/notifications', '/bot-plugins', '/help', '/live', '/live/queue']);
let obsOverlayState = { updatedAt: 0, playing: null, queue: { vip: [], standard: [] } };
const discordPostTimes = [];
const twitchEvents = [];
const twitchMessageIds = new Set();
let twitchSequence = 0;
let twitchAuthorization = null;
let twitchAppToken = null;
const twitchOAuthStates = new Map();
const twitchSubscriptions = new Map();
const twitchScopes = ['bits:read', 'channel:read:subscriptions', 'user:read:chat', 'user:write:chat', 'user:bot', 'channel:bot'];
let youtubeAuthorization = null;
const youtubeOAuthStates = new Map();
const youtubeEvents = [];
const youtubeMessageIds = new Set();
let youtubeSequence = 0;
let youtubeLiveChatId = '';
let youtubePageToken = '';
let youtubeNextPollAt = 0;
let kickAuthorization = null;
let kickPublicKey = null;
let kickPublicKeyExpiresAt = 0;
const kickOAuthStates = new Map();
const kickEvents = [];
const kickMessageIds = new Set();
let kickSequence = 0;
const credentialStore = path.join(dataDirectory, '.lirisq-private-tokens.json');
const credentialStoreTemporary = path.join(dataDirectory, '.lirisq-private-tokens.tmp');
const types = { '.css': 'text/css; charset=utf-8', '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.md': 'text/markdown; charset=utf-8', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ttf': 'font/ttf' };

function credentialEncryptionKey() {
  const configured = String(process.env.LIRISQ_TOKEN_ENCRYPTION_KEY || '').trim();
  if (!/^[0-9a-f]{64}$/i.test(configured)) return null;
  return Buffer.from(configured, 'hex');
}
async function loadCredentialStore() {
  const key = credentialEncryptionKey(); if (!key) return;
  try {
    const record = JSON.parse(await readFile(credentialStore, 'utf8'));
    if (record?.version !== 1 || !record.iv || !record.tag || !record.ciphertext) return;
    const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(record.iv, 'base64'));
    decipher.setAuthTag(Buffer.from(record.tag, 'base64'));
    const data = JSON.parse(Buffer.concat([decipher.update(Buffer.from(record.ciphertext, 'base64')), decipher.final()]).toString('utf8'));
    twitchAuthorization = data.twitch && typeof data.twitch === 'object' ? data.twitch : null;
    youtubeAuthorization = data.youtube && typeof data.youtube === 'object' ? data.youtube : null;
    kickAuthorization = data.kick && typeof data.kick === 'object' ? data.kick : null;
  } catch { /* An unavailable or invalid credential store never becomes a connected state. */ }
}
async function persistCredentialStore() {
  const key = credentialEncryptionKey(); if (!key) return false;
  const iv = randomBytes(12); const cipher = createCipheriv('aes-256-gcm', key, iv);
  const plaintext = Buffer.from(JSON.stringify({ twitch:twitchAuthorization, youtube:youtubeAuthorization, kick:kickAuthorization }), 'utf8');
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const record = JSON.stringify({ version:1, iv:iv.toString('base64'), tag:cipher.getAuthTag().toString('base64'), ciphertext:ciphertext.toString('base64') });
  await writeFile(credentialStoreTemporary, record, { mode:0o600 }); await rename(credentialStoreTemporary, credentialStore); return true;
}
const credentialStoreReady = mkdir(dataDirectory, { recursive:true, mode:0o700 }).then(loadCredentialStore);

function sendJson(res, status, value) {
  res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' });
  res.end(JSON.stringify(value));
}

function requestOrigin(req) {
  if (configuredPublicOrigin) return configuredPublicOrigin;
  return `http://${String(req.headers.host || `127.0.0.1:${port}`)}`;
}
function sameOrigin(req) { return !req.headers.origin || req.headers.origin === requestOrigin(req); }
function cookie(req, name) { return String(req.headers.cookie || '').split(';').map(value => value.trim()).find(value => value.startsWith(`${name}=`))?.slice(name.length + 1) || ''; }
function setCookie(res, name, value, maxAge = 600) { res.setHeader('set-cookie', `${name}=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}`); }
function clearCookie(res, name) { res.setHeader('set-cookie', `${name}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`); }
function twitchConfiguration() {
  const clientId = String(process.env.LIRISQ_TWITCH_CLIENT_ID || '').trim();
  const clientSecret = String(process.env.LIRISQ_TWITCH_CLIENT_SECRET || '').trim();
  const redirectUri = String(process.env.LIRISQ_TWITCH_REDIRECT_URI || '').trim();
  const eventSubCallback = String(process.env.LIRISQ_TWITCH_EVENTSUB_CALLBACK_URL || '').trim();
  return { clientId, clientSecret, redirectUri, eventSubCallback, ready: Boolean(clientId && clientSecret && /^https?:\/\//.test(redirectUri) && /^https:\/\//.test(eventSubCallback) && process.env.LIRISQ_TWITCH_EVENTSUB_SECRET) };
}
function youtubeConfiguration() {
  const clientId = String(process.env.LIRISQ_YOUTUBE_CLIENT_ID || '').trim();
  const clientSecret = String(process.env.LIRISQ_YOUTUBE_CLIENT_SECRET || '').trim();
  const redirectUri = String(process.env.LIRISQ_YOUTUBE_REDIRECT_URI || '').trim();
  return { clientId, clientSecret, redirectUri, ready: Boolean(clientId && clientSecret && /^https?:\/\//.test(redirectUri)) };
}
function kickConfiguration() {
  const clientId = String(process.env.LIRISQ_KICK_CLIENT_ID || '').trim();
  const clientSecret = String(process.env.LIRISQ_KICK_CLIENT_SECRET || '').trim();
  const redirectUri = String(process.env.LIRISQ_KICK_REDIRECT_URI || '').trim();
  const webhookCallback = String(process.env.LIRISQ_KICK_WEBHOOK_CALLBACK_URL || '').trim();
  return { clientId, clientSecret, redirectUri, webhookCallback, ready:Boolean(clientId && clientSecret && /^https?:\/\//.test(redirectUri) && /^https:\/\//.test(webhookCallback)) };
}
async function kickJson(url, options = {}) { const response = await fetch(url, { ...options, signal:AbortSignal.timeout(15000) }); const body = await response.json().catch(() => ({})); if (!response.ok) throw Error(body.message || body.error || `Kick request failed (${response.status})`); return body; }
function cleanExpiredKickState() { const now = Date.now(); for (const [state, value] of kickOAuthStates) if (value.expiresAt < now) kickOAuthStates.delete(state); }
async function refreshKickAuthorization() { if (!kickAuthorization?.refreshToken) throw Error('Kick broadcaster authorization is required'); if (kickAuthorization.expiresAt > Date.now() + 120000) return kickAuthorization; const config=kickConfiguration(); const result=await kickJson('https://id.kick.com/oauth/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'refresh_token',client_id:config.clientId,client_secret:config.clientSecret,refresh_token:kickAuthorization.refreshToken})}); kickAuthorization={...kickAuthorization,accessToken:result.access_token,refreshToken:result.refresh_token||kickAuthorization.refreshToken,expiresAt:Date.now()+Number(result.expires_in||0)*1000,scopes:String(result.scope||kickAuthorization.scopes||'').split(' ').filter(Boolean)};await persistCredentialStore();return kickAuthorization; }
async function kickPublicVerificationKey() { if (kickPublicKey && kickPublicKeyExpiresAt>Date.now()) return kickPublicKey; const response=await fetch('https://api.kick.com/public/v1/public-key',{signal:AbortSignal.timeout(15000)}); const pem=await response.text(); if (!response.ok || !pem.includes('BEGIN PUBLIC KEY')) throw Error('Kick public key unavailable'); kickPublicKey=pem;kickPublicKeyExpiresAt=Date.now()+5*60*1000;return pem; }
async function validKickSignature(rawBody, headers) { const id=String(headers['kick-event-message-id']||'');const timestamp=String(headers['kick-event-message-timestamp']||'');const signature=String(headers['kick-event-signature']||'');const sentAt=Date.parse(timestamp);if(!id||!signature||!Number.isFinite(sentAt)||Math.abs(Date.now()-sentAt)>10*60*1000)return false;try{const verify=createVerify('RSA-SHA256');verify.update(`${id}.${timestamp}.${rawBody.toString('utf8')}`);verify.end();return verify.verify(await kickPublicVerificationKey(),Buffer.from(signature,'base64'));}catch{return false;} }
async function youtubeJson(url, options = {}) { const response = await fetch(url, { ...options, signal: AbortSignal.timeout(15000) }); const body = await response.json().catch(() => ({})); if (!response.ok) throw Error(body.error?.message || body.error || `YouTube request failed (${response.status})`); return body; }
async function refreshYoutubeAuthorization() { if (!youtubeAuthorization?.refreshToken) throw Error('YouTube broadcaster authorization is required'); if (youtubeAuthorization.expiresAt > Date.now() + 120000) return youtubeAuthorization; const config = youtubeConfiguration(); const result = await youtubeJson('https://oauth2.googleapis.com/token', { method:'POST', headers:{'content-type':'application/x-www-form-urlencoded'}, body:new URLSearchParams({ client_id:config.clientId, client_secret:config.clientSecret, grant_type:'refresh_token', refresh_token:youtubeAuthorization.refreshToken }) }); youtubeAuthorization = { ...youtubeAuthorization, accessToken:result.access_token, refreshToken:result.refresh_token || youtubeAuthorization.refreshToken, expiresAt:Date.now() + Number(result.expires_in || 0) * 1000 }; await persistCredentialStore(); return youtubeAuthorization; }
async function youtubeAccessToken() { return (await refreshYoutubeAuthorization()).accessToken; }
async function refreshYoutubeLiveChat() { if (!youtubeAuthorization) return ''; const token = await youtubeAccessToken(); const result = await youtubeJson('https://www.googleapis.com/youtube/v3/liveBroadcasts?part=snippet&broadcastStatus=active&broadcastType=all&mine=true', { headers:{authorization:`Bearer ${token}`} }); const chatId = String(result.items?.[0]?.snippet?.liveChatId || ''); if (chatId !== youtubeLiveChatId) { youtubeLiveChatId = chatId; youtubePageToken = ''; } return youtubeLiveChatId; }
async function pollYoutubeLiveChat() { if (!youtubeAuthorization || Date.now() < youtubeNextPollAt) return; try { const chatId = await refreshYoutubeLiveChat(); if (!chatId) { youtubeNextPollAt = Date.now() + 15000; return; } const token = await youtubeAccessToken(); const url = new URL('https://www.googleapis.com/youtube/v3/liveChat/messages'); url.search = new URLSearchParams({ liveChatId:chatId, part:'id,snippet,authorDetails', maxResults:'200', ...(youtubePageToken ? { pageToken:youtubePageToken } : {}) }).toString(); const result = await youtubeJson(url, { headers:{authorization:`Bearer ${token}`} }); youtubePageToken = String(result.nextPageToken || youtubePageToken); youtubeNextPollAt = Date.now() + Math.max(1000, Number(result.pollingIntervalMillis || 5000)); for (const message of Array.isArray(result.items) ? result.items : []) { const id = String(message?.id || ''); if (!id || youtubeMessageIds.has(id)) continue; youtubeMessageIds.add(id); youtubeEvents.push({ sequence:++youtubeSequence, messageId:id, receivedAt:Date.now(), message }); } while (youtubeEvents.length > 500) youtubeEvents.shift(); while (youtubeMessageIds.size > 1000) youtubeMessageIds.delete(youtubeMessageIds.values().next().value); } catch { youtubeNextPollAt = Date.now() + 15000; } }
function cleanExpiredTwitchState() { const now = Date.now(); for (const [state, value] of twitchOAuthStates) if (value.expiresAt < now) twitchOAuthStates.delete(state); }
async function twitchJson(url, options = {}) {
  const response = await fetch(url, { ...options, signal: AbortSignal.timeout(12000) });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw Error(body.message || body.error || `Twitch request failed (${response.status})`);
  return body;
}
async function refreshTwitchAuthorization() {
  if (!twitchAuthorization?.refreshToken) throw Error('Twitch streamer authorization is required');
  if (twitchAuthorization.expiresAt > Date.now() + 120000) return twitchAuthorization;
  const config = twitchConfiguration();
  const result = await twitchJson('https://id.twitch.tv/oauth2/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: twitchAuthorization.refreshToken, client_id: config.clientId, client_secret: config.clientSecret }) });
  twitchAuthorization = { ...twitchAuthorization, accessToken: result.access_token, refreshToken: result.refresh_token || twitchAuthorization.refreshToken, expiresAt: Date.now() + Number(result.expires_in || 0) * 1000, scopes: Array.isArray(result.scope) ? result.scope : twitchAuthorization.scopes };
  await persistCredentialStore();
  return twitchAuthorization;
}
async function twitchAppAccessToken() {
  const config = twitchConfiguration();
  if (twitchAppToken?.expiresAt > Date.now() + 120000) return twitchAppToken.accessToken;
  const result = await twitchJson('https://id.twitch.tv/oauth2/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: config.clientId, client_secret: config.clientSecret, grant_type: 'client_credentials' }) });
  twitchAppToken = { accessToken: result.access_token, expiresAt: Date.now() + Number(result.expires_in || 0) * 1000 };
  return twitchAppToken.accessToken;
}
function twitchHeaders(token) { return { authorization: `Bearer ${token}`, 'client-id': twitchConfiguration().clientId, 'content-type': 'application/json' }; }
async function refreshTwitchSubscriptions() {
  const config = twitchConfiguration(); if (!config.clientId || !config.clientSecret) return;
  const token = await twitchAppAccessToken(); const result = await twitchJson('https://api.twitch.tv/helix/eventsub/subscriptions', { headers: twitchHeaders(token) });
  twitchSubscriptions.clear(); for (const subscription of Array.isArray(result.data) ? result.data : []) twitchSubscriptions.set(subscription.id, { id: subscription.id, type: subscription.type, status: subscription.status });
}

function validTwitchSignature(rawBody, headers) {
  const secret = process.env.LIRISQ_TWITCH_EVENTSUB_SECRET;
  const id = String(headers['twitch-eventsub-message-id'] || '');
  const timestamp = String(headers['twitch-eventsub-message-timestamp'] || '');
  const signature = String(headers['twitch-eventsub-message-signature'] || '');
  if (!secret || !id || !timestamp || !/^sha256=[0-9a-f]{64}$/i.test(signature)) return false;
  const sentAt = Date.parse(timestamp);
  if (!Number.isFinite(sentAt) || Math.abs(Date.now() - sentAt) > 10 * 60 * 1000) return false;
  const expected = `sha256=${createHmac('sha256', secret).update(id).update(timestamp).update(rawBody).digest('hex')}`;
  const supplied = Buffer.from(signature, 'utf8'); const expectedBytes = Buffer.from(expected, 'utf8');
  return supplied.length === expectedBytes.length && timingSafeEqual(supplied, expectedBytes);
}

async function readRawBody(req, limit = 256 * 1024) {
  const chunks = []; let size = 0;
  for await (const chunk of req) { size += chunk.length; if (size > limit) throw new Error('Request too large'); chunks.push(chunk); }
  return Buffer.concat(chunks);
}

createServer(async (req, res) => {
  await credentialStoreReady;
  const requestUrl = new URL(req.url || '/', requestOrigin(req));
  const pathname = decodeURIComponent(requestUrl.pathname);
  if (pathname === '/healthz' && req.method === 'GET') return sendJson(res, 200, { ok:true, version:process.env.LIRISQ_RELEASE_VERSION || 'development', storage:workspaceStore.status() });
  if (pathname === '/api/setup/status' && req.method === 'GET') return sendJson(res, 200, { administratorReady:workspaceStore.administratorReady() });
  if (pathname === '/api/setup/bootstrap' && req.method === 'POST') {
    if (!sameOrigin(req) || workspaceStore.administratorReady()) return sendJson(res, 403, { error:'Setup is unavailable' });
    try { const body=JSON.parse((await readRawBody(req, 2048)).toString('utf8')); workspaceStore.bootstrapAdministrator(String(body.password || '')); const login=workspaceStore.createAdministratorSession(String(body.password || '')); setCookie(res, 'lirisq_admin', login.token, 12*60*60); return sendJson(res, 201, { csrfToken:login.csrfToken }); } catch (error) { return sendJson(res,400,{error:String(error.message||error)}); }
  }
  if (pathname === '/api/admin/login' && req.method === 'POST') {
    if (!sameOrigin(req)) return sendJson(res,403,{error:'Invalid origin'});
    try { const body=JSON.parse((await readRawBody(req,2048)).toString('utf8')); const login=workspaceStore.createAdministratorSession(String(body.password||'')); setCookie(res,'lirisq_admin',login.token,12*60*60); return sendJson(res,200,{csrfToken:login.csrfToken}); } catch { return sendJson(res,401,{error:'Invalid administrator credentials'}); }
  }
  if (pathname === '/api/admin/session' && req.method === 'GET') return sendJson(res,200,{authenticated:Boolean(workspaceStore.administratorSession(cookie(req,'lirisq_admin')))});
  if (pathname === '/api/admin/logout' && req.method === 'POST') { clearCookie(res,'lirisq_admin'); return sendJson(res,204,{}); }
  if (pathname === '/api/workspace') {
    const administrator = workspaceStore.administratorSession(cookie(req, 'lirisq_admin'));
    if (!administrator) return sendJson(res, 401, { error:'Administrator authentication is required' });
    if (req.method === 'GET') return sendJson(res, 200, { workspace:workspaceStore.read() });
    if (req.method === 'PUT') {
      if (!sameOrigin(req) || req.headers['x-lirisq-csrf'] !== administrator.csrfToken || req.headers['content-type']?.split(';')[0].trim() !== 'application/json') return sendJson(res,403,{error:'Invalid workspace write'});
      try { const state=JSON.parse((await readRawBody(req, 2*1024*1024)).toString('utf8')); return sendJson(res,200,{workspace:workspaceStore.write('default',state)}); }
      catch (error) { return sendJson(res,400,{error:String(error.message||error)}); }
    }
    return sendJson(res,405,{error:'Method not allowed'});
  }
  // Deliberately diagnostic-only until administrator authentication is in place.
  if (pathname === '/api/system/storage' && req.method === 'GET') return sendJson(res, 200, { ready:true, storage:workspaceStore.status() });
  if (pathname === '/api/youtube/authorize' && req.method === 'GET') {
    const config = youtubeConfiguration(); if (!config.ready) return sendJson(res, 503, { error:'YouTube server configuration is incomplete' });
    const state = randomBytes(32).toString('base64url'); youtubeOAuthStates.set(state, Date.now() + 10 * 60 * 1000); setCookie(res, 'lirisq_youtube_oauth_state', state);
    const destination = new URL('https://accounts.google.com/o/oauth2/v2/auth'); destination.search = new URLSearchParams({ client_id:config.clientId, redirect_uri:config.redirectUri, response_type:'code', scope:'https://www.googleapis.com/auth/youtube.force-ssl', access_type:'offline', prompt:'consent', state, include_granted_scopes:'true' }).toString(); res.writeHead(302, { location:destination.toString(), 'cache-control':'no-store' }); return res.end();
  }
  if (pathname === '/api/youtube/oauth/callback' && req.method === 'GET') {
    const state = requestUrl.searchParams.get('state') || ''; const code = requestUrl.searchParams.get('code') || ''; const expiresAt = youtubeOAuthStates.get(state); youtubeOAuthStates.delete(state);
    if (!expiresAt || expiresAt < Date.now() || !code || cookie(req, 'lirisq_youtube_oauth_state') !== state) { res.writeHead(400, {'content-type':'text/html; charset=utf-8'}); return res.end('<h1>YouTube connection could not be verified.</h1><p>Return to LirisQ and try again.</p>'); }
    try { const config = youtubeConfiguration(); const tokens = await youtubeJson('https://oauth2.googleapis.com/token', { method:'POST', headers:{'content-type':'application/x-www-form-urlencoded'}, body:new URLSearchParams({ client_id:config.clientId, client_secret:config.clientSecret, code, grant_type:'authorization_code', redirect_uri:config.redirectUri }) }); const identity = await youtubeJson('https://www.googleapis.com/youtube/v3/channels?part=id,snippet&mine=true', { headers:{authorization:`Bearer ${tokens.access_token}`} }); const channel = identity.items?.[0]; if (!channel?.id) throw Error('YouTube channel identity was not returned'); youtubeAuthorization = { accessToken:tokens.access_token, refreshToken:tokens.refresh_token, expiresAt:Date.now() + Number(tokens.expires_in || 0) * 1000, channelId:String(channel.id), channelTitle:String(channel.snippet?.title || '') }; await persistCredentialStore(); youtubeLiveChatId = ''; youtubePageToken = ''; setCookie(res, 'lirisq_youtube_oauth_state', '', 0); res.writeHead(302, { location:'/configuration?youtube=connected', 'cache-control':'no-store' }); return res.end(); } catch { res.writeHead(502, {'content-type':'text/html; charset=utf-8'}); return res.end('<h1>YouTube connection failed.</h1><p>Return to LirisQ and verify the server configuration.</p>'); }
  }
  if (pathname === '/api/youtube/status' && req.method === 'GET') { const config = youtubeConfiguration(); await pollYoutubeLiveChat(); const authorized = youtubeAuthorization && youtubeAuthorization.expiresAt > Date.now(); return sendJson(res, 200, { configured:config.ready, credentialPersistenceConfigured:Boolean(credentialEncryptionKey()), authorized:Boolean(authorized), broadcaster:authorized ? { id:youtubeAuthorization.channelId, title:youtubeAuthorization.channelTitle } : null, liveChatId:youtubeLiveChatId || null, receivedEvents:youtubeSequence }); }
  if (pathname === '/api/youtube/events' && req.method === 'GET') { await pollYoutubeLiveChat(); const after = Math.max(0, Number(requestUrl.searchParams.get('after')) || 0); return sendJson(res, 200, { events:youtubeEvents.filter(event => event.sequence > after), latest:youtubeSequence }); }
  if (pathname === '/api/youtube/chat' && req.method === 'POST') {
    if (!sameOrigin(req)) return sendJson(res, 403, { error:'Cross-origin request denied' });
    try { const raw = await readRawBody(req, 4096); const body = JSON.parse(raw.toString('utf8')); const message = String(body.message || '').trim(); if (!message || message.length > 200) throw Error('A chat message of up to 200 characters is required'); const chatId = await refreshYoutubeLiveChat(); if (!chatId) throw Error('No active YouTube live chat was found'); const result = await youtubeJson('https://www.googleapis.com/youtube/v3/liveChat/messages?part=snippet', { method:'POST', headers:{authorization:`Bearer ${await youtubeAccessToken()}`, 'content-type':'application/json'}, body:JSON.stringify({ snippet:{ liveChatId:chatId, type:'textMessageEvent', textMessageDetails:{ messageText:message } } }) }); return sendJson(res, 200, { sent:Boolean(result.id), messageId:result.id || null }); } catch (error) { return sendJson(res, 502, { error:String(error.message || error) }); }
  }
  if (pathname === '/api/kick/authorize' && req.method === 'GET') {
    const config=kickConfiguration(); if (!config.clientId || !config.clientSecret || !/^https?:\/\//.test(config.redirectUri)) return sendJson(res,503,{error:'Kick OAuth server configuration is incomplete'});
    cleanExpiredKickState(); const state=randomBytes(32).toString('base64url'); const verifier=randomBytes(48).toString('base64url'); const challenge=createHash('sha256').update(verifier).digest('base64url'); kickOAuthStates.set(state,{expiresAt:Date.now()+10*60*1000,verifier}); setCookie(res,'lirisq_kick_oauth_state',state);
    const destination=new URL('https://id.kick.com/oauth/authorize'); destination.search=new URLSearchParams({client_id:config.clientId,response_type:'code',redirect_uri:config.redirectUri,state,scope:'user:read channel:read chat:write events:subscribe kicks:read',code_challenge:challenge,code_challenge_method:'S256'}).toString(); res.writeHead(302,{location:destination.toString(),'cache-control':'no-store'});return res.end();
  }
  if (pathname === '/api/kick/oauth/callback' && req.method === 'GET') {
    const state=requestUrl.searchParams.get('state')||'',code=requestUrl.searchParams.get('code')||'',record=kickOAuthStates.get(state);kickOAuthStates.delete(state);
    if(!record||record.expiresAt<Date.now()||!code||cookie(req,'lirisq_kick_oauth_state')!==state){res.writeHead(400,{'content-type':'text/html; charset=utf-8'});return res.end('<h1>Kick connection could not be verified.</h1><p>Return to LirisQ and try again.</p>');}
    try{const config=kickConfiguration();const tokens=await kickJson('https://id.kick.com/oauth/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'authorization_code',client_id:config.clientId,client_secret:config.clientSecret,redirect_uri:config.redirectUri,code_verifier:record.verifier,code})});kickAuthorization={accessToken:tokens.access_token,refreshToken:tokens.refresh_token,expiresAt:Date.now()+Number(tokens.expires_in||0)*1000,scopes:String(tokens.scope||'').split(' ').filter(Boolean)};await persistCredentialStore();setCookie(res,'lirisq_kick_oauth_state','',0);res.writeHead(302,{location:'/configuration?kick=connected','cache-control':'no-store'});return res.end();}catch{res.writeHead(502,{'content-type':'text/html; charset=utf-8'});return res.end('<h1>Kick connection failed.</h1><p>Return to LirisQ and verify the server configuration.</p>');}
  }
  if (pathname === '/api/kick/status' && req.method === 'GET') { const config=kickConfiguration(); const authorized=kickAuthorization && (await refreshKickAuthorization().then(()=>true).catch(()=>false)); return sendJson(res,200,{configured:config.ready,credentialPersistenceConfigured:Boolean(credentialEncryptionKey()),oauthConfigured:Boolean(config.clientId&&config.clientSecret&&/^https?:\/\//.test(config.redirectUri)),publicCallbackConfigured:/^https:\/\//.test(config.webhookCallback),authorized:Boolean(authorized),receivedEvents:kickSequence}); }
  if (pathname === '/api/kick/events' && req.method === 'GET') { const after=Math.max(0,Number(requestUrl.searchParams.get('after'))||0);return sendJson(res,200,{events:kickEvents.filter(event=>event.sequence>after),latest:kickSequence}); }
  if (pathname === '/api/kick/webhook' && req.method === 'POST') {
    let rawBody;try{rawBody=await readRawBody(req);}catch{res.writeHead(413);return res.end();}if(!await validKickSignature(rawBody,req.headers)){res.writeHead(403);return res.end();}let payload;try{payload=JSON.parse(rawBody.toString('utf8'));}catch{res.writeHead(400);return res.end();}const messageId=String(req.headers['kick-event-message-id']||'');if(!kickMessageIds.has(messageId)){kickMessageIds.add(messageId);kickEvents.push({sequence:++kickSequence,messageId,type:String(req.headers['kick-event-type']||''),receivedAt:Date.now(),payload});while(kickEvents.length>500)kickEvents.shift();while(kickMessageIds.size>1000)kickMessageIds.delete(kickMessageIds.values().next().value);}res.writeHead(204,{'cache-control':'no-store'});return res.end();
  }
  if (pathname === '/api/obs/overlay' && req.method === 'GET') return sendJson(res, 200, obsOverlayState);
  if (pathname === '/api/obs/overlay' && req.method === 'POST') {
    if (!sameOrigin(req) || req.headers['content-type']?.split(';')[0].trim() !== 'application/json') return sendJson(res, 403, { error: 'Cross-origin request denied' });
    try {
      const raw = await readRawBody(req, 32 * 1024);
      const body = JSON.parse(raw.toString('utf8'));
      const text = value => String(value || '').trim().slice(0, 240);
      const item = value => value && typeof value === 'object' ? { id: text(value.id).slice(0, 128), song: text(value.song), artist: text(value.artist), viewer: text(value.viewer), url: /^https?:\/\//i.test(String(value.url || '')) ? String(value.url).slice(0, 1000) : '#', artistUrl: /^https?:\/\//i.test(String(value.artistUrl || '')) ? String(value.artistUrl).slice(0, 1000) : '' } : null;
      const queue = body.queue && typeof body.queue === 'object' ? body.queue : {};
      obsOverlayState = { updatedAt: Date.now(), playing: item(body.playing), queue: { vip: Array.isArray(queue.vip) ? queue.vip.slice(0, 12).map(item).filter(Boolean) : [], standard: Array.isArray(queue.standard) ? queue.standard.slice(0, 12).map(item).filter(Boolean) : [] } };
      return sendJson(res, 204, {});
    } catch { return sendJson(res, 400, { error: 'Invalid overlay state' }); }
  }
  if (pathname === '/api/twitch/authorize' && req.method === 'GET') {
    const config = twitchConfiguration();
    if (!config.clientId || !config.clientSecret || !/^https?:\/\//.test(config.redirectUri)) return sendJson(res, 503, { error: 'Twitch OAuth server configuration is incomplete' });
    cleanExpiredTwitchState();
    const state = randomBytes(32).toString('base64url'); twitchOAuthStates.set(state, { expiresAt: Date.now() + 10 * 60 * 1000 });
    setCookie(res, 'lirisq_twitch_oauth_state', state);
    const destination = new URL('https://id.twitch.tv/oauth2/authorize');
    destination.search = new URLSearchParams({ client_id: config.clientId, redirect_uri: config.redirectUri, response_type: 'code', scope: twitchScopes.join(' '), state, force_verify: 'true' }).toString();
    res.writeHead(302, { location: destination.toString(), 'cache-control': 'no-store' }); return res.end();
  }
  if (pathname === '/api/twitch/oauth/callback' && req.method === 'GET') {
    const state = requestUrl.searchParams.get('state') || ''; const code = requestUrl.searchParams.get('code') || '';
    const record = twitchOAuthStates.get(state); twitchOAuthStates.delete(state);
    if (!record || record.expiresAt < Date.now() || !code || cookie(req, 'lirisq_twitch_oauth_state') !== state) { res.writeHead(400, { 'content-type': 'text/html; charset=utf-8' }); return res.end('<h1>Twitch connection could not be verified.</h1><p>Return to LirisQ and try again.</p>'); }
    try {
      const config = twitchConfiguration();
      const tokens = await twitchJson('https://id.twitch.tv/oauth2/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: config.clientId, client_secret: config.clientSecret, code, grant_type: 'authorization_code', redirect_uri: config.redirectUri }) });
      const identity = await twitchJson('https://id.twitch.tv/oauth2/validate', { headers: { authorization: `OAuth ${tokens.access_token}` } });
      twitchAuthorization = { accessToken: tokens.access_token, refreshToken: tokens.refresh_token, expiresAt: Date.now() + Number(tokens.expires_in || 0) * 1000, userId: String(identity.user_id || ''), login: String(identity.login || ''), scopes: Array.isArray(identity.scopes) ? identity.scopes : [] };
      await persistCredentialStore();
      setCookie(res, 'lirisq_twitch_oauth_state', '', 0);
      res.writeHead(302, { location: '/configuration?twitch=connected', 'cache-control': 'no-store' }); return res.end();
    } catch (error) { res.writeHead(502, { 'content-type': 'text/html; charset=utf-8' }); return res.end(`<h1>Twitch connection failed.</h1><p>${String(error.message || error).replace(/[<>&]/g, '')}</p><p>Return to LirisQ and verify the server configuration.</p>`); }
  }
  if (pathname === '/api/twitch/status' && req.method === 'GET') {
    const config = twitchConfiguration();
    if (config.clientId && config.clientSecret) await refreshTwitchSubscriptions().catch(() => {});
    const authorized = twitchAuthorization && twitchAuthorization.expiresAt > Date.now();
    return sendJson(res, 200, { configured: config.ready, credentialPersistenceConfigured:Boolean(credentialEncryptionKey()), oauthConfigured: Boolean(config.clientId && config.clientSecret && /^https?:\/\//.test(config.redirectUri)), eventSubSecretConfigured: Boolean(process.env.LIRISQ_TWITCH_EVENTSUB_SECRET), publicCallbackConfigured: /^https:\/\//.test(config.eventSubCallback), authorized: Boolean(authorized), broadcaster: authorized ? { id: twitchAuthorization.userId, login: twitchAuthorization.login, scopes: twitchAuthorization.scopes } : null, subscriptions: [...twitchSubscriptions.values()], receivedEvents: twitchSequence });
  }
  if (pathname === '/api/twitch/subscriptions' && req.method === 'POST') {
    if (!sameOrigin(req)) return sendJson(res, 403, { error: 'Cross-origin request denied' });
    const config = twitchConfiguration();
    if (!config.ready) return sendJson(res, 503, { error: 'Twitch server configuration is incomplete' });
    try {
      const grant = await refreshTwitchAuthorization(); const appToken = await twitchAppAccessToken();
      const definitions = [
        ['stream.online', '1', { broadcaster_user_id: grant.userId }], ['stream.offline', '1', { broadcaster_user_id: grant.userId }],
        ['channel.subscribe', '1', { broadcaster_user_id: grant.userId }], ['channel.subscription.end', '1', { broadcaster_user_id: grant.userId }],
        ['channel.subscription.gift', '1', { broadcaster_user_id: grant.userId }], ['channel.cheer', '1', { broadcaster_user_id: grant.userId }],
        ['channel.chat.message', '1', { broadcaster_user_id: grant.userId, user_id: grant.userId }]
      ];
      const results = [];
      for (const [type, version, condition] of definitions) {
        try { const result = await twitchJson('https://api.twitch.tv/helix/eventsub/subscriptions', { method: 'POST', headers: twitchHeaders(appToken), body: JSON.stringify({ type, version, condition, transport: { method: 'webhook', callback: config.eventSubCallback, secret: process.env.LIRISQ_TWITCH_EVENTSUB_SECRET } }) }); const subscription = result.data?.[0]; if (subscription) twitchSubscriptions.set(subscription.id, { id: subscription.id, type: subscription.type, status: subscription.status }); results.push({ type, status: subscription?.status || 'pending' }); } catch (error) { results.push({ type, error: String(error.message || error) }); }
      }
      return sendJson(res, 200, { results });
    } catch (error) { return sendJson(res, 502, { error: String(error.message || error) }); }
  }
  if (pathname === '/api/twitch/chat' && req.method === 'POST') {
    if (!sameOrigin(req)) return sendJson(res, 403, { error: 'Cross-origin request denied' });
    try { const raw = await readRawBody(req, 4096); const body = JSON.parse(raw.toString('utf8')); const message = String(body.message || '').trim(); if (!message || message.length > 500) throw Error('A chat message of up to 500 characters is required'); const grant = await refreshTwitchAuthorization(); const result = await twitchJson('https://api.twitch.tv/helix/chat/messages', { method: 'POST', headers: twitchHeaders(grant.accessToken), body: JSON.stringify({ broadcaster_id: grant.userId, sender_id: grant.userId, message }) }); return sendJson(res, 200, { sent: Boolean(result.data?.[0]?.is_sent), messageId: result.data?.[0]?.message_id || null, dropReason: result.data?.[0]?.drop_reason || null }); } catch (error) { return sendJson(res, 502, { error: String(error.message || error) }); }
  }
  if (pathname === '/api/twitch/events' && req.method === 'GET') {
    const after = Math.max(0, Number(new URL(req.url || '/', 'http://127.0.0.1').searchParams.get('after')) || 0);
    return sendJson(res, 200, { events: twitchEvents.filter(event => event.sequence > after), latest: twitchSequence });
  }
  if (pathname === '/api/twitch/eventsub' && req.method === 'POST') {
    let rawBody;
    try { rawBody = await readRawBody(req); } catch { res.writeHead(413); return res.end(); }
    if (!validTwitchSignature(rawBody, req.headers)) { res.writeHead(403); return res.end(); }
    let body; try { body = JSON.parse(rawBody.toString('utf8')); } catch { res.writeHead(400); return res.end(); }
    const messageType = String(req.headers['twitch-eventsub-message-type'] || '');
    if (messageType === 'webhook_callback_verification' && typeof body.challenge === 'string') {
      res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' }); return res.end(body.challenge);
    }
    const messageId = String(req.headers['twitch-eventsub-message-id']);
    if (messageType === 'notification' && !twitchMessageIds.has(messageId)) {
      twitchMessageIds.add(messageId);
      twitchEvents.push({ sequence: ++twitchSequence, messageId, subscriptionType: String(req.headers['twitch-eventsub-subscription-type'] || ''), receivedAt: Date.now(), payload: body });
      while (twitchEvents.length > 500) twitchEvents.shift();
      while (twitchMessageIds.size > 1000) twitchMessageIds.delete(twitchMessageIds.values().next().value);
    }
    res.writeHead(204, { 'cache-control': 'no-store' }); return res.end();
  }
  if (pathname === '/api/discord/status' && req.method === 'GET') {
    res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    return res.end(JSON.stringify({ configured: /^https:\/\/(discord\.com|discordapp\.com)\/api\/webhooks\/[0-9]+\/[A-Za-z0-9_-]+$/.test(process.env.LIRISQ_DISCORD_WEBHOOK_URL || '') }));
  }
  if (pathname === '/api/discord/announce' && req.method === 'POST') {
    const webhook = process.env.LIRISQ_DISCORD_WEBHOOK_URL || '';
    if (!/^https:\/\/(discord\.com|discordapp\.com)\/api\/webhooks\/[0-9]+\/[A-Za-z0-9_-]+$/.test(webhook)) {
      res.writeHead(503, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: 'Discord webhook not configured on server' }));
    }
    if (!sameOrigin(req) || req.headers['content-type']?.split(';')[0].trim() !== 'application/json') {
      res.writeHead(403); return res.end();
    }
    const now = Date.now();
    while (discordPostTimes.length && discordPostTimes[0] < now - 60000) discordPostTimes.shift();
    if (discordPostTimes.length >= 15) {
      res.writeHead(429, { 'content-type': 'application/json', 'retry-after': '60' });
      return res.end(JSON.stringify({ error: 'Discord posting limit reached' }));
    }
    discordPostTimes.push(now);
    let body = '';
    for await (const chunk of req) {
      body += chunk;
      if (body.length > 4096) { res.writeHead(413); return res.end(); }
    }
    try {
      const data = JSON.parse(body);
      if (typeof data.content !== 'string' || !data.content.trim() || data.content.length > 1000) throw new Error('Invalid content');
      const response = await fetch(webhook, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ content: data.content, allowed_mentions: { parse: [] } }),
        signal: AbortSignal.timeout(8000)
      });
      if (response.status === 429) {
        res.writeHead(429, { 'content-type': 'application/json', 'retry-after': '60', 'cache-control': 'no-store' });
        return res.end(JSON.stringify({ error: 'Discord rate limit reached' }));
      }
      res.writeHead(response.ok ? 204 : 502, { 'cache-control': 'no-store' });
      return res.end();
    } catch {
      res.writeHead(400, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: 'Invalid request or Discord delivery failed' }));
    }
  }
  const defaultsMatch = pathname.match(/^\/api\/skin-defaults\/(cassette|record|jukebox|vhs)$/);
  if (defaultsMatch && req.method === 'POST') {
    let body = '';
    for await (const chunk of req) body += chunk;
    try {
      const defaults = JSON.parse(body);
      if (defaults?.schema !== 'lirisq-skin-defaults/v1' || defaults.packageId !== defaultsMatch[1] || !defaults.positions) throw new Error('Invalid skin defaults');
      await writeFile(new URL(`skins/${defaultsMatch[1]}/defaults.json`, root), `${JSON.stringify(defaults, null, 2)}\n`);
      res.writeHead(204, { 'cache-control': 'no-store' }); return res.end();
    } catch { res.writeHead(400, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: 'Invalid skin defaults' })); }
  }
  const requested = routes.has(pathname) ? 'index.html' : pathname.replace(/^\/+/, '');
  const file = path.posix.normalize(requested);
  if (!file || file.startsWith('../') || path.posix.isAbsolute(file)) { res.writeHead(404); return res.end('Not found'); }
  try {
    const ext = path.posix.extname(file);
    const content = await readFile(new URL(file, root));
    res.writeHead(200, { 'content-type': types[ext] || 'application/octet-stream', 'cache-control': 'no-store' });
    res.end(content);
  } catch { res.writeHead(404); res.end('Not found'); }
}).listen(port, bindHost, () => console.log(`LirisQ: http://${bindHost}:${port}`));
