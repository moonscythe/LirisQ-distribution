/* Authenticated MessagePort transport for an already-paired LirisQ/MGB session.
   A trusted bootstrap must transfer the MessagePort and exchange a 256-bit secret.
   Never send the secret over the same untrusted postMessage channel.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQMGBTransport = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const encoder = new TextEncoder();
  const hex = bytes => Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
  function canonical(message) {
    const { schema, kind, event, messageId, sessionId, sentAt, payload } = message;
    return JSON.stringify([schema, kind, event, messageId, sessionId, sentAt, payload]);
  }
  async function createTransport({ port, secret, sessionId, bridge, cryptoApi = globalThis.crypto, onError = () => {}, onDisconnect = () => {} }) {
    if (!port || typeof port.postMessage !== 'function' || typeof port.addEventListener !== 'function') throw new Error('MessagePort required');
    if (!cryptoApi?.subtle) throw new Error('Web Crypto required');
    if (!(secret instanceof Uint8Array) || secret.length !== 32) throw new Error('32-byte session secret required');
    if (typeof sessionId !== 'string' || !sessionId) throw new Error('Session ID required');
    const key = await cryptoApi.subtle.importKey('raw', secret, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
    let closed = false;
    async function sign(message) {
      const signature = await cryptoApi.subtle.sign('HMAC', key, encoder.encode(canonical(message)));
      return hex(new Uint8Array(signature));
    }
    async function verify(raw) {
      if (!raw || typeof raw !== 'object' || typeof raw.mac !== 'string' || !/^[a-f0-9]{64}$/.test(raw.mac)) return false;
      const { mac, ...message } = raw;
      if (message.sessionId !== sessionId) return false;
      const bytes = Uint8Array.from(mac.match(/../g), x => parseInt(x, 16));
      return cryptoApi.subtle.verify('HMAC', key, bytes, encoder.encode(canonical(message)));
    }
    async function send(message) {
      if (closed) throw new Error('Transport closed');
      if (message.sessionId !== sessionId) throw new Error('Session mismatch');
      port.postMessage({ ...message, mac: await sign(message) });
    }
    let disconnectReported = false;
    const reportDisconnect = reason => {
      if (disconnectReported || closed) return;
      disconnectReported = true;
      onDisconnect(reason instanceof Error ? reason : new Error(String(reason || 'MGB MessagePort disconnected')));
    };
    const listener = event => {
      if (closed || !bridge) return;
      Promise.resolve(bridge.receive(event.data, { authenticatedPort: port })).catch(onError);
    };
    const messageErrorListener = () => reportDisconnect(new Error('MGB MessagePort communication failed'));
    port.addEventListener('message', listener);
    port.addEventListener('messageerror', messageErrorListener);
    if (typeof port.start === 'function') port.start();
    return Object.freeze({
      send, verify,
      close() {
        if (closed) return;
        closed = true;
        port.removeEventListener('message', listener);
        port.removeEventListener('messageerror', messageErrorListener);
        if (typeof port.close === 'function') port.close();
      }
    });
  }
  return Object.freeze({ createTransport });
});
