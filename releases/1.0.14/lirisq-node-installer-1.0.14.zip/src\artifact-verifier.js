/* Verify Store package bytes before any host-owned install. No code execution. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQArtifactVerifier = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const MAX_BYTES = 20 * 1024 * 1024;
  function toHex(bytes) { return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join(''); }
  async function verifyBytes(manifest, bytes, options = {}) {
    if (!manifest || !manifest.artifact || !/^sha256:[a-f0-9]{64}$/.test(manifest.artifact.digest)) throw new Error('Invalid expected digest');
    if (!(bytes instanceof Uint8Array)) throw new TypeError('Expected Uint8Array artifact');
    const maxBytes = options.maxBytes === undefined ? MAX_BYTES : options.maxBytes;
    if (!Number.isSafeInteger(maxBytes) || maxBytes < 1 || maxBytes > MAX_BYTES) throw new Error('Invalid size limit');
    if (bytes.byteLength === 0 || bytes.byteLength > maxBytes) throw new Error('Artifact exceeds size limit or is empty');
    const cryptoApi = options.crypto || (typeof globalThis !== 'undefined' && globalThis.crypto);
    if (!cryptoApi || !cryptoApi.subtle || typeof cryptoApi.subtle.digest !== 'function') throw new Error('Web Crypto SHA-256 unavailable');
    const digest = 'sha256:' + toHex(new Uint8Array(await cryptoApi.subtle.digest('SHA-256', bytes)));
    if (digest !== manifest.artifact.digest) throw new Error('Artifact digest mismatch');
    return Object.freeze({ verified: true, digest, size: bytes.byteLength });
  }
  function validateArchivePaths(paths) {
    if (!Array.isArray(paths)) throw new TypeError('Expected archive paths');
    const seen = new Set();
    for (const path of paths) {
      if (typeof path !== 'string' || !path || path.length > 240 ||
          path.includes('\\') || path.startsWith('/') || /^[a-zA-Z]:/.test(path) ||
          path.split('/').some(segment => !segment || segment === '.' || segment === '..' || /[\x00-\x1f]/.test(segment))) {
        throw new Error('Unsafe archive path');
      }
      if (seen.has(path.toLowerCase())) throw new Error('Duplicate archive path');
      seen.add(path.toLowerCase());
    }
    return true;
  }
  return Object.freeze({ verifyBytes, validateArchivePaths, MAX_BYTES });
});
