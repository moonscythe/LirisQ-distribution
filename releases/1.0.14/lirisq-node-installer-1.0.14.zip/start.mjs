#!/usr/bin/env node
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
let configuration = {};
try { configuration = JSON.parse(await readFile(path.join(root, 'lirisq.config.json'), 'utf8')); } catch (error) { if (error.code === 'ENOENT') throw new Error('Run node install-node.mjs before starting LirisQ.'); throw error; }
process.env.LIRISQ_DATA_DIR ||= String(configuration.dataDirectory || path.join(root, '.lirisq-data'));
process.env.LIRISQ_RELEASE_VERSION ||= String(configuration.releaseVersion || 'installed');
process.env.LIRISQ_TOKEN_ENCRYPTION_KEY ||= String(configuration.tokenEncryptionKey || '');
await import('./server.mjs');
