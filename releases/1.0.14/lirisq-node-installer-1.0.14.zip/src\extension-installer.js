/* Host-owned free extension installer: verified staging, inventory and rollback.
   Does not unpack archives or execute plugins. Storage adapter is supplied by host. */
(function (root, factory) {
  const api = factory(
    typeof module === 'object' && module.exports ? require('./extension-contract.js') : root.LirisQExtensionContract,
    typeof module === 'object' && module.exports ? require('./artifact-verifier.js') : root.LirisQArtifactVerifier
  );
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQExtensionInstaller = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (contract, verifier) {
  'use strict';
  if (!contract || !verifier) throw new Error('Extension contract and artifact verifier required');
  function createInstaller({ storage, fetchBytes, authorize, trustPublisher, host = 'lirisq', apiMajor = 1 }) {
    if (!storage || !['get', 'put', 'remove'].every(k => typeof storage[k] === 'function')) throw new TypeError('Storage adapter must implement get, put and remove');
    if (typeof fetchBytes !== 'function' || typeof authorize !== 'function' || typeof trustPublisher !== 'function') throw new TypeError('Fetch, authorization and publisher trust callbacks required');
    if (!['lirisq', 'mgb'].includes(host) || !Number.isSafeInteger(apiMajor) || apiMajor < 0) throw new Error('Invalid host API configuration');
    const prefix = 'extension:' + host + ':';
    const key = id => prefix + id;
    async function install(input) {
      const manifest = contract.validate(input);
      if (!contract.compatible(manifest, host, apiMajor)) throw new Error('Extension incompatible with host');
      if (await trustPublisher(manifest) !== true) throw new Error('Publisher is not trusted');
      if (await authorize(manifest) !== true) throw new Error('Installation not approved');
      const bytes = await fetchBytes(manifest.artifact.url, verifier.MAX_BYTES);
      await verifier.verifyBytes(manifest, bytes);
      // The artifact is kept opaque; extraction and executable activation require separate audited host stages.
      const previous = await storage.get(key(manifest.id));
      const record = {
        manifest, artifact: new Uint8Array(bytes),
        previous: previous ? { manifest: previous.manifest, artifact: previous.artifact } : null,
        state: 'staged'
      };
      await storage.put(key(manifest.id), record);
      return { id: manifest.id, version: manifest.version, state: 'staged', rollbackAvailable: !!previous };
    }
    async function inventory(id) {
      if (id !== undefined) {
        if (typeof id !== 'string' || !/^[a-z0-9][a-z0-9._-]{2,127}$/.test(id)) throw new Error('Invalid extension ID');
        const item = await storage.get(key(id));
        return item ? { id, version: item.manifest.version, state: item.state, rollbackAvailable: !!item.previous } : null;
      }
      if (typeof storage.keys !== 'function') throw new Error('Storage adapter does not support listing');
      const ids = await storage.keys(prefix);
      const result = [];
      for (const fullKey of ids) {
        if (typeof fullKey !== 'string' || !fullKey.startsWith(prefix)) continue;
        const item = await storage.get(fullKey);
        if (item) result.push({ id: item.manifest.id, version: item.manifest.version, state: item.state, rollbackAvailable: !!item.previous });
      }
      return result;
    }
    async function rollback(id) {
      const current = await storage.get(key(id));
      if (!current || !current.previous) throw new Error('No rollback available');
      const previous = current.previous;
      // Validate and rehash stored rollback bytes; storage is not implicitly trusted.
      const manifest = contract.validate(previous.manifest);
      if (!contract.compatible(manifest, host, apiMajor)) throw new Error('Rollback incompatible with host');
      if (await trustPublisher(manifest) !== true) throw new Error('Rollback publisher not trusted');
      await verifier.verifyBytes(manifest, previous.artifact);
      await storage.put(key(id), { manifest, artifact: previous.artifact, previous: null, state: 'staged' });
      return { id, version: manifest.version, state: 'staged' };
    }
    async function uninstall(id) {
      const current = await storage.get(key(id));
      if (!current) return false;
      await storage.remove(key(id));
      return true;
    }
    return Object.freeze({ install, inventory, rollback, uninstall });
  }
  return Object.freeze({ createInstaller });
});
