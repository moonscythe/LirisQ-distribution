# LirisQ Node installer

1. Extract the package into its own directory on a Node 22+ host.
2. Run `node install-node.mjs` once. It creates `lirisq.config.json` and private data only if they do not already exist.
3. Run `node start.mjs` or configure that command in your process manager.

For an upgrade, replace application files from the newer package but retain
`lirisq.config.json` and `.lirisq-data/`; then run `node install-node.mjs` again.
Environment variables supplied by your host take priority over this configuration
file, so existing server-side platform credentials remain intact.
