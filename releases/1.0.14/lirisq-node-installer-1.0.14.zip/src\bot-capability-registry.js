/* Shared capability registry for trusted, enabled LirisQ Bot plugins. */
(function(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQBotCapabilityRegistry = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const providers = new Map();
  function register(pluginId, capability, provider) {
    if (typeof pluginId !== 'string' || typeof capability !== 'string' || !provider || typeof provider !== 'object') throw Error('Invalid Bot capability provider');
    if (providers.has(capability)) throw Error(`Capability already provided: ${capability}`);
    providers.set(capability, { pluginId, provider });
    return () => providers.get(capability)?.pluginId === pluginId && providers.delete(capability);
  }
  function resolve(capability) { return providers.get(capability)?.provider || null; }
  function inventory() { return [...providers.entries()].map(([capability, value]) => ({ capability, pluginId: value.pluginId })); }
  return Object.freeze({ register, resolve, inventory });
});
