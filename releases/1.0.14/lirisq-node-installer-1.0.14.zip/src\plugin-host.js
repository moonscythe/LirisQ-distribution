/* LirisQ plugin host v1: lifecycle and scoped event permissions.
 * Trusted, already-loaded factories only. No remote code loading or sandbox claim.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQPluginHost = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const ID = /^[a-z0-9][a-z0-9._-]{2,127}$/;
  const EVENTS = Object.freeze({
    'song.queued': 'queue.read',
    'song.lane.changed': 'queue.read',
    'song.started': 'queue.read',
    'song.finished': 'queue.read',
    'queue.paused': 'queue.read',
    'queue.resumed': 'queue.read'
  });
  function createPluginHost({ log = () => {}, approval = () => false, translate = key => String(key) } = {}) {
    const plugins = new Map();
    const subscriptions = new Map();
    function register({ id, version, permissions = [], dependencies = [], factory }) {
      if (typeof id !== 'string' || !ID.test(id)) throw new Error('Invalid plugin ID');
      if (plugins.has(id)) throw new Error('Plugin already registered');
      if (typeof version !== 'string' || !/^\d+\.\d+\.\d+$/.test(version)) throw new Error('Invalid plugin version');
      if (!Array.isArray(permissions) || !permissions.every(p => typeof p === 'string')) throw new Error('Invalid plugin permissions');
      if (!Array.isArray(dependencies) || !dependencies.every(dependency => typeof dependency === 'string' && ID.test(dependency) && dependency !== id)) throw new Error('Invalid plugin dependencies');
      if (typeof factory !== 'function') throw new Error('Trusted plugin factory required');
      plugins.set(id, { id, version, permissions: Object.freeze([...new Set(permissions)]), dependencies: Object.freeze([...new Set(dependencies)]), factory, status: 'registered', cleanup: null });
      return id;
    }
    async function enable(id) {
      const plugin = plugins.get(id);
      if (!plugin) throw new Error('Unknown plugin');
      if (plugin.status !== 'registered') throw new Error('Plugin is not available for enable');
      for (const dependencyId of plugin.dependencies) {
        if (plugins.get(dependencyId)?.status !== 'enabled') throw new Error('Plugin dependency is not enabled: ' + dependencyId);
      }
      if (await approval({ id, version: plugin.version, permissions: [...plugin.permissions] }) !== true) throw new Error('Plugin permissions not approved');
      plugin.status = 'starting';
      const owned = new Set();
      const api = Object.freeze({
        on(event, handler) {
          if (!(event in EVENTS)) throw new Error('Unknown event');
          if (!plugin.permissions.includes(EVENTS[event])) throw new Error('Permission denied: ' + EVENTS[event]);
          if (typeof handler !== 'function') throw new TypeError('Event handler required');
          const record = { id, handler };
          if (!subscriptions.has(event)) subscriptions.set(event, new Set());
          subscriptions.get(event).add(record);
          owned.add(() => subscriptions.get(event).delete(record));
          return () => { subscriptions.get(event).delete(record); };
        },
        t(key, parameters) { return String(translate(String(key), parameters || {})); },
        log(message) { log({ pluginId: id, message: String(message).slice(0, 500) }); }
      });
      try {
        const instance = await plugin.factory(api);
        if (instance && typeof instance.start === 'function') await instance.start();
        plugin.cleanup = async () => {
          try { if (instance && typeof instance.stop === 'function') await instance.stop(); }
          finally { for (const unsubscribe of owned) unsubscribe(); }
        };
        plugin.status = 'enabled';
      } catch (error) {
        for (const unsubscribe of owned) unsubscribe();
        plugin.status = 'registered';
        throw error;
      }
    }
    async function disable(id) {
      const plugin = plugins.get(id);
      if (!plugin) throw new Error('Unknown plugin');
      if (plugin.status !== 'enabled') return false;
      const dependent = [...plugins.values()].find(candidate => candidate.status === 'enabled' && candidate.dependencies.includes(id));
      if (dependent) throw new Error('Disable dependent plugin first: ' + dependent.id);
      plugin.status = 'stopping';
      try { await plugin.cleanup(); }
      finally { plugin.cleanup = null; plugin.status = 'registered'; }
      return true;
    }
    async function unregister(id) {
      const plugin = plugins.get(id);
      if (!plugin) return false;
      if (plugin.status === 'enabled') await disable(id);
      if (plugin.status !== 'registered') throw new Error('Plugin is busy');
      plugins.delete(id);
      return true;
    }
    function emit(event, payload) {
      if (!(event in EVENTS)) throw new Error('Unknown event');
      // Plugin event consumers receive a copy, not the core-owned object.
      for (const subscription of [...(subscriptions.get(event) || [])]) {
        try {
          const safePayload = JSON.parse(JSON.stringify(payload === undefined ? null : payload));
          Promise.resolve(subscription.handler(safePayload)).catch(error => log({ pluginId: subscription.id, error: String(error) }));
        } catch (error) { log({ pluginId: subscription.id, error: String(error) }); }
      }
    }
    function inventory() { return [...plugins.values()].map(({ id, version, permissions, dependencies, status }) => ({ id, version, permissions: [...permissions], dependencies: [...dependencies], status })); }
    return Object.freeze({ register, enable, disable, unregister, emit, inventory });
  }
  return Object.freeze({ createPluginHost, EVENTS });
});
