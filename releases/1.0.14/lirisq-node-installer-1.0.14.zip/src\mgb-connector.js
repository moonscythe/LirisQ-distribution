/* Attach an authenticated MGB MessagePort to LirisQ's trusted plugin host.
   Pairing and secret transfer are intentionally external to this API. */
(function (root, factory) {
  const api = factory(
    typeof module === 'object' && module.exports ? require('./mgb-bridge.js') : root.LirisQMGBBridge,
    typeof module === 'object' && module.exports ? require('./mgb-transport.js') : root.LirisQMGBTransport
  );
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQMGBConnector = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (bridgeModule, transportModule) {
  'use strict';
  async function connect({ port, secret, sessionId, pluginHost, cryptoApi, onError = () => {}, onDisconnect = () => {} }) {
    if (!pluginHost || typeof pluginHost.emit !== 'function') throw new Error('Plugin host required');
    let transport;
    const bridge = bridgeModule.createBridge({
      sessionId,
      emit: (event, payload) => pluginHost.emit(event, payload),
      authenticate: async (context, raw) => {
        if (!transport || context?.authenticatedPort !== port) return false;
        return transport.verify(raw);
      }
    });
    // The bridge accepts an authenticated envelope; extra mac field is ignored by protocol parser.
    transport = await transportModule.createTransport({ port, secret, sessionId, bridge, cryptoApi, onError, onDisconnect });
    return Object.freeze({ close: () => transport.close() });
  }
  return Object.freeze({ connect });
});
