/* Minimal LirisQ Store view. Existing Skin Maker remains untouched.
   Catalog is supplied by the host; absent trust policy means install is disabled. */
(function (root) {
  'use strict';
  function mount() {
    const target = root.document && root.document.querySelector('#store');
    if (!target) return;
    const required = [root.LirisQExtensionContract, root.LirisQArtifactVerifier, root.LirisQExtensionInstaller, root.LirisQStoreHost, root.MGBStoreCatalog];
    const heading = root.document.createElement('h2');
    heading.textContent = 'EXTENSIONS STORE';
    target.append(heading);
    const info = root.document.createElement('p');
    info.textContent = 'Verified packages are staged only. Installing does not activate skins or execute plugins.';
    target.append(info);
    const status = root.document.createElement('p');
    status.setAttribute('role', 'status');
    target.append(status);
    if (required.some(item => !item)) { status.textContent = 'Store integration unavailable: missing module.'; return; }
    const catalog = Array.isArray(root.LIRISQ_STORE_CATALOG) ? root.LIRISQ_STORE_CATALOG : [];
    const trusted = root.LIRISQ_TRUSTED_PUBLISHERS;
    const trustedSet = Array.isArray(trusted) ? new Set(trusted) : new Set();
    const host = root.LirisQStoreHost.createStoreHost({
      catalog: root.MGBStoreCatalog,
      installerModule: root.LirisQExtensionInstaller,
      approve: async manifest => root.confirm('Stage ' + manifest.name + ' v' + manifest.version + ' from ' + manifest.publisherId + '? Permissions: ' + (manifest.permissions || []).join(', ')),
      trustPublisher: async manifest => trustedSet.has(manifest.publisherId)
    });
    const list = root.document.createElement('div');
    target.append(list);
    async function render() {
      list.replaceChildren();
      let products;
      try { products = host.products(catalog); } catch (err) { status.textContent = 'Catalog error: ' + err.message; return; }
      if (!products.length) status.textContent = 'No compatible published extensions available.';
      for (const product of products) {
        const card = root.document.createElement('div');
        const name = root.document.createElement('strong'); name.textContent = product.name + ' · v' + product.version;
        const button = root.document.createElement('button'); button.type = 'button'; button.textContent = 'STAGE VERIFIED PACKAGE';
        button.disabled = !trustedSet.size;
        button.addEventListener('click', async () => {
          button.disabled = true;
          try {
            const result = await product.actions[0].onClick();
            status.textContent = result.id + ' v' + result.version + ' verified and staged (not activated).';
            await renderInventory();
          } catch (err) { status.textContent = 'Install failed: ' + err.message; }
          finally { button.disabled = false; }
        });
        card.append(name, root.document.createTextNode(' '), button); list.append(card);
      }
    }
    const inventoryHeading = root.document.createElement('h3'); inventoryHeading.textContent = 'STAGED PACKAGES';
    target.append(inventoryHeading);
    const inventoryList = root.document.createElement('div'); target.append(inventoryList);
    async function renderInventory() {
      inventoryList.replaceChildren();
      try {
        const records = await host.inventory();
        if (!records.length) { inventoryList.textContent = 'No verified packages staged.'; return; }
        for (const record of records) {
          const item = root.document.createElement('div');
          const label = root.document.createElement('span'); label.textContent = record.id + ' · v' + record.version + ' (' + record.state + ') ';
          item.append(label);
          if (record.rollbackAvailable) {
            const rollback = root.document.createElement('button'); rollback.textContent = 'ROLLBACK';
            rollback.addEventListener('click', async () => {
              try { await host.rollback(record.id); status.textContent = 'Rolled back ' + record.id; await renderInventory(); }
              catch (err) { status.textContent = 'Rollback failed: ' + err.message; }
            });
            item.append(rollback);
          }
          const remove = root.document.createElement('button'); remove.textContent = 'REMOVE';
          remove.addEventListener('click', async () => {
            if (!root.confirm('Remove staged package ' + record.id + '?')) return;
            try { await host.uninstall(record.id); status.textContent = 'Removed ' + record.id; await renderInventory(); }
            catch (err) { status.textContent = 'Removal failed: ' + err.message; }
          });
          item.append(remove); inventoryList.append(item);
        }
      } catch (err) { inventoryList.textContent = 'Inventory unavailable: ' + err.message; }
    }
    render(); renderInventory();
  }
  if (root.document.readyState === 'loading') root.document.addEventListener('DOMContentLoaded', mount);
  else mount();
})(typeof window === 'undefined' ? globalThis : window);
