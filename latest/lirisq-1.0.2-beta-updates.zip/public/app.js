const songUrl = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
const obsOverlayView = window.location.pathname === '/obs-player' ? 'obsPlayerOverlay' : window.location.pathname === '/obs-queue' ? 'obsQueueOverlay' : null;
const freshState = () => ({
  pending: [],
  vip: [],
  standard: []
});
const savedTestFixture = () => ({
  pending: [],
  vip: [
    { id: 'tv1', song: 'Example Song', artist: 'Demo Artist', viewer: 'demo-vip', url: songUrl }, { id: 'tv2', song: 'Afterglow', artist: 'Mira Vale', viewer: 'mira', url: songUrl }, { id: 'tv3', song: 'Fire Escape', artist: 'Vanta Bloom', viewer: 'vantabloom', url: songUrl }, { id: 'tv4', song: 'Night Signal', artist: 'Orion Glass', viewer: 'orionglass', url: songUrl }, { id: 'tv5', song: 'Electric Rain', artist: 'Sable Stereo', viewer: 'sablestereo', url: songUrl }, { id: 'tv6', song: 'Chrome Hearts', artist: 'Sonic Bloom', viewer: 'sonicbloom', url: songUrl }, { id: 'tv7', song: 'Last Exit', artist: 'Mira Atlas', viewer: 'miraatlas', url: songUrl }, { id: 'tv8', song: 'Tangerine Static', artist: 'Neon Acres', viewer: 'neonacres', url: songUrl }, { id: 'tv9', song: 'Citywide', artist: 'Amber Avenue', viewer: 'amberavenue', url: songUrl }, { id: 'tv10', song: 'Ghost Notes', artist: 'Quiet Parade', viewer: 'quietparade', url: songUrl }
  ],
  standard: [
    { id: 'ts1', song: 'Midnight Arcade', artist: 'Kairo', viewer: 'nightowl', url: songUrl }, { id: 'ts2', song: 'Slow Burn', artist: 'The Northline', viewer: 'riverlynn', url: songUrl }, { id: 'ts3', song: 'Silver Static', artist: 'Paper Satellites', viewer: 'echofox', url: songUrl }, { id: 'ts4', song: 'Blue Motel', artist: 'Velvet Comet', viewer: 'velvetcomet', url: songUrl }, { id: 'ts5', song: 'Side Street Glow', artist: 'Juniper FM', viewer: 'juniperfm', url: songUrl }, { id: 'ts6', song: 'Polaroid Summer', artist: 'Nova Habits', viewer: 'novahabits', url: songUrl }, { id: 'ts7', song: 'Satellite Heart', artist: 'Westward Static', viewer: 'westwardstatic', url: songUrl }, { id: 'ts8', song: 'Golden Hour Drive', artist: 'Motel Mirage', viewer: 'motelmirage', url: songUrl }, { id: 'ts9', song: 'Soft Landing', artist: 'Familiar Sky', viewer: 'familiarsky', url: songUrl }, { id: 'ts10', song: 'Summer Receiver', artist: 'Coastline Color', viewer: 'coastlinecolor', url: songUrl }
  ]
});
let state = storedJson('lirisq-test-queue', null) || freshState();
state.pending ||= [];
let history = [];
let dragging = null;
const queuePlaybackStateKey = 'lirisq-queue-playback-state-v1';
const savedQueuePlayback = storedJson(queuePlaybackStateKey, {});
let paused = savedQueuePlayback.paused === true;
// A queued item is not playing until a playback control explicitly starts it.
// This restores only an explicit local queue selection—not test data or MGB capture.
let activeQueuePlaybackId = typeof savedQueuePlayback.activeId === 'string' ? savedQueuePlayback.activeId : null;
let displayMonth = new Date();
let selectedCalendarDate = null;
let queueViewportExpanded = false;
const playbackModeKey = 'lirisq-playback-mode-v1';
const randomArtistKey = 'lirisq-random-last-artist-v1';
const mgbCaptureKey = 'lirisq-mgb-captured-playback-v1';
let playbackMode = ['queue', 'random', 'free-play'].includes(localStorage.getItem(playbackModeKey)) ? localStorage.getItem(playbackModeKey) : 'queue';
let lastRandomArtist = localStorage.getItem(randomArtistKey) || '';
// Capture is live-session data. Never resurrect a stale song after a reload,
// disconnect, or removed pairing; MGB will send the current track again.
localStorage.removeItem(mgbCaptureKey);
let mgbCapturedPlayback = { current: null, playlist: [] };
let shows;
let activeShowId;
const liveQueueStyle = document.createElement('style');
liveQueueStyle.textContent = `.cassette-liner{position:relative}.queue-viewport-expand{position:absolute;z-index:8;top:14px;right:14px;width:30px;height:30px;padding:0;border:1px solid color-mix(in srgb,var(--line) 80%,var(--ink));background:color-mix(in srgb,var(--panel) 78%,transparent);color:var(--ink);font:700 18px/26px Arial;opacity:.2;transition:opacity .18s,background .18s,border-color .18s,color .18s}.cassette-liner:hover .queue-viewport-expand,.queue-viewport-expand:focus-visible{opacity:1;border-color:var(--cyan);background:color-mix(in srgb,var(--panel) 92%,transparent);color:var(--cyan)}.queue-viewport-expanded .queue-viewport-expand{opacity:.65;color:var(--cyan);border-color:var(--cyan)}`;
document.head.append(liveQueueStyle);
const obsOverlayStyle = document.createElement('style');
obsOverlayStyle.textContent = `body.obs-overlay{background:transparent!important;min-width:0}body.obs-overlay header,body.obs-overlay nav,body.obs-overlay #toast,body.obs-overlay main>.view:not(.obs-overlay){display:none!important}body.obs-overlay main{max-width:none;margin:0;padding:0}.obs-overlay{padding:0;background:transparent}.obs-player-surface{margin:0!important;padding:0!important;background:transparent!important;box-shadow:none!important;min-width:0!important}.obs-player-surface .cassette-stage{width:100%;max-width:none;aspect-ratio:3/2}.obs-player-surface .cassette-label .song-name{overflow-wrap:anywhere}.obs-queue-surface{box-sizing:border-box;min-width:900px;min-height:600px;padding:72px 90px!important;background-image:url("skins/cassette/assets/cassette-liner.png");background-position:center;background-size:100% 100%;background-repeat:no-repeat}.obs-queue-surface .queue-head{margin-bottom:8px}.obs-queue-surface .queue-head h2{font-size:28px}.obs-queue-surface .queue-note{display:block;margin:-2px 0 20px;font-size:19px}.obs-queue-columns{display:grid;grid-template-columns:1fr 1fr;gap:36px}.obs-queue-columns .queue-list{margin:0}.obs-queue-columns .row{font-size:18px}`;
document.head.append(obsOverlayStyle);

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function profile(name) { return `https://www.twitch.tv/${encodeURIComponent(String(name || '').replace(/^@/, ''))}`; }
function persistQueuePlayback() { localStorage.setItem(queuePlaybackStateKey, JSON.stringify({ activeId:activeQueuePlaybackId, paused })); }
function save() { localStorage.setItem('lirisq-test-queue', JSON.stringify(state)); const active = shows?.find(show => show.id === activeShowId); if (active) { active.queue = clone(state); saveShows(); } if (window.LirisQStreamNotificationsPlugin?.status().active) window.LirisQStreamNotificationsPlugin.reconcileQueue(activeShowId,state); }
/* Trusted built-in plugin host. Does not load downloaded plugin artifacts. */
const lirisqPluginHost = window.LirisQPluginHost?.createPluginHost({
  approval: async plugin => {
    const approvals = JSON.parse(localStorage.getItem('lirisq-plugin-approvals-v1') || '{}');
    return approvals[plugin.id]?.version === plugin.version &&
      JSON.stringify(approvals[plugin.id]?.permissions) === JSON.stringify(plugin.permissions);
  },
  log: entry => console.info('[LirisQ plugin]', entry),
  translate: (key, parameters) => window.LIRISQ_I18N?.t(key, parameters) || key
});
const localePreferenceKey = 'lirisq-locale-v1';
const createLocalI18n = window.LirisQI18n?.createI18n || (options => {
  const packs = new Map(); const missing = new Set(); let locale = String(options.locale || 'en').toLowerCase(); const fallback = String(options.fallbackLocale || 'en').toLowerCase();
  const candidates = value => [...new Set([value, value.split('-')[0], fallback, fallback.split('-')[0]])];
  const lookup = (messages, key) => messages && Object.hasOwn(messages, key) ? messages[key] : String(key).split('.').reduce((value, part) => value && typeof value === 'object' ? value[part] : undefined, messages);
  return Object.freeze({ register(language, messages) { const key = String(language).toLowerCase(); packs.set(key, Object.freeze({ ...(packs.get(key) || {}), ...messages })); }, setLocale(value) { locale = String(value || fallback).toLowerCase(); return locale; }, getLocale: () => locale, availableLocales: () => [...packs.keys()], missingKeys: () => [...missing], t(key, parameters = {}) { let message; for (const candidate of candidates(locale)) { message = lookup(packs.get(candidate), key); if (typeof message === 'string') break; } if (typeof message !== 'string') { missing.add(String(key)); return String(key); } return message.replace(/\{([A-Za-z0-9_.-]+)\}/g, (match, name) => Object.hasOwn(parameters, name) ? String(parameters[name]) : match); } });
});
const lirisqI18n = createLocalI18n({ locale: localStorage.getItem(localePreferenceKey) || navigator.language, fallbackLocale: 'en' });
lirisqI18n?.register('en', {
  'configuration.language.title': 'DISPLAY LANGUAGE', 'configuration.language.description': 'Choose the language for supported LirisQ controls. Song titles, chat messages, and platform data are never translated automatically.',
  'plugins.manager.title': 'PLUGIN MANAGER', 'plugins.manager.description': 'INSTALL, ENABLE, DISABLE, OR UNINSTALL PLUGINS HERE. BUILT-IN BOT CORE FEATURES CAN BE ENABLED OR DISABLED, BUT STAY INSTALLED.',
  'plugins.category.general': 'GENERAL PLUGINS', 'plugins.category.core': 'BOT CORE', 'plugins.category.adapters': 'PLATFORM ADAPTERS', 'plugins.category.features': 'BOT FEATURES', 'plugins.category.system': 'SYSTEM INTEGRATIONS', 'plugins.install': 'INSTALL', 'plugins.enabled': 'ENABLED', 'plugins.disabled': 'DISABLED', 'plugins.uninstall': 'UNINSTALL'
});
lirisqI18n?.register('es', {
  'configuration.language.title': 'IDIOMA DE PANTALLA', 'configuration.language.description': 'Elige el idioma para los controles compatibles de LirisQ. Los títulos de canciones, mensajes de chat y datos de plataformas nunca se traducen automáticamente.',
  'plugins.manager.title': 'ADMINISTRADOR DE COMPLEMENTOS', 'plugins.manager.description': 'INSTALA, ACTIVA, DESACTIVA O DESINSTALA COMPLEMENTOS AQUÍ. LAS FUNCIONES INTEGRADAS DEL NÚCLEO DEL BOT PUEDEN ACTIVARSE O DESACTIVARSE, PERO PERMANECEN INSTALADAS.',
  'plugins.category.general': 'COMPLEMENTOS GENERALES', 'plugins.category.core': 'NÚCLEO DEL BOT', 'plugins.category.adapters': 'ADAPTADORES DE PLATAFORMA', 'plugins.category.features': 'FUNCIONES DEL BOT', 'plugins.category.system': 'INTEGRACIONES DEL SISTEMA', 'plugins.install': 'INSTALAR', 'plugins.enabled': 'ACTIVADO', 'plugins.disabled': 'DESACTIVADO', 'plugins.uninstall': 'DESINSTALAR'
});
lirisqI18n?.register('fr', {
  'configuration.language.title': "LANGUE D’AFFICHAGE", 'configuration.language.description': 'Choisissez la langue des commandes LirisQ prises en charge. Les titres de chansons, les messages de chat et les données de plateforme ne sont jamais traduits automatiquement.',
  'plugins.manager.title': 'GESTIONNAIRE DE MODULES', 'plugins.manager.description': 'INSTALLEZ, ACTIVEZ, DÉSACTIVEZ OU DÉSINSTALLEZ DES MODULES ICI. LES FONCTIONS INTÉGRÉES DU CŒUR DU BOT PEUVENT ÊTRE ACTIVÉES OU DÉSACTIVÉES, MAIS RESTENT INSTALLÉES.',
  'plugins.category.general': 'MODULES GÉNÉRAUX', 'plugins.category.core': 'CŒUR DU BOT', 'plugins.category.adapters': 'ADAPTATEURS DE PLATEFORME', 'plugins.category.features': 'FONCTIONS DU BOT', 'plugins.category.system': 'INTÉGRATIONS SYSTÈME', 'plugins.install': 'INSTALLER', 'plugins.enabled': 'ACTIVÉ', 'plugins.disabled': 'DÉSACTIVÉ', 'plugins.uninstall': 'DÉSINSTALLER'
});
lirisqI18n?.register('de', {
  'configuration.language.title': 'ANZEIGESPRACHE', 'configuration.language.description': 'Wähle die Sprache für unterstützte LirisQ-Bedienelemente. Songtitel, Chat-Nachrichten und Plattformdaten werden nie automatisch übersetzt.',
  'plugins.manager.title': 'PLUGIN-VERWALTUNG', 'plugins.manager.description': 'INSTALLIERE, AKTIVIERE, DEAKTIVIERE ODER DEINSTALLIERE PLUGINS HIER. INTEGRIERTE BOT-KERNFUNKTIONEN KÖNNEN AKTIVIERT ODER DEAKTIVIERT WERDEN, BLEIBEN ABER INSTALLIERT.',
  'plugins.category.general': 'ALLGEMEINE PLUGINS', 'plugins.category.core': 'BOT-KERN', 'plugins.category.adapters': 'PLATTFORM-ADAPTER', 'plugins.category.features': 'BOT-FUNKTIONEN', 'plugins.category.system': 'SYSTEMINTEGRATIONEN', 'plugins.install': 'INSTALLIEREN', 'plugins.enabled': 'AKTIVIERT', 'plugins.disabled': 'DEAKTIVIERT', 'plugins.uninstall': 'DEINSTALLIEREN'
});
lirisqI18n?.register('pt', {
  'configuration.language.title': 'IDIOMA DE EXIBIÇÃO', 'configuration.language.description': 'Escolha o idioma dos controles compatíveis do LirisQ. Títulos de músicas, mensagens de chat e dados da plataforma nunca são traduzidos automaticamente.',
  'plugins.manager.title': 'GERENCIADOR DE PLUGINS', 'plugins.manager.description': 'INSTALE, ATIVE, DESATIVE OU DESINSTALE PLUGINS AQUI. OS RECURSOS INTEGRADOS DO NÚCLEO DO BOT PODEM SER ATIVADOS OU DESATIVADOS, MAS PERMANECEM INSTALADOS.',
  'plugins.category.general': 'PLUGINS GERAIS', 'plugins.category.core': 'NÚCLEO DO BOT', 'plugins.category.adapters': 'ADAPTADORES DE PLATAFORMA', 'plugins.category.features': 'RECURSOS DO BOT', 'plugins.category.system': 'INTEGRAÇÕES DO SISTEMA', 'plugins.install': 'INSTALAR', 'plugins.enabled': 'ATIVADO', 'plugins.disabled': 'DESATIVADO', 'plugins.uninstall': 'DESINSTALAR'
});
const sharedUiPacks = Object.freeze({
  en: { 'ui.queue': 'Queue', 'ui.player': 'Player Mode', 'ui.shows': 'Shows', 'ui.configuration': 'Configuration', 'ui.analytics': 'Analytics', 'ui.history': 'Song History', 'ui.notifications': 'Notifications', 'ui.vipQueue': 'VIP QUEUE', 'ui.standardQueue': 'STANDARD QUEUE', 'ui.manualEntry': 'MANUAL ENTRY', 'ui.songTitle': 'SONG TITLE', 'ui.artist': 'ARTIST', 'ui.songUrl': 'SONG URL', 'ui.addStandard': 'ADD TO STANDARD', 'ui.undo': 'UNDO', 'ui.optionalPlugin': 'OPTIONAL PLUGIN', 'ui.refresh': 'REFRESH', 'ui.save': 'SAVE', 'ui.clear': 'CLEAR', 'ui.export': 'EXPORT CSV', 'ui.today': 'TODAY', 'ui.addShow': '+ ADD SHOW', 'ui.streamerView': 'STREAMER VIEW', 'ui.viewerView': 'VIEWER VIEW', 'ui.next': 'NEXT', 'ui.pause': 'PAUSE [SPACE]', 'ui.configurationTitle': 'CONFIGURATION', 'ui.testData': 'TEST DATA', 'ui.loadTestData': 'LOAD TEST DATA', 'ui.wipeTestData': 'WIPE TEST DATA', 'ui.enablePlugin': 'ENABLE PLUGIN', 'ui.disabled': 'Plugin disabled.' },
  es: { 'ui.queue': 'Cola', 'ui.player': 'Modo de reproducción', 'ui.shows': 'Shows', 'ui.configuration': 'Configuración', 'ui.analytics': 'Analíticas', 'ui.history': 'Historial de canciones', 'ui.notifications': 'Notificaciones', 'ui.vipQueue': 'COLA VIP', 'ui.standardQueue': 'COLA ESTÁNDAR', 'ui.manualEntry': 'ENTRADA MANUAL', 'ui.songTitle': 'TÍTULO DE LA CANCIÓN', 'ui.artist': 'ARTISTA', 'ui.songUrl': 'URL DE LA CANCIÓN', 'ui.addStandard': 'AÑADIR A ESTÁNDAR', 'ui.undo': 'DESHACER', 'ui.optionalPlugin': 'COMPLEMENTO OPCIONAL', 'ui.refresh': 'ACTUALIZAR', 'ui.save': 'GUARDAR', 'ui.clear': 'BORRAR', 'ui.export': 'EXPORTAR CSV', 'ui.today': 'HOY', 'ui.addShow': '+ AÑADIR SHOW', 'ui.streamerView': 'VISTA DEL STREAMER', 'ui.viewerView': 'VISTA DEL ESPECTADOR', 'ui.next': 'SIGUIENTE', 'ui.pause': 'PAUSA [ESPACIO]', 'ui.configurationTitle': 'CONFIGURACIÓN', 'ui.testData': 'DATOS DE PRUEBA', 'ui.loadTestData': 'CARGAR DATOS DE PRUEBA', 'ui.wipeTestData': 'BORRAR DATOS DE PRUEBA', 'ui.enablePlugin': 'ACTIVAR COMPLEMENTO', 'ui.disabled': 'Complemento desactivado.' },
  fr: { 'ui.queue': 'File d’attente', 'ui.player': 'Mode lecteur', 'ui.shows': 'Émissions', 'ui.configuration': 'Configuration', 'ui.analytics': 'Analyses', 'ui.history': 'Historique des chansons', 'ui.notifications': 'Notifications', 'ui.vipQueue': 'FILE VIP', 'ui.standardQueue': 'FILE STANDARD', 'ui.manualEntry': 'SAISIE MANUELLE', 'ui.songTitle': 'TITRE DE LA CHANSON', 'ui.artist': 'ARTISTE', 'ui.songUrl': 'URL DE LA CHANSON', 'ui.addStandard': 'AJOUTER À LA FILE STANDARD', 'ui.undo': 'ANNULER', 'ui.optionalPlugin': 'MODULE OPTIONNEL', 'ui.refresh': 'ACTUALISER', 'ui.save': 'ENREGISTRER', 'ui.clear': 'EFFACER', 'ui.export': 'EXPORTER CSV', 'ui.today': 'AUJOURD’HUI', 'ui.addShow': '+ AJOUTER UNE ÉMISSION', 'ui.streamerView': 'VUE STREAMER', 'ui.viewerView': 'VUE SPECTATEUR', 'ui.next': 'SUIVANT', 'ui.pause': 'PAUSE [ESPACE]', 'ui.configurationTitle': 'CONFIGURATION', 'ui.testData': 'DONNÉES DE TEST', 'ui.loadTestData': 'CHARGER LES DONNÉES DE TEST', 'ui.wipeTestData': 'EFFACER LES DONNÉES DE TEST', 'ui.enablePlugin': 'ACTIVER LE MODULE', 'ui.disabled': 'Module désactivé.' },
  de: { 'ui.queue': 'Warteschlange', 'ui.player': 'Player-Modus', 'ui.shows': 'Shows', 'ui.configuration': 'Konfiguration', 'ui.analytics': 'Analysen', 'ui.history': 'Songverlauf', 'ui.notifications': 'Benachrichtigungen', 'ui.vipQueue': 'VIP-WARTESCHLANGE', 'ui.standardQueue': 'STANDARD-WARTESCHLANGE', 'ui.manualEntry': 'MANUELLE EINGABE', 'ui.songTitle': 'SONGTITEL', 'ui.artist': 'KÜNSTLER', 'ui.songUrl': 'SONG-URL', 'ui.addStandard': 'ZUR STANDARD-WARTESCHLANGE HINZUFÜGEN', 'ui.undo': 'RÜCKGÄNGIG', 'ui.optionalPlugin': 'OPTIONALES PLUGIN', 'ui.refresh': 'AKTUALISIEREN', 'ui.save': 'SPEICHERN', 'ui.clear': 'LÖSCHEN', 'ui.export': 'CSV EXPORTIEREN', 'ui.today': 'HEUTE', 'ui.addShow': '+ SHOW HINZUFÜGEN', 'ui.streamerView': 'STREAMER-ANSICHT', 'ui.viewerView': 'ZUSCHAUER-ANSICHT', 'ui.next': 'WEITER', 'ui.pause': 'PAUSE [LEERTASTE]', 'ui.configurationTitle': 'KONFIGURATION', 'ui.testData': 'TESTDATEN', 'ui.loadTestData': 'TESTDATEN LADEN', 'ui.wipeTestData': 'TESTDATEN LÖSCHEN', 'ui.enablePlugin': 'PLUGIN AKTIVIEREN', 'ui.disabled': 'Plugin deaktiviert.' },
  pt: { 'ui.queue': 'Fila', 'ui.player': 'Modo do player', 'ui.shows': 'Shows', 'ui.configuration': 'Configuração', 'ui.analytics': 'Análises', 'ui.history': 'Histórico de músicas', 'ui.notifications': 'Notificações', 'ui.vipQueue': 'FILA VIP', 'ui.standardQueue': 'FILA PADRÃO', 'ui.manualEntry': 'ENTRADA MANUAL', 'ui.songTitle': 'TÍTULO DA MÚSICA', 'ui.artist': 'ARTISTA', 'ui.songUrl': 'URL DA MÚSICA', 'ui.addStandard': 'ADICIONAR À FILA PADRÃO', 'ui.undo': 'DESFAZER', 'ui.optionalPlugin': 'PLUGIN OPCIONAL', 'ui.refresh': 'ATUALIZAR', 'ui.save': 'SALVAR', 'ui.clear': 'LIMPAR', 'ui.export': 'EXPORTAR CSV', 'ui.today': 'HOJE', 'ui.addShow': '+ ADICIONAR SHOW', 'ui.streamerView': 'VISÃO DO STREAMER', 'ui.viewerView': 'VISÃO DO ESPECTADOR', 'ui.next': 'PRÓXIMA', 'ui.pause': 'PAUSAR [ESPAÇO]', 'ui.configurationTitle': 'CONFIGURAÇÃO', 'ui.testData': 'DADOS DE TESTE', 'ui.loadTestData': 'CARREGAR DADOS DE TESTE', 'ui.wipeTestData': 'APAGAR DADOS DE TESTE', 'ui.enablePlugin': 'ATIVAR PLUGIN', 'ui.disabled': 'Plugin desativado.' }
});
Object.entries(sharedUiPacks).forEach(([locale, messages]) => lirisqI18n?.register(locale, messages));
const configurationUiPacks = Object.freeze({
  en: { 'ui.main': 'MAIN', 'ui.chatBot': 'CHAT BOT', 'ui.skins': 'SKINS', 'ui.plugins': 'PLUGINS', 'ui.playMode': 'PLAY MODE', 'ui.queueMode': 'QUEUE', 'ui.random': 'RANDOM', 'ui.freePlay': 'FREE PLAY', 'ui.timezone': 'BROADCAST TIME ZONE', 'ui.mgb': 'MUSIC GAME BRIDGE', 'ui.obs': 'OBS CONFIGURATION', 'ui.platforms': 'PLATFORM CONFIGURATIONS', 'ui.testReset': 'TEST DATA & RESET', 'ui.streamNotifications': 'STREAM NOTIFICATIONS', 'ui.calendarExport': 'CALENDAR EXPORT', 'ui.discord': 'DISCORD ANNOUNCEMENTS', 'ui.xShows': 'X SHOW ANNOUNCER', 'ui.commandAliases': 'COMMAND ALIASES', 'ui.addCalendar': 'ADD TO CALENDAR', 'ui.exportTo': 'EXPORT TO', 'ui.windowsOutlook': 'WINDOWS / OUTLOOK', 'ui.googleAndroid': 'GOOGLE / ANDROID', 'ui.appleIos': 'APPLE / iOS', 'ui.other': 'OTHER' },
  es: { 'ui.main': 'PRINCIPAL', 'ui.chatBot': 'CHATBOT', 'ui.skins': 'SKINS', 'ui.plugins': 'COMPLEMENTOS', 'ui.playMode': 'MODO DE REPRODUCCIÓN', 'ui.queueMode': 'COLA', 'ui.random': 'ALEATORIO', 'ui.freePlay': 'REPRODUCCIÓN LIBRE', 'ui.timezone': 'ZONA HORARIA DE TRANSMISIÓN', 'ui.mgb': 'MUSIC GAME BRIDGE', 'ui.obs': 'CONFIGURACIÓN DE OBS', 'ui.platforms': 'CONFIGURACIONES DE PLATAFORMA', 'ui.testReset': 'DATOS DE PRUEBA Y RESTABLECIMIENTO', 'ui.streamNotifications': 'NOTIFICACIONES DE TRANSMISIÓN', 'ui.calendarExport': 'EXPORTACIÓN DE CALENDARIO', 'ui.discord': 'ANUNCIOS DE DISCORD', 'ui.xShows': 'ANUNCIADOR DE SHOWS EN X', 'ui.commandAliases': 'ALIASES DE COMANDOS', 'ui.addCalendar': 'AÑADIR AL CALENDARIO', 'ui.exportTo': 'EXPORTAR A', 'ui.windowsOutlook': 'WINDOWS / OUTLOOK', 'ui.googleAndroid': 'GOOGLE / ANDROID', 'ui.appleIos': 'APPLE / iOS', 'ui.other': 'OTRO' },
  fr: { 'ui.main': 'PRINCIPAL', 'ui.chatBot': 'CHATBOT', 'ui.skins': 'SKINS', 'ui.plugins': 'MODULES', 'ui.playMode': 'MODE DE LECTURE', 'ui.queueMode': 'FILE', 'ui.random': 'ALÉATOIRE', 'ui.freePlay': 'LECTURE LIBRE', 'ui.timezone': 'FUSEAU HORAIRE DE DIFFUSION', 'ui.mgb': 'MUSIC GAME BRIDGE', 'ui.obs': 'CONFIGURATION OBS', 'ui.platforms': 'CONFIGURATIONS DE PLATEFORME', 'ui.testReset': 'DONNÉES DE TEST ET RÉINITIALISATION', 'ui.streamNotifications': 'NOTIFICATIONS DE STREAM', 'ui.calendarExport': 'EXPORTATION DE CALENDRIER', 'ui.discord': 'ANNONCES DISCORD', 'ui.xShows': 'ANNONCEUR DE SHOWS X', 'ui.commandAliases': 'ALIAS DE COMMANDES', 'ui.addCalendar': 'AJOUTER AU CALENDRIER', 'ui.exportTo': 'EXPORTER VERS', 'ui.windowsOutlook': 'WINDOWS / OUTLOOK', 'ui.googleAndroid': 'GOOGLE / ANDROID', 'ui.appleIos': 'APPLE / iOS', 'ui.other': 'AUTRE' },
  de: { 'ui.main': 'HAUPTSEITE', 'ui.chatBot': 'CHATBOT', 'ui.skins': 'SKINS', 'ui.plugins': 'PLUGINS', 'ui.playMode': 'WIEDERGABEMODUS', 'ui.queueMode': 'WARTESCHLANGE', 'ui.random': 'ZUFÄLLIG', 'ui.freePlay': 'FREIES ABSPIELEN', 'ui.timezone': 'SENDEZEITZONE', 'ui.mgb': 'MUSIC GAME BRIDGE', 'ui.obs': 'OBS-KONFIGURATION', 'ui.platforms': 'PLATTFORMKONFIGURATIONEN', 'ui.testReset': 'TESTDATEN UND ZURÜCKSETZEN', 'ui.streamNotifications': 'STREAM-BENACHRICHTIGUNGEN', 'ui.calendarExport': 'KALENDEREXPORT', 'ui.discord': 'DISCORD-ANKÜNDIGUNGEN', 'ui.xShows': 'X-SHOW-ANKÜNDIGER', 'ui.commandAliases': 'BEFEHLSALIASE', 'ui.addCalendar': 'ZUM KALENDER HINZUFÜGEN', 'ui.exportTo': 'EXPORTIEREN NACH', 'ui.windowsOutlook': 'WINDOWS / OUTLOOK', 'ui.googleAndroid': 'GOOGLE / ANDROID', 'ui.appleIos': 'APPLE / iOS', 'ui.other': 'ANDERE' },
  pt: { 'ui.main': 'PRINCIPAL', 'ui.chatBot': 'CHATBOT', 'ui.skins': 'SKINS', 'ui.plugins': 'PLUGINS', 'ui.playMode': 'MODO DE REPRODUÇÃO', 'ui.queueMode': 'FILA', 'ui.random': 'ALEATÓRIO', 'ui.freePlay': 'REPRODUÇÃO LIVRE', 'ui.timezone': 'FUSO HORÁRIO DA TRANSMISSÃO', 'ui.mgb': 'MUSIC GAME BRIDGE', 'ui.obs': 'CONFIGURAÇÃO DO OBS', 'ui.platforms': 'CONFIGURAÇÕES DE PLATAFORMA', 'ui.testReset': 'DADOS DE TESTE E REDEFINIÇÃO', 'ui.streamNotifications': 'NOTIFICAÇÕES DA TRANSMISSÃO', 'ui.calendarExport': 'EXPORTAÇÃO DE CALENDÁRIO', 'ui.discord': 'ANÚNCIOS DO DISCORD', 'ui.xShows': 'ANUNCIADOR DE SHOWS NO X', 'ui.commandAliases': 'ALIAS DE COMANDOS', 'ui.addCalendar': 'ADICIONAR AO CALENDÁRIO', 'ui.exportTo': 'EXPORTAR PARA', 'ui.windowsOutlook': 'WINDOWS / OUTLOOK', 'ui.googleAndroid': 'GOOGLE / ANDROID', 'ui.appleIos': 'APPLE / iOS', 'ui.other': 'OUTRO' }
});
Object.entries(configurationUiPacks).forEach(([locale, messages]) => lirisqI18n?.register(locale, messages));
const skinUiPacks = Object.freeze({
  en: { 'skins.manager': 'SKIN MANAGER', 'skins.packs': 'SKIN PACKS', 'skins.skins': 'SKINS', 'skins.openMaker': 'OPEN SKIN MAKER', 'skins.install': 'INSTALL', 'skins.reinstall': 'REINSTALL', 'skins.uninstall': 'UNINSTALL', 'skins.selected': 'SELECTED', 'skins.select': 'SELECT', 'skins.installed': 'INSTALLED', 'skins.notInstalled': 'NOT INSTALLED', 'skins.ready': 'READY TO SELECT', 'skins.installPack': 'INSTALL ITS SKIN PACK TO USE THIS SKIN', 'skins.count': '{count} SKINS' },
  es: { 'skins.manager': 'ADMINISTRADOR DE SKINS', 'skins.packs': 'PAQUETES DE SKINS', 'skins.skins': 'SKINS', 'skins.openMaker': 'ABRIR CREADOR DE SKINS', 'skins.install': 'INSTALAR', 'skins.reinstall': 'REINSTALAR', 'skins.uninstall': 'DESINSTALAR', 'skins.selected': 'SELECCIONADO', 'skins.select': 'SELECCIONAR', 'skins.installed': 'INSTALADO', 'skins.notInstalled': 'NO INSTALADO', 'skins.ready': 'LISTO PARA SELECCIONAR', 'skins.installPack': 'INSTALA SU PAQUETE DE SKINS PARA USAR ESTA SKIN', 'skins.count': '{count} SKINS' },
  fr: { 'skins.manager': 'GESTIONNAIRE DE SKINS', 'skins.packs': 'PACKS DE SKINS', 'skins.skins': 'SKINS', 'skins.openMaker': 'OUVRIR LE CRÉATEUR DE SKINS', 'skins.install': 'INSTALLER', 'skins.reinstall': 'RÉINSTALLER', 'skins.uninstall': 'DÉSINSTALLER', 'skins.selected': 'SÉLECTIONNÉ', 'skins.select': 'SÉLECTIONNER', 'skins.installed': 'INSTALLÉ', 'skins.notInstalled': 'NON INSTALLÉ', 'skins.ready': 'PRÊT À SÉLECTIONNER', 'skins.installPack': 'INSTALLEZ SON PACK DE SKINS POUR UTILISER CE SKIN', 'skins.count': '{count} SKINS' },
  de: { 'skins.manager': 'SKIN-VERWALTUNG', 'skins.packs': 'SKIN-PAKETE', 'skins.skins': 'SKINS', 'skins.openMaker': 'SKIN-ERSTELLER ÖFFNEN', 'skins.install': 'INSTALLIEREN', 'skins.reinstall': 'NEU INSTALLIEREN', 'skins.uninstall': 'DEINSTALLIEREN', 'skins.selected': 'AUSGEWÄHLT', 'skins.select': 'AUSWÄHLEN', 'skins.installed': 'INSTALLIERT', 'skins.notInstalled': 'NICHT INSTALLIERT', 'skins.ready': 'BEREIT ZUM AUSWÄHLEN', 'skins.installPack': 'INSTALLIERE DAS SKIN-PAKET, UM DIESEN SKIN ZU VERWENDEN', 'skins.count': '{count} SKINS' },
  pt: { 'skins.manager': 'GERENCIADOR DE SKINS', 'skins.packs': 'PACOTES DE SKINS', 'skins.skins': 'SKINS', 'skins.openMaker': 'ABRIR CRIADOR DE SKINS', 'skins.install': 'INSTALAR', 'skins.reinstall': 'REINSTALAR', 'skins.uninstall': 'DESINSTALAR', 'skins.selected': 'SELECIONADO', 'skins.select': 'SELECIONAR', 'skins.installed': 'INSTALADO', 'skins.notInstalled': 'NÃO INSTALADO', 'skins.ready': 'PRONTO PARA SELECIONAR', 'skins.installPack': 'INSTALE O PACOTE DE SKINS PARA USAR ESTA SKIN', 'skins.count': '{count} SKINS' }
});
Object.entries(skinUiPacks).forEach(([locale, messages]) => lirisqI18n?.register(locale, messages));
const pluginUiPacks = Object.freeze({
  en: { 'plugins.genericDescription': 'Adds the {name} capability to LirisQ. Open its configuration to manage its specific settings.', 'plugins.devNote': 'This plugin remains in development until its live authorization, inbound event verification, and delivery support are complete.' },
  es: { 'plugins.genericDescription': 'Añade la capacidad {name} a LirisQ. Abre su configuración para administrar sus ajustes específicos.', 'plugins.devNote': 'Este complemento permanece en desarrollo hasta completar la autorización en vivo, la verificación de eventos entrantes y la entrega.' },
  fr: { 'plugins.genericDescription': 'Ajoute la fonction {name} à LirisQ. Ouvrez sa configuration pour gérer ses paramètres spécifiques.', 'plugins.devNote': 'Ce module reste en développement jusqu’à ce que son autorisation en direct, la vérification des événements entrants et la livraison soient terminées.' },
  de: { 'plugins.genericDescription': 'Fügt LirisQ die Funktion {name} hinzu. Öffne die Konfiguration, um die jeweiligen Einstellungen zu verwalten.', 'plugins.devNote': 'Dieses Plugin bleibt in Entwicklung, bis Live-Autorisierung, eingehende Ereignisprüfung und Zustellung vollständig sind.' },
  pt: { 'plugins.genericDescription': 'Adiciona o recurso {name} ao LirisQ. Abra a configuração para gerenciar as opções específicas.', 'plugins.devNote': 'Este plugin permanece em desenvolvimento até que a autorização ao vivo, a verificação de eventos recebidos e a entrega sejam concluídas.' }
});
Object.entries(pluginUiPacks).forEach(([locale, messages]) => lirisqI18n?.register(locale, messages));
const chatbotUiPacks = Object.freeze({
  en: { 'chat.features': 'CHAT BOT FEATURES', 'chat.featuresDescription': 'These built-in Bot Core features are configured here. Use their state toggle to enable or disable them.', 'chat.commands': 'CHAT BOT COMMANDS', 'chat.commandsDescription': 'Enable only the commands your chat bot may handle. Viewer commands are available to chat; broadcaster commands require broadcaster or allowed moderator permission. Changes apply to Bot Core immediately.', 'chat.viewerCommands': 'VIEWER COMMANDS', 'chat.viewerDescription': 'Available to identified viewers when enabled.', 'chat.broadcasterCommands': 'BROADCASTER COMMANDS', 'chat.broadcasterDescription': 'Disabled by default. Broadcasters may use them; grant verified moderators access per command.', 'chat.enableCommand': 'ENABLE COMMAND', 'chat.allowModerators': 'ALLOW MODERATORS', 'chat.variables': 'Variables: {variables}.', 'chat.noVariables': 'No variables.', 'chat.rules': '!RULES MANAGEMENT', 'chat.saveRules': 'SAVE RULES', 'chat.command.generic': 'Configure the {command} chat command.' },
  es: { 'chat.features': 'FUNCIONES DEL CHATBOT', 'chat.featuresDescription': 'Aquí se configuran las funciones integradas del núcleo del bot. Usa su interruptor para activarlas o desactivarlas.', 'chat.commands': 'COMANDOS DEL CHATBOT', 'chat.commandsDescription': 'Activa solo los comandos que el chatbot puede manejar. Los comandos de espectadores están disponibles en el chat; los de emisores requieren permiso de emisor o moderador autorizado.', 'chat.viewerCommands': 'COMANDOS DE ESPECTADOR', 'chat.viewerDescription': 'Disponibles para espectadores identificados cuando están activados.', 'chat.broadcasterCommands': 'COMANDOS DE EMISOR', 'chat.broadcasterDescription': 'Desactivados de forma predeterminada. Los emisores pueden usarlos; concede acceso a moderadores verificados por comando.', 'chat.enableCommand': 'ACTIVAR COMANDO', 'chat.allowModerators': 'PERMITIR MODERADORES', 'chat.variables': 'Variables: {variables}.', 'chat.noVariables': 'Sin variables.', 'chat.rules': 'GESTIÓN DE !RULES', 'chat.saveRules': 'GUARDAR REGLAS', 'chat.command.generic': 'Configura el comando de chat {command}.' },
  fr: { 'chat.features': 'FONCTIONNALITÉS DU CHATBOT', 'chat.featuresDescription': 'Les fonctionnalités intégrées du noyau du bot se configurent ici. Utilisez leur interrupteur pour les activer ou les désactiver.', 'chat.commands': 'COMMANDES DU CHATBOT', 'chat.commandsDescription': 'Activez uniquement les commandes que votre chatbot peut gérer. Les commandes spectateur sont disponibles dans le chat ; les commandes diffuseur requièrent le diffuseur ou un modérateur autorisé.', 'chat.viewerCommands': 'COMMANDES SPECTATEUR', 'chat.viewerDescription': 'Disponibles pour les spectateurs identifiés lorsqu’elles sont activées.', 'chat.broadcasterCommands': 'COMMANDES DIFFUSEUR', 'chat.broadcasterDescription': 'Désactivées par défaut. Les diffuseurs peuvent les utiliser ; accordez l’accès aux modérateurs vérifiés par commande.', 'chat.enableCommand': 'ACTIVER LA COMMANDE', 'chat.allowModerators': 'AUTORISER LES MODÉRATEURS', 'chat.variables': 'Variables : {variables}.', 'chat.noVariables': 'Aucune variable.', 'chat.rules': 'GESTION DE !RULES', 'chat.saveRules': 'ENREGISTRER LES RÈGLES', 'chat.command.generic': 'Configurez la commande de chat {command}.' },
  de: { 'chat.features': 'CHATBOT-FUNKTIONEN', 'chat.featuresDescription': 'Die integrierten Bot-Kernfunktionen werden hier konfiguriert. Verwende ihren Schalter, um sie zu aktivieren oder zu deaktivieren.', 'chat.commands': 'CHATBOT-BEFEHLE', 'chat.commandsDescription': 'Aktiviere nur die Befehle, die dein Chatbot verarbeiten darf. Zuschauerbefehle sind im Chat verfügbar; Senderbefehle erfordern Sender- oder erlaubte Moderatorrechte.', 'chat.viewerCommands': 'ZUSCHAUERBEFEHLE', 'chat.viewerDescription': 'Bei Aktivierung für identifizierte Zuschauer verfügbar.', 'chat.broadcasterCommands': 'SENDERBEFEHLE', 'chat.broadcasterDescription': 'Standardmäßig deaktiviert. Sender können sie verwenden; erteile verifizierten Moderatoren je Befehl Zugriff.', 'chat.enableCommand': 'BEFEHL AKTIVIEREN', 'chat.allowModerators': 'MODERATOREN ERLAUBEN', 'chat.variables': 'Variablen: {variables}.', 'chat.noVariables': 'Keine Variablen.', 'chat.rules': '!RULES-VERWALTUNG', 'chat.saveRules': 'REGELN SPEICHERN', 'chat.command.generic': 'Konfiguriere den Chatbefehl {command}.' },
  pt: { 'chat.features': 'RECURSOS DO CHATBOT', 'chat.featuresDescription': 'Os recursos integrados do núcleo do bot são configurados aqui. Use o controle para ativá-los ou desativá-los.', 'chat.commands': 'COMANDOS DO CHATBOT', 'chat.commandsDescription': 'Ative apenas os comandos que o chatbot pode usar. Comandos de espectadores estão disponíveis no chat; comandos do transmissor exigem permissão do transmissor ou moderador autorizado.', 'chat.viewerCommands': 'COMANDOS DE ESPECTADOR', 'chat.viewerDescription': 'Disponíveis para espectadores identificados quando ativados.', 'chat.broadcasterCommands': 'COMANDOS DO TRANSMISSOR', 'chat.broadcasterDescription': 'Desativados por padrão. Transmissores podem usá-los; conceda acesso a moderadores verificados por comando.', 'chat.enableCommand': 'ATIVAR COMANDO', 'chat.allowModerators': 'PERMITIR MODERADORES', 'chat.variables': 'Variáveis: {variables}.', 'chat.noVariables': 'Sem variáveis.', 'chat.rules': 'GERENCIAMENTO DE !RULES', 'chat.saveRules': 'SALVAR REGRAS', 'chat.command.generic': 'Configure o comando de chat {command}.' }
});
Object.entries(chatbotUiPacks).forEach(([locale, messages]) => lirisqI18n?.register(locale, messages));
const adapterUiPacks = Object.freeze({
  en: { 'adapter.configuration': '{platform} PLUGIN CONFIGURATION', 'adapter.description': 'Choose the {platform} profile and link it to this streamer profile. Live provider sign-in is not configured in this build; this saves the local profile link used by the adapter.', 'adapter.channel': '{platform} CHANNEL', 'adapter.profilePlaceholder': '{platform} PROFILE / DISPLAY NAME', 'adapter.channelPlaceholder': '{platform} CHANNEL OR ROOM ID', 'adapter.useStreamer': 'USE STREAMER PROFILE', 'adapter.save': 'SAVE PLATFORM CONFIGURATION', 'adapter.platforms': 'PLATFORM CONFIGURATIONS', 'adapter.platformsDescription': 'Configure installed streaming platforms here. Each platform stays collapsed until you open it.', 'adapter.serverSetup': '{platform} SERVER SETUP', 'adapter.serverCompanion': 'SERVER COMPANION', 'adapter.nodeServer': 'NODE SERVER', 'adapter.phpServer': 'PHP SERVER', 'adapter.saveServer': 'SAVE SERVER CHOICE', 'adapter.connect': 'CONNECT {platform}' },
  es: { 'adapter.configuration': 'CONFIGURACIÓN DEL COMPLEMENTO {platform}', 'adapter.description': 'Elige el perfil de {platform} y vincúlalo a este perfil de streamer. El inicio de sesión del proveedor en vivo no está configurado en esta compilación; esto guarda el vínculo de perfil local usado por el adaptador.', 'adapter.channel': 'CANAL DE {platform}', 'adapter.profilePlaceholder': 'PERFIL / NOMBRE PARA MOSTRAR DE {platform}', 'adapter.channelPlaceholder': 'ID DE CANAL O SALA DE {platform}', 'adapter.useStreamer': 'USAR PERFIL DEL STREAMER', 'adapter.save': 'GUARDAR CONFIGURACIÓN DE PLATAFORMA', 'adapter.platforms': 'CONFIGURACIONES DE PLATAFORMA', 'adapter.platformsDescription': 'Configura aquí las plataformas de streaming instaladas. Cada plataforma permanece contraída hasta que la abras.', 'adapter.serverSetup': 'CONFIGURACIÓN DEL SERVIDOR DE {platform}', 'adapter.serverCompanion': 'SERVIDOR COMPLEMENTARIO', 'adapter.nodeServer': 'SERVIDOR NODE', 'adapter.phpServer': 'SERVIDOR PHP', 'adapter.saveServer': 'GUARDAR ELECCIÓN DE SERVIDOR', 'adapter.connect': 'CONECTAR {platform}' },
  fr: { 'adapter.configuration': 'CONFIGURATION DU MODULE {platform}', 'adapter.description': 'Choisissez le profil {platform} et liez-le à ce profil de streamer. La connexion au fournisseur en direct n’est pas configurée dans cette version ; ceci enregistre le lien de profil local utilisé par l’adaptateur.', 'adapter.channel': 'CHAÎNE {platform}', 'adapter.profilePlaceholder': 'PROFIL / NOM D’AFFICHAGE {platform}', 'adapter.channelPlaceholder': 'ID DE CHAÎNE OU SALLE {platform}', 'adapter.useStreamer': 'UTILISER LE PROFIL STREAMER', 'adapter.save': 'ENREGISTRER LA CONFIGURATION DE PLATEFORME', 'adapter.platforms': 'CONFIGURATIONS DE PLATEFORME', 'adapter.platformsDescription': 'Configurez ici les plateformes de streaming installées. Chaque plateforme reste repliée jusqu’à son ouverture.', 'adapter.serverSetup': 'CONFIGURATION DU SERVEUR {platform}', 'adapter.serverCompanion': 'SERVEUR COMPAGNON', 'adapter.nodeServer': 'SERVEUR NODE', 'adapter.phpServer': 'SERVEUR PHP', 'adapter.saveServer': 'ENREGISTRER LE CHOIX DU SERVEUR', 'adapter.connect': 'CONNECTER {platform}' },
  de: { 'adapter.configuration': '{platform}-PLUGIN-KONFIGURATION', 'adapter.description': 'Wähle das {platform}-Profil und verknüpfe es mit diesem Streamer-Profil. Die Live-Anmeldung beim Anbieter ist in diesem Build nicht eingerichtet; dies speichert die lokale Profilverknüpfung des Adapters.', 'adapter.channel': '{platform}-KANAL', 'adapter.profilePlaceholder': '{platform}-PROFIL / ANZEIGENAME', 'adapter.channelPlaceholder': '{platform}-KANAL- ODER RAUM-ID', 'adapter.useStreamer': 'STREAMER-PROFIL VERWENDEN', 'adapter.save': 'PLATTFORMKONFIGURATION SPEICHERN', 'adapter.platforms': 'PLATTFORMKONFIGURATIONEN', 'adapter.platformsDescription': 'Konfiguriere hier installierte Streaming-Plattformen. Jede Plattform bleibt eingeklappt, bis du sie öffnest.', 'adapter.serverSetup': '{platform}-SERVER-EINRICHTUNG', 'adapter.serverCompanion': 'SERVER-BEGLEITER', 'adapter.nodeServer': 'NODE-SERVER', 'adapter.phpServer': 'PHP-SERVER', 'adapter.saveServer': 'SERVERAUSWAHL SPEICHERN', 'adapter.connect': '{platform} VERBINDEN' },
  pt: { 'adapter.configuration': 'CONFIGURAÇÃO DO PLUGIN {platform}', 'adapter.description': 'Escolha o perfil de {platform} e vincule-o a este perfil de streamer. O login do provedor ao vivo não está configurado nesta compilação; isto salva o vínculo de perfil local usado pelo adaptador.', 'adapter.channel': 'CANAL {platform}', 'adapter.profilePlaceholder': 'PERFIL / NOME DE EXIBIÇÃO {platform}', 'adapter.channelPlaceholder': 'ID DO CANAL OU SALA {platform}', 'adapter.useStreamer': 'USAR PERFIL DO STREAMER', 'adapter.save': 'SALVAR CONFIGURAÇÃO DA PLATAFORMA', 'adapter.platforms': 'CONFIGURAÇÕES DE PLATAFORMA', 'adapter.platformsDescription': 'Configure aqui as plataformas de streaming instaladas. Cada plataforma fica recolhida até você abri-la.', 'adapter.serverSetup': 'CONFIGURAÇÃO DO SERVIDOR {platform}', 'adapter.serverCompanion': 'SERVIDOR COMPLEMENTAR', 'adapter.nodeServer': 'SERVIDOR NODE', 'adapter.phpServer': 'SERVIDOR PHP', 'adapter.saveServer': 'SALVAR ESCOLHA DO SERVIDOR', 'adapter.connect': 'CONECTAR {platform}' }
});
Object.entries(adapterUiPacks).forEach(([locale, messages]) => lirisqI18n?.register(locale, messages));
const t = (key, parameters) => lirisqI18n?.t(key, parameters) || key;
const sharedUiSourceKeys = Object.freeze({
  'Queue': 'ui.queue', 'Player Mode': 'ui.player', 'Shows': 'ui.shows', 'Configuration': 'ui.configuration', 'Analytics': 'ui.analytics', 'Song History': 'ui.history', 'Notifications': 'ui.notifications', 'VIP QUEUE': 'ui.vipQueue', 'STANDARD QUEUE': 'ui.standardQueue', 'MANUAL ENTRY': 'ui.manualEntry', 'SONG TITLE': 'ui.songTitle', 'ARTIST': 'ui.artist', 'SONG URL': 'ui.songUrl', 'ADD TO STANDARD': 'ui.addStandard', 'UNDO': 'ui.undo', 'OPTIONAL PLUGIN': 'ui.optionalPlugin', 'REFRESH': 'ui.refresh', 'SAVE': 'ui.save', 'CLEAR': 'ui.clear', 'EXPORT CSV': 'ui.export', 'TODAY': 'ui.today', '+ ADD SHOW': 'ui.addShow', 'STREAMER VIEW': 'ui.streamerView', 'VIEWER VIEW': 'ui.viewerView', 'NEXT': 'ui.next', 'PAUSE [SPACE]': 'ui.pause', 'CONFIGURATION': 'ui.configurationTitle', 'TEST DATA': 'ui.testData', 'LOAD TEST DATA': 'ui.loadTestData', 'WIPE TEST DATA': 'ui.wipeTestData', 'ENABLE PLUGIN': 'ui.enablePlugin', 'Plugin disabled.': 'ui.disabled', 'SKIN MANAGER': 'skins.manager', 'SKIN PACKS': 'skins.packs', 'OPEN SKIN MAKER': 'skins.openMaker', 'INSTALL': 'skins.install', 'REINSTALL': 'skins.reinstall', 'SELECT': 'skins.select', 'SELECTED': 'skins.selected', 'NOT INSTALLED': 'skins.notInstalled', 'MAIN': 'ui.main', 'CHAT BOT': 'ui.chatBot', 'SKINS': 'ui.skins', 'PLUGINS': 'ui.plugins', 'PLAY MODE': 'ui.playMode', 'QUEUE': 'ui.queueMode', 'RANDOM': 'ui.random', 'FREE PLAY': 'ui.freePlay', 'BROADCAST TIME ZONE': 'ui.timezone', 'MUSIC GAME BRIDGE': 'ui.mgb', 'OBS CONFIGURATION': 'ui.obs', 'PLATFORM CONFIGURATIONS': 'ui.platforms', 'TEST DATA & RESET': 'ui.testReset', 'STREAM NOTIFICATIONS': 'ui.streamNotifications', 'SHOW CALENDAR EXPORT': 'ui.calendarExport', 'CALENDAR EXPORT': 'ui.calendarExport', 'DISCORD ANNOUNCEMENTS': 'ui.discord', 'X SHOW ANNOUNCER': 'ui.xShows', 'COMMAND ALIASES': 'ui.commandAliases', 'ADD TO CALENDAR': 'ui.addCalendar', 'EXPORT TO': 'ui.exportTo', 'WINDOWS / OUTLOOK': 'ui.windowsOutlook', 'GOOGLE / ANDROID': 'ui.googleAndroid', 'APPLE / iOS': 'ui.appleIos', 'OTHER': 'ui.other'
});
const localizedTextSources = new WeakMap(); const localizedAttributeSources = new WeakMap();
function localizeUiNode(node) {
  if (!node || node.nodeType !== Node.TEXT_NODE || node.parentElement?.closest('script,style,svg')) return;
  const source = localizedTextSources.get(node) || node.nodeValue;
  localizedTextSources.set(node, source);
  const match = source.match(/^(\s*)(.*?)(\s*)$/s); const key = sharedUiSourceKeys[match?.[2]];
  if (key) node.nodeValue = `${match[1]}${t(key)}${match[3]}`;
}
function localizeUi(root = document.body) {
  if (!root) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); let node;
  while ((node = walker.nextNode())) localizeUiNode(node);
  root.querySelectorAll?.('[placeholder],[title],[aria-label]').forEach(element => {
    const sources = localizedAttributeSources.get(element) || {}; localizedAttributeSources.set(element, sources);
    for (const attribute of ['placeholder', 'title', 'aria-label']) {
      if (!element.hasAttribute(attribute)) continue;
      const source = sources[attribute] || element.getAttribute(attribute); sources[attribute] = source;
      const key = sharedUiSourceKeys[source]; if (key) element.setAttribute(attribute, t(key));
    }
  });
}
const uiLocalizationObserver = new MutationObserver(records => records.forEach(record => record.addedNodes.forEach(node => {
  if (node.nodeType === Node.TEXT_NODE) localizeUiNode(node);
  else if (node.nodeType === Node.ELEMENT_NODE) localizeUi(node);
})));
uiLocalizationObserver.observe(document.body, { childList: true, subtree: true });
localizeUi();
window.LIRISQ_I18N = Object.freeze({ t, register: (locale, messages) => lirisqI18n?.register(locale, messages), setLocale: locale => lirisqI18n?.setLocale(locale), getLocale: () => lirisqI18n?.getLocale() || 'en', missingKeys: () => lirisqI18n?.missingKeys() || [] });
const pluginDependencyMetadata = Object.freeze({
  'lirisq.discord-integration': ['lirisq.stream-notifications'],
  'lirisq.x-show-announcer': ['lirisq.stream-notifications'],
  'lirisq.song-requests': ['lirisq.bot-core'],
  'lirisq.play-controls': ['lirisq.bot-core'],
  'lirisq.queue-priority': ['lirisq.bot-core'],
  'lirisq.rules': ['lirisq.bot-core'],
  'lirisq.command-aliases': ['lirisq.bot-core'],
  'lirisq.stream-status-monitor': ['lirisq.bot-core'],
  'lirisq.stream-notifications-bot-hook': ['lirisq.bot-core', 'lirisq.stream-notifications'],
  'lirisq.viewer-notification-preferences': ['lirisq.bot-core', 'lirisq.stream-notifications'],
  'lirisq.notification-health-monitor': ['lirisq.bot-core', 'lirisq.stream-notifications'],
  'lirisq.twitch-live-adapter': ['lirisq.bot-core'],
  'lirisq.youtube-live-adapter': ['lirisq.bot-core'],
  'lirisq.tiktok-live-adapter': ['lirisq.bot-core'],
  'lirisq.douyin-live-adapter': ['lirisq.bot-core'],
  'lirisq.bilibili-live-adapter': ['lirisq.bot-core'],
  'lirisq.kick-live-adapter': ['lirisq.bot-core'],
  'lirisq.x-live-adapter': ['lirisq.bot-core']
});
function registerLirisQPlugin(plugin) {
  if (!plugin || lirisqPluginHost?.inventory().some(item => item.id === plugin.id)) return;
  lirisqPluginHost?.register({ ...plugin, dependencies: pluginDependencyMetadata[plugin.id] || [] });
}
window.LIRISQ_MGB_CONNECTION = Object.freeze({
  status: () => window.LirisQMGBSessions.status(),
  connectTrusted: options => window.LirisQMGBSessions.connectTrusted({
    ...options, pluginHost: lirisqPluginHost,
    modelImprovementOptIn: localStorage.getItem('lirisq-mgb-model-improvement-opt-in') === 'true'
  }),
  disconnect: () => window.LirisQMGBSessions.disconnect()
});
function normalizeMgbTrack(track) {
  if (!track || typeof track !== 'object') return null;
  const song = String(track.song || track.title || '').trim();
  const artist = String(track.artist || '').trim();
  if (!song || !artist) return null;
  const url = String(track.url || track.songUrl || '').trim();
  const artistUrl = String(track.artistUrl || '').trim();
  let fallbackHash = 2166136261;
  for (const character of `${song}${String.fromCharCode(0)}${artist}`) fallbackHash = Math.imul(fallbackHash ^ character.charCodeAt(0), 16777619);
  const id = String(track.id || `mgb-${(fallbackHash >>> 0).toString(36)}`).slice(0, 128);
  return { id, song, artist, url: /^https?:\/\//i.test(url) ? url : '#', artistUrl: /^https?:\/\//i.test(artistUrl) ? artistUrl : null };
}
function saveMgbCapturedPlayback() { /* MGB capture is intentionally memory-only. */ }
function emitMgbPlayback(event, track) {
  if (!track) return;
  lirisqPluginHost?.emit(event, { id: track.id, title: track.song, artist: track.artist, source: 'mgb', lane: 'unknown' });
}
function updateMgbCapturedPlayback(update = {}) {
  const previous = mgbCapturedPlayback.current;
  const current = Object.hasOwn(update, 'current') ? normalizeMgbTrack(update.current) : mgbCapturedPlayback.current;
  const playlist = Object.hasOwn(update, 'playlist') ? (Array.isArray(update.playlist) ? update.playlist.map(normalizeMgbTrack).filter(Boolean) : []) : mgbCapturedPlayback.playlist;
  mgbCapturedPlayback = { current, playlist };
  saveMgbCapturedPlayback();
  if (previous?.id !== current?.id) {
    emitMgbPlayback('song.finished', previous);
    emitMgbPlayback('song.started', current);
  }
  if (document.querySelector('#queue')) render();
}
/* Adapter-facing capture contract. MGB adapters provide only their captured-tab playback data here. */
window.LIRISQ_MGB_CAPTURE = Object.freeze({
  update: updateMgbCapturedPlayback,
  setCurrent: current => updateMgbCapturedPlayback({ current }),
  setPlaylist: playlist => updateMgbCapturedPlayback({ playlist }),
  status: () => ({ current: mgbCapturedPlayback.current, playlist: [...mgbCapturedPlayback.playlist] })
});
const mgbPairingBroker = 'https://api.five18.com/v1/pairings.php';
const mgbClientIdKey = 'lirisq-mgb-client-id-v1';
const mgbClientSecretKey = 'lirisq-mgb-client-secret-v1';
const mgbPairingIdKey = 'lirisq-mgb-pairing-id-v1';
let mgbLiveSession = null;
let mgbPortRequestId = null;
let mgbPairingError = '';
let mgbPlaybackLinkStatus = '';
let mgbPairingRestoring = Boolean(localStorage.getItem(mgbPairingIdKey));
function mgbClientId() {
  let id = localStorage.getItem(mgbClientIdKey);
  if (!id) { id = `five18.lirisq.${crypto.randomUUID()}`; localStorage.setItem(mgbClientIdKey, id); }
  return id;
}
function mgbClientSecret() {
  let secret = localStorage.getItem(mgbClientSecretKey);
  if (!secret) { secret = Array.from(crypto.getRandomValues(new Uint8Array(32)), byte => byte.toString(16).padStart(2, '0')).join(''); localStorage.setItem(mgbClientSecretKey, secret); }
  return secret;
}
function mgbPairingId() { return localStorage.getItem(mgbPairingIdKey); }
function mgbBrokerPaired() { return Boolean(mgbPairingId()); }
function clearMgbBrokerPairing() { window.LIRISQ_MGB_CONNECTION?.disconnect?.(); mgbLiveSession = null; mgbPortRequestId = null; mgbPlaybackLinkStatus = ''; mgbPairingRestoring = false; updateMgbCapturedPlayback({ current:null, playlist:[] }); localStorage.removeItem(mgbPairingIdKey); localStorage.removeItem(mgbClientSecretKey); }
function base64ToBytes(value) { const binary = atob(String(value || '')); const bytes = Uint8Array.from(binary, char => char.charCodeAt(0)); if (bytes.length !== 32) throw Error('Invalid paired MGB session secret'); return bytes; }
function hex(bytes) { return Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join(''); }
async function requestMgbPort() {
  if (!mgbLiveSession || window.LIRISQ_MGB_CONNECTION?.status?.().connected) return;
  const schema = 'lirisq.mgb-port-request/v1', requestId = crypto.randomUUID(), sentAt = Date.now();
  const signed = JSON.stringify([schema, mgbLiveSession.sessionId, requestId, sentAt]);
  const key = await crypto.subtle.importKey('raw', mgbLiveSession.secret, { name:'HMAC', hash:'SHA-256' }, false, ['sign']);
  const mac = hex(new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(signed))));
  mgbPortRequestId = requestId;
  mgbPlaybackLinkStatus = 'PAIRED. REQUESTING MGB PLAYBACK LINK.';
  window.postMessage({ schema, sessionId:mgbLiveSession.sessionId, requestId, sentAt, mac }, location.origin);
}
window.addEventListener('message', async event => {
  const offer = event.data;
  // The port offer is bound to the paired session.  A broker-compatible MGB
  // offer does not need to echo the control request ID.
  if (event.source !== window || event.origin !== location.origin || offer?.schema !== 'lirisq.mgb-port-offer/v1' || offer?.sessionId !== mgbLiveSession?.sessionId || !event.ports?.[0]) return;
  try {
    mgbPlaybackLinkStatus = 'PAIRED. CONNECTING MGB PLAYBACK LINK.';
    await window.LIRISQ_MGB_CONNECTION.connectTrusted({ port:event.ports[0], secret:mgbLiveSession.secret, sessionId:mgbLiveSession.sessionId, onDisconnect: () => {
      mgbLiveSession = null;
      mgbPortRequestId = null;
      updateMgbCapturedPlayback({ current:null, playlist:[] });
      mgbPlaybackLinkStatus = 'MGB PLAYBACK LINK DISCONNECTED. RECONNECTING…';
      refreshMgbLockdown();
      window.setTimeout(() => { if (mgbBrokerPaired() && !mgbIsConnected()) void refreshMgbBrokerPairing(); }, 1000);
    } });
    mgbPortRequestId = null;
    mgbPlaybackLinkStatus = 'PAIRED WITH MGB. PLAYBACK LINK IS ACTIVE.';
    refreshMgbLockdown();
  } catch (_) {
    mgbPortRequestId = null;
    mgbPlaybackLinkStatus = 'PLAYBACK LINK FAILED. REFRESH MGB AND LIRISQ, THEN TRY AGAIN.';
  }
});
async function mgbBrokerRequest(payload) {
  const response = await fetch(mgbPairingBroker, { method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify(payload) });
  const body = await response.json().catch(() => ({}));
  if (!response.ok || body?.error) { const error = new Error(body?.error || `MGB pairing service returned ${response.status}`); error.status = response.status; throw error; }
  return body;
}
async function refreshMgbBrokerPairing() {
  const pairingId = mgbPairingId(); if (!pairingId) return false;
  try {
    const result = await mgbBrokerRequest({ action:'status', pairingId, clientId:mgbClientId(), clientSecret:mgbClientSecret() });
    if (result.state === 'revoked') { clearMgbBrokerPairing(); refreshMgbLockdown(); say('MGB PAIRING WAS REMOVED'); return false; }
    if (result.paired === true || result.state === 'paired') {
      if (!result.sessionSecret) {
        mgbPlaybackLinkStatus = 'PAIRED, BUT MGB PLAYBACK CREDENTIALS ARE NOT AVAILABLE.';
        return true;
      }
      mgbLiveSession = { sessionId:String(result.sessionId || pairingId), secret:base64ToBytes(result.sessionSecret) };
      await requestMgbPort();
    }
  } catch (error) {
    // A missing authenticated session means MGB removed it and the broker
    // deleted its control-plane row. Temporary failures must not unpair.
    if (error?.status === 404) { clearMgbBrokerPairing(); refreshMgbLockdown(); say('MGB PAIRING WAS REMOVED'); return false; }
    mgbPlaybackLinkStatus = error?.status
      ? `MGB PLAYBACK LINK STATUS IS UNAVAILABLE (SERVICE ${error.status}).`
      : 'MGB PLAYBACK LINK STATUS IS UNAVAILABLE. CHECK THE MGB PAIRING SERVICE.';
  } finally {
    if (mgbPairingRestoring) { mgbPairingRestoring = false; refreshMgbLockdown(); }
  }
  return true;
}
if (lirisqPluginHost && window.LirisQSongHistoryPlugin) {
  registerLirisQPlugin(window.LirisQSongHistoryPlugin);
}
window.LIRISQ_SONG_HISTORY = Object.freeze({
  list: () => window.LirisQSongHistoryPlugin?.history() || [],
  clear: () => window.LirisQSongHistoryPlugin?.clear()
});
function renderSongHistory() {
  const plugin = window.LirisQSongHistoryPlugin; const list = document.querySelector('#songHistoryList'); if (!plugin || !list) return;
  const active = pluginIsEnabled?.(plugin.id) ?? plugin.status?.().active;
  const sharedLedger = window.LirisQQueueAnalyticsPlugin?.status?.().active === true;
  document.querySelector('#songHistoryStatus').textContent = active ? (sharedLedger ? 'Song History is enabled and shares Queue Analytics song activity for this browser session.' : 'Song History is enabled. Showing this browser session.') : 'Song History is disabled. Enable it in Configuration → Plugins.';
  document.querySelector('#songHistoryClear').disabled = !active;
  const entries = plugin.history().slice().reverse();
  list.replaceChildren();
  if (!entries.length) { list.textContent = active ? 'No songs have started or finished in this session yet.' : 'Song History is unavailable until the plugin is enabled.'; return; }
  const rows = document.createElement('ol'); rows.className = 'queue-list';
  for (const entry of entries) { const row = document.createElement('li'); row.className = 'row'; const time = new Date(entry.recordedAt).toLocaleTimeString([], { hour:'numeric', minute:'2-digit', second:'2-digit' }); row.innerHTML = `<span class="grip" aria-hidden="true"></span><div><div class="songline"><span class="song">${escaped(entry.title || 'UNTITLED SONG')}</span><span class="artist">— ${escaped(entry.artist || 'UNKNOWN ARTIST')}</span></div><div class="requester">${entry.event.toUpperCase()} · ${escaped(String(entry.source || 'queue').toUpperCase())} · ${time}</div></div>`; rows.append(row); }
  list.append(rows);
}
document.querySelector('#songHistoryRefresh')?.addEventListener('click', renderSongHistory);
document.querySelector('#songHistoryClear')?.addEventListener('click', () => { window.LIRISQ_SONG_HISTORY.clear(); renderSongHistory(); say('SONG HISTORY CLEARED'); });
if (lirisqPluginHost && window.LirisQQueueVotingPlugin) {
  registerLirisQPlugin(window.LirisQQueueVotingPlugin);
}
window.LIRISQ_QUEUE_VOTING = Object.freeze({
  vote: (songId, voterId) => window.LirisQQueueVotingPlugin.vote(songId, voterId),
  retract: (songId, voterId) => window.LirisQQueueVotingPlugin.retract(songId, voterId),
  results: () => window.LirisQQueueVotingPlugin.results(),
  reset: () => window.LirisQQueueVotingPlugin.reset()
});
if (lirisqPluginHost && window.LirisQQueueAnalyticsPlugin) {
  registerLirisQPlugin(window.LirisQQueueAnalyticsPlugin);
}
window.LIRISQ_QUEUE_ANALYTICS = Object.freeze({
  snapshot: () => window.LirisQQueueAnalyticsPlugin.snapshot(),
  clear: () => window.LirisQQueueAnalyticsPlugin.clear(),
  history: () => window.LirisQQueueAnalyticsPlugin.history(),
  retention: () => window.LirisQQueueAnalyticsPlugin.retention(),
  setRetention: days => window.LirisQQueueAnalyticsPlugin.setRetention(days),
  exportCsv: () => window.LirisQQueueAnalyticsPlugin.exportCsv()
});
if (lirisqPluginHost && window.LirisQDiscordIntegrationPlugin) {
  registerLirisQPlugin(window.LirisQDiscordIntegrationPlugin);
}
if (lirisqPluginHost && window.LirisQXShowAnnouncerPlugin) {
  registerLirisQPlugin(window.LirisQXShowAnnouncerPlugin);
}
if (lirisqPluginHost && window.LirisQShowCalendarPlugin) {
  registerLirisQPlugin(window.LirisQShowCalendarPlugin);
}
const calendarDestinationSettingsKey = 'lirisq-calendar-export-destinations-v1';
const calendarDestinationLabels = Object.freeze({ windows:'Windows calendar', mac:'Mac Calendar', ios:'iOS Calendar', android:'Android calendar', other:'Other calendar' });
const viewerCalendarDestinationNames = Object.freeze({ ios:'Apple / iOS Calendar', windows:'Outlook or Windows Calendar', android:'Google / Android Calendar', other:'your calendar app' });
function detectViewerCalendarDestination() {
  const platform = String(navigator.userAgentData?.platform || navigator.platform || navigator.userAgent || '').toLowerCase();
  const agent = String(navigator.userAgent || '').toLowerCase();
  if (/android/.test(platform) || /android/.test(agent)) return 'android';
  if (/win/.test(platform) || /windows/.test(agent)) return 'windows';
  if (/iphone|ipad|ipod|mac/.test(platform) || /iphone|ipad|ipod|mac os/.test(agent)) return 'ios';
  return 'other';
}
const calendarDestinationStyle = document.createElement('style');
calendarDestinationStyle.textContent = '#calendarExportDestinations .calendar-destination-choice:has([data-calendar-destination="mac"]){display:none}';
document.head.append(calendarDestinationStyle);
function calendarProviderIcon(provider) {
  const icons = {
    windows:'<svg viewBox="0 0 20 20"><path fill="#55a9e9" d="M1 3.1 8.5 2v7H1zM9.5 1.8 19 0v9H9.5zM1 10h7.5v7L1 15.9zm8.5 0H19v10l-9.5-1.8z"/></svg>',
    apple:'<svg viewBox="0 0 20 20" fill="currentColor"><path d="M13.7 4.7c.8-1 1.4-2.2 1.2-3.5-1.2.1-2.6.8-3.4 1.8-.7.8-1.3 2.1-1.1 3.3 1.3.1 2.5-.7 3.3-1.6ZM17.2 13.7c-.5 1.1-1.1 2.1-1.9 3.1-1 1.2-2.1 2.5-3.7 2.5-1.4 0-1.9-.8-3.5-.8s-2.2.8-3.5.8c-1.5 0-2.7-1.4-3.7-2.6C-1.2 13.8-.9 8.8 1.5 7.3c1.2-.8 2.7-.9 3.8-.9 1.4 0 2.7.9 3.5.9.7 0 2.2-1.1 3.8-.9.7 0 2.7.3 3.9 2.1-3.2 1.8-2.7 6.3.7 7.7Z"/></svg>',
    android:'<svg viewBox="0 0 20 20" fill="currentColor"><path d="M5 8h10v7.5a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V8Zm1.3-2.2L4.9 3.4l.8-.5 1.5 2.5A6.8 6.8 0 0 1 10 4.8c1 0 1.9.2 2.8.6l1.5-2.5.8.5-1.4 2.4A4 4 0 0 1 16 8H4a4 4 0 0 1 2.3-2.2ZM7.5 6.8a.7.7 0 1 0 0-1.4.7.7 0 0 0 0 1.4Zm5 0a.7.7 0 1 0 0-1.4.7.7 0 0 0 0 1.4Z"/></svg>',
    other:'<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="14" height="13" rx="2"/><path d="M6 2v4m8-4v4M3 8h14"/></svg>'
  };
  return icons[provider] || icons.other;
}
function calendarAddIcon() { return '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="12" height="13" rx="2"/><path d="M5 2v4m6-4v4M2 8h12m3 5h3m-1.5-1.5v3"/></svg>'; }
function selectedCalendarDestinations() { const saved = storedJson(calendarDestinationSettingsKey, {}); return Object.keys(calendarDestinationLabels).filter(destination => saved[destination] === true); }
function renderCalendarExportDestinations(active) {
  const saved = storedJson(calendarDestinationSettingsKey, {});
  const otherChoice = document.querySelector('#calendarExportDestinations .calendar-provider-icon.other')?.closest('label');
  if (otherChoice && !otherChoice.querySelector('[data-calendar-destination]')) { const input = document.createElement('input'); input.type = 'checkbox'; input.dataset.calendarDestination = 'other'; otherChoice.prepend(input); input.addEventListener('change', event => { const settings = storedJson(calendarDestinationSettingsKey, {}); settings.other = event.target.checked; localStorage.setItem(calendarDestinationSettingsKey, JSON.stringify(settings)); renderCalendarExportDestinations(window.LirisQShowCalendarPlugin?.status().active === true); }); }
  document.querySelectorAll('#calendarExportDestinations .calendar-provider-icon.apple').forEach(icon => { icon.innerHTML = calendarProviderIcon('apple'); });
  document.querySelectorAll('#calendarExportDestinations .calendar-provider-icon.android').forEach(icon => { icon.innerHTML = calendarProviderIcon('android'); });
  document.querySelectorAll('[data-calendar-destination]').forEach(input => { input.checked = saved[input.dataset.calendarDestination] === true; input.disabled = !active; });
  const selected = selectedCalendarDestinations();
  document.querySelector('#calendarExportDestinationNote').textContent = selected.length ? `SAVED DESTINATIONS: ${selected.map(destination => calendarDestinationLabels[destination].toUpperCase()).join(', ')}.` : 'Choose one or more calendar destinations. Selections save automatically.';
}
function renderCalendarExport() {
  const plugin = window.LirisQShowCalendarPlugin;
  const active = plugin.status().active;
  document.querySelector('#calendarExport h2').textContent = 'CALENDAR EXPORT';
  document.querySelector('#calendarExportStatus').hidden = true;
  document.querySelector('#calendarExportAdd').innerHTML = `<span class="calendar-add-icon" aria-hidden="true">${calendarAddIcon()}</span> EXPORT TO SELECTED CALENDARS`;
  document.querySelector('#calendarExportEnable').textContent = active ? 'DISABLE PLUGIN' : 'ENABLE PLUGIN';
  const select = document.querySelector('#calendarExportShow');
  const selected = select.value;
  select.replaceChildren();
  for (const show of shows || []) {
    const option = document.createElement('option');
    option.value = show.id;
    option.textContent = show.title;
    select.append(option);
  }
  if ([...select.options].some(option => option.value === selected)) select.value = selected;
  const show = (shows || []).find(item => item.id === select.value);
  const dates = document.querySelector('#calendarExportDate');
  const previous = dates.value;
  dates.replaceChildren();
  if (show) {
    try {
      const zone = document.querySelector('#calendarExportZone').value || window.LIRISQ_BROADCAST_TIMEZONE?.get() || Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
      for (const key of plugin.occurrences(show, new Date(), 12, zone)) {
        const option = document.createElement('option');
        option.value = key;
        option.textContent = key + ' at ' + show.time;
        dates.append(option);
      }
    } catch (error) { document.querySelector('#calendarExportFeedback').textContent = String(error.message || error); }
  }
  if ([...dates.options].some(option => option.value === previous)) dates.value = previous;
  if (!document.querySelector('#calendarExportZone').value) document.querySelector('#calendarExportZone').value = window.LIRISQ_BROADCAST_TIMEZONE?.get() || Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  document.querySelector('#calendarExportDownload').disabled = !active || !dates.value;
  document.querySelector('#calendarExportAdd').disabled = !active || !dates.value;
  renderCalendarExportDestinations(active);
  document.querySelector('#calendarExportPreview').textContent = show && dates.value ? 'Selected: ' + show.title + ' — ' + dates.value + ' ' + show.time + ' (' + document.querySelector('#calendarExportZone').value + '). Event duration and reminders are editable.' : 'No upcoming occurrence available.';
}
document.querySelector('#calendarExportShow')?.addEventListener('change', renderCalendarExport);
document.querySelector('#calendarExportZone')?.addEventListener('change', renderCalendarExport);
document.querySelector('#calendarExportDate')?.addEventListener('change', renderCalendarExport);
document.querySelectorAll('[data-calendar-destination]').forEach(input => input.addEventListener('change', event => { const saved = storedJson(calendarDestinationSettingsKey, {}); saved[event.target.dataset.calendarDestination] = event.target.checked; localStorage.setItem(calendarDestinationSettingsKey, JSON.stringify(saved)); renderCalendarExportDestinations(window.LirisQShowCalendarPlugin?.status().active === true); say(`${calendarDestinationLabels[event.target.dataset.calendarDestination].toUpperCase()} CALENDAR EXPORT ${event.target.checked ? 'SELECTED' : 'REMOVED'}`); }));
document.querySelector('#calendarExportEnable')?.addEventListener('click', async () => {
  const plugin = window.LirisQShowCalendarPlugin;
  const feedback = document.querySelector('#calendarExportFeedback');
  try {
    if (plugin.status().active) await lirisqPluginHost.disable(plugin.id);
    else {
      const item = lirisqPluginHost.inventory().find(entry => entry.id === plugin.id);
      const approvals = JSON.parse(localStorage.getItem('lirisq-plugin-approvals-v1') || '{}');
      if (approvals[plugin.id]?.version !== item.version) {
        if (!window.confirm('Enable local show calendar export? It creates downloadable .ics files and does not access your calendar.')) return;
        approvals[plugin.id] = { version: item.version, permissions: [...item.permissions] };
        localStorage.setItem('lirisq-plugin-approvals-v1', JSON.stringify(approvals));
      }
      await lirisqPluginHost.enable(plugin.id);
    }
    feedback.textContent = '';
    renderCalendarExport();
  } catch (error) { feedback.textContent = String(error.message || error); }
});
function calendarExportPayload() {
  const show = (shows || []).find(item => item.id === document.querySelector('#calendarExportShow').value);
  const date = document.querySelector('#calendarExportDate').value;
  const zone = document.querySelector('#calendarExportZone').value.trim();
  const duration = Number(document.querySelector('#calendarExportDuration').value);
  if (!show || !date) throw new Error('Select an upcoming show');
  const reminder = Number(document.querySelector('#calendarExportReminder').value);
  const bulk = document.querySelector('#calendarExportMultiple').checked;
  const dates = bulk ? window.LirisQShowCalendarPlugin.occurrences(show, new Date(), 12, zone) : [date];
  return { ics: window.LirisQShowCalendarPlugin.exportEvents(show, dates, zone, duration, reminder), filename: 'lirisq-show-' + (bulk ? 'upcoming-' : '') + date + '.ics' };
}
function downloadCalendarExport({ ics, filename }) {
  const url = URL.createObjectURL(new Blob([ics], { type: 'text/calendar;charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = filename; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
async function addCalendarToDevice(payload, destination = 'your calendar') {
  const file = new File([payload.ics], payload.filename, { type: 'text/calendar;charset=utf-8' });
  if (navigator.share && (!navigator.canShare || navigator.canShare({ files: [file] }))) {
    try {
      await navigator.share({ files: [file], title: 'LirisQ show calendar event' });
      return `Choose ${destination} in the device share sheet to add this event.`;
    } catch (error) {
      if (error?.name === 'AbortError') throw error;
      downloadCalendarExport(payload);
      return `Direct calendar sharing was unavailable, so LirisQ exported an .ics file. Open it with ${destination} to add this event.`;
    }
  }
  downloadCalendarExport(payload);
  return `Your browser exported an .ics file. Open it with ${destination} to add this event.`;
}
function calendarExportPayloadForShow(show, date, recurring = false, zone = window.LIRISQ_BROADCAST_TIMEZONE?.get() || Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC') {
  if (!window.LirisQShowCalendarPlugin?.status().active) throw new Error('Calendar Export is not available for viewers');
  if (!show || !date) throw new Error('Select an upcoming show');
  const dates = recurring ? window.LirisQShowCalendarPlugin.occurrences(show, new Date(), 12, zone) : [date];
  return { ics: window.LirisQShowCalendarPlugin.exportEvents(show, dates, zone, 120, 30), filename: 'lirisq-show-' + (recurring ? 'upcoming-' : '') + date + '.ics' };
}
document.querySelector('#calendarExportDownload')?.addEventListener('click', () => {
  const feedback = document.querySelector('#calendarExportFeedback');
  try { downloadCalendarExport(calendarExportPayload()); feedback.textContent = 'Calendar file exported. Open it in Apple Calendar, Google Calendar, Outlook, or your Windows calendar app.'; }
  catch (error) { feedback.textContent = String(error.message || error); }
});
document.querySelector('#calendarExportAdd')?.addEventListener('click', async () => {
  const feedback = document.querySelector('#calendarExportFeedback');
  try {
    const destinations = selectedCalendarDestinations();
    if (!destinations.length) throw new Error('Choose at least one calendar destination');
    const payload = calendarExportPayload();
    for (const destination of destinations) downloadCalendarExport({ ...payload, filename: payload.filename.replace(/\.ics$/i, `-${destination}.ics`) });
    feedback.textContent = `EXPORTED FOR ${destinations.map(destination => calendarDestinationLabels[destination].toUpperCase()).join(', ')}. OPEN EACH .ICS FILE IN ITS SELECTED CALENDAR APP.`;
  } catch (error) { if (error?.name !== 'AbortError') feedback.textContent = String(error.message || error); }
});
if (lirisqPluginHost && window.LirisQStreamNotificationsPlugin) {
  [window.LirisQStreamNotificationsPlugin, window.LirisQBotCorePlugin, window.LirisQSongRequestsPlugin, window.LirisQPlayControlsPlugin, window.LirisQQueuePriorityPlugin, window.LirisQQueueAdministrationPlugin, window.LirisQRulesPlugin, window.LirisQCommandAliasesPlugin, window.LirisQStreamStatusMonitorPlugin, window.LirisQStreamNotificationsBotHookPlugin, window.LirisQViewerNotificationPreferencesPlugin, window.LirisQNotificationHealthMonitorPlugin, window.LirisQOBSIntegrationPlugin, window.LirisQTwitchLiveAdapterPlugin, window.LirisQYouTubeLiveAdapterPlugin, window.LirisQTikTokLiveAdapterPlugin, window.LirisQDouyinLiveAdapterPlugin, window.LirisQBilibiliLiveAdapterPlugin, window.LirisQKickLiveAdapterPlugin, window.LirisQXLiveAdapterPlugin].forEach(registerLirisQPlugin);
}
/* Shared handoff for every enabled platform adapter. Adapters normalize events; the
   router owns Bot Core dispatch and leaves actual platform posting to its transport. */
window.LIRISQ_PLATFORM_EVENT_SINK = async event => {
  const vipUpdate = window.LirisQBotCorePlugin?.handlePlatformEvent?.(event);
  if (vipUpdate?.promoteViewer && event?.payload) window.LIRISQ_QUEUE_COMMAND_SERVICE?.promoteViewerRequest?.(event.payload.viewerId || event.payload.userId || event.payload.authorChannelId || event.payload.username || event.payload.author);
  const core = window.LirisQBotCorePlugin;
  if (!core?.status?.().active) return false;
  return core.routePlatformEvent(event);
};
let twitchEventCursor = 0;
let twitchIngressPollRunning = false;
let youtubeEventCursor = 0;
let youtubeIngressPollRunning = false;
const twitchTransportConfigurationKey = 'lirisq-twitch-transport-v1';
function twitchTransportConfiguration() { return { kind:'node', phpEndpoint:'', ...storedJson(twitchTransportConfigurationKey, {}) }; }
let serverAudienceRole = 'viewer';
let serverAudienceIdentity = null;
function usesServerAudience() { return location.protocol === 'https:' || twitchTransportConfiguration().kind === 'php'; }
async function refreshServerAudienceRole() {
  if (!usesServerAudience() || twitchTransportConfiguration().kind !== 'php') return;
  try {
    const response = await fetch(twitchEndpoint('session'), { cache:'no-store', credentials:'same-origin' });
    const session = response.ok ? await response.json() : null;
    serverAudienceRole = session?.role === 'streamer' ? 'streamer' : 'viewer';
    serverAudienceIdentity = session?.identity || null;
  } catch (_) { serverAudienceRole = 'viewer'; serverAudienceIdentity = null; }
  if (typeof renderAccountProfile === 'function') { renderAccountProfile(); if (location.pathname.endsWith('/profile')) void renderProfilePage(); }
}
void fetch('./lirisq-deployment.json', { cache:'no-store' }).then(response => response.ok ? response.json() : null).then(deployment => {
  if (deployment?.schema !== 'lirisq-deployment/v1' || deployment?.twitch?.transport !== 'php' || typeof deployment.twitch.endpoint !== 'string') return;
  const saved = storedJson(twitchTransportConfigurationKey, {});
  if (!saved.kind || saved.managedByDeployment !== false) {
    const next = { kind:'php', phpEndpoint:deployment.twitch.endpoint, managedByDeployment:true };
    const changed = saved.kind !== next.kind || saved.phpEndpoint !== next.phpEndpoint || saved.managedByDeployment !== true;
    localStorage.setItem(twitchTransportConfigurationKey, JSON.stringify(next));
    if (changed && typeof renderStreamerIdentity === 'function') void renderStreamerIdentity();
  }
  void refreshServerAudienceRole();
}).catch(() => {});
const youtubeTransportConfigurationKey = 'lirisq-youtube-transport-v1';
function youtubeTransportConfiguration() { return { kind:'node', phpEndpoint:'', ...storedJson(youtubeTransportConfigurationKey, {}) }; }
function twitchEndpoint(action) {
  const configuration = twitchTransportConfiguration();
  if (configuration.kind !== 'php' || !configuration.phpEndpoint) return `/api/twitch/${action}`;
  const url = new URL(configuration.phpEndpoint, window.location.href); url.searchParams.set('action', action); return url.toString();
}
function youtubeEndpoint(action) {
  const configuration = youtubeTransportConfiguration();
  if (configuration.kind !== 'php' || !configuration.phpEndpoint) return `/api/youtube/${action}`;
  const url = new URL(configuration.phpEndpoint, window.location.href); url.searchParams.set('action', action); return url.toString();
}
async function pollVerifiedTwitchEvents() {
  if (twitchIngressPollRunning || !pluginIsEnabled?.('lirisq.twitch-live-adapter')) return;
  twitchIngressPollRunning = true;
  try {
    const eventsUrl = new URL(twitchEndpoint('events'), window.location.href); eventsUrl.searchParams.set('after', String(twitchEventCursor));
    const response = await fetch(eventsUrl, { cache: 'no-store' });
    if (!response.ok) return;
    const data = await response.json(); const adapter = window.LirisQTwitchLiveAdapterPlugin;
    for (const event of Array.isArray(data.events) ? data.events : []) {
      twitchEventCursor = Math.max(twitchEventCursor, Number(event.sequence) || 0);
      await adapter?.ingestEventSub?.(event.subscriptionType, event.payload, event.messageId);
    }
    const statusResponse = await fetch(twitchEndpoint('status'), { cache: 'no-store' });
    const status = statusResponse.ok ? await statusResponse.json() : null;
    adapter?.setVerifiedIngress?.(Boolean(status?.authorized && Array.isArray(status.subscriptions) && status.subscriptions.some(subscription => subscription.status === 'enabled')));
  } catch (_) { /* The local server remains optional while Twitch is in development. */ }
  finally { twitchIngressPollRunning = false; }
}
setInterval(() => { void pollVerifiedTwitchEvents(); }, 2000);
async function pollVerifiedYouTubeEvents() {
  if (youtubeIngressPollRunning || !pluginIsEnabled?.('lirisq.youtube-live-adapter')) return;
  youtubeIngressPollRunning = true;
  try {
    const eventsUrl = new URL(youtubeEndpoint('events'), window.location.href); eventsUrl.searchParams.set('after', String(youtubeEventCursor));
    const response = await fetch(eventsUrl, { cache:'no-store' }); if (!response.ok) return;
    const data = await response.json(); const adapter = window.LirisQYouTubeLiveAdapterPlugin;
    for (const event of Array.isArray(data.events) ? data.events : []) { youtubeEventCursor = Math.max(youtubeEventCursor, Number(event.sequence) || 0); await adapter?.ingestLiveChat?.(event.message); }
    const statusResponse = await fetch(youtubeEndpoint('status'), { cache:'no-store' }); const status = statusResponse.ok ? await statusResponse.json() : null;
    adapter?.setVerifiedIngress?.(Boolean(status?.authorized && status?.liveChatId));
  } catch (_) { /* The configured YouTube server may be offline. */ }
  finally { youtubeIngressPollRunning = false; }
}
setInterval(() => { void pollVerifiedYouTubeEvents(); }, 2000);
let kickEventCursor = 0;
let kickIngressPollRunning = false;
async function pollVerifiedKickEvents() {
  if (kickIngressPollRunning || !pluginIsEnabled?.('lirisq.kick-live-adapter')) return;
  kickIngressPollRunning = true;
  try {
    const eventsUrl = new URL('/api/kick/events', window.location.href); eventsUrl.searchParams.set('after', String(kickEventCursor));
    const response = await fetch(eventsUrl, { cache:'no-store' }); if (!response.ok) return;
    const data = await response.json(); const adapter = window.LirisQKickLiveAdapterPlugin;
    for (const event of Array.isArray(data.events) ? data.events : []) { kickEventCursor = Math.max(kickEventCursor, Number(event.sequence) || 0); await adapter?.ingestWebhook?.(event.type, event.payload, event.messageId); }
    const statusResponse = await fetch('/api/kick/status', { cache:'no-store' }); const status = statusResponse.ok ? await statusResponse.json() : null;
    adapter?.setVerifiedIngress?.(Boolean(status?.authorized && Number(status?.receivedEvents) > 0));
  } catch (_) { /* Kick remains unavailable until its server setup is complete. */ }
  finally { kickIngressPollRunning = false; }
}
setInterval(() => { void pollVerifiedKickEvents(); }, 2000);
const bundledPluginGlobals = [
  'LirisQSongHistoryPlugin', 'LirisQQueueVotingPlugin', 'LirisQQueueAnalyticsPlugin',
  'LirisQDiscordIntegrationPlugin', 'LirisQXShowAnnouncerPlugin', 'LirisQShowCalendarPlugin', 'LirisQStreamNotificationsPlugin',
  'LirisQBotCorePlugin', 'LirisQSongRequestsPlugin', 'LirisQPlayControlsPlugin', 'LirisQQueuePriorityPlugin', 'LirisQQueueAdministrationPlugin', 'LirisQRulesPlugin', 'LirisQCommandAliasesPlugin',
  'LirisQStreamStatusMonitorPlugin', 'LirisQStreamNotificationsBotHookPlugin', 'LirisQViewerNotificationPreferencesPlugin',
  'LirisQNotificationHealthMonitorPlugin', 'LirisQOBSIntegrationPlugin',
  'LirisQTwitchLiveAdapterPlugin', 'LirisQYouTubeLiveAdapterPlugin', 'LirisQTikTokLiveAdapterPlugin', 'LirisQDouyinLiveAdapterPlugin',
  'LirisQBilibiliLiveAdapterPlugin', 'LirisQKickLiveAdapterPlugin', 'LirisQXLiveAdapterPlugin'
];
const bundledPlugins = bundledPluginGlobals.map(name => window[name]).filter(plugin => plugin?.id && plugin?.factory);
const bundledPluginById = new Map(bundledPlugins.map(plugin => [plugin.id, plugin]));
const pluginLabels = Object.freeze({
  'lirisq.song-history':'Song History','lirisq.queue-voting':'Queue Voting','lirisq.queue-analytics':'Queue Analytics','lirisq.discord-integration':'Discord','lirisq.x-show-announcer':'X Shows','lirisq.show-calendar-export':'Calendar Export','lirisq.stream-notifications':'Stream Notifications','lirisq.bot-core':'LirisQ Bot Core','lirisq.song-requests':'Song Requests','lirisq.queue-administration':'Queue Administration','lirisq.command-aliases':'Command Aliases'
});
const pluginDescriptionFallbacks = Object.freeze({
  'lirisq.discord-integration': 'Collects LirisQ queue events and prepares Discord webhook messages only when you explicitly send them.',
  'lirisq.song-history': 'Keeps a local session history of songs that have started or finished playing.',
  'lirisq.queue-voting': 'Collects advisory votes for queued songs without changing VIP priority or queue order.',
  'lirisq.queue-analytics': 'Measures local queue and playback activity and can retain or export browser-local session data.',
  'lirisq.obs-integration': 'Receives OBS scene events for Bot Core when an OBS WebSocket connection is configured.',
  'lirisq.command-aliases': 'Lets you assign additional command names to existing Bot Core commands, stored only in this browser.',
  'lirisq.song-requests': 'Lets Bot Core submit, list, and remove a viewer’s own pending song requests.',
  'lirisq.play-controls': 'Lets authorized chat commands start, pause, or advance the queue player.',
  'lirisq.queue-priority': 'Lets broadcasters move approved requests between Standard and VIP priority.',
  'lirisq.queue-administration': 'Lets verified broadcasters safely clear the queue, set the play mode, and set the active show queue limit.',
  'lirisq.rules': 'Lets viewers read and verified broadcasters or moderators update the saved queue rules.',
  'lirisq.bot-core': 'Coordinates local chatbot events and hooks without platform accounts or automatic messages.'
});
function localizedPluginName(plugin) { return pluginLabels[plugin.id] || plugin.name || plugin.id; }
function localizedPluginDescription(plugin) {
  const key = `plugin.${plugin.id}.description`; const localized = t(key);
  if (localized !== key) return localized;
  if ((lirisqI18n?.getLocale() || 'en').split('-')[0] === 'en') return plugin.description || pluginDescriptionFallbacks[plugin.id] || 'Adds an optional LirisQ capability that can be enabled or disabled from this card.';
  return t('plugins.genericDescription', { name: localizedPluginName(plugin) });
}
const bundledPluginStorageKey = 'lirisq-installed-bundled-plugins-v1';
const bundledPluginDisabledStorageKey = 'lirisq-disabled-bundled-plugins-v1';
const storedBundledPlugins = JSON.parse(localStorage.getItem(bundledPluginStorageKey) || 'null');
let installedBundledPlugins = new Set(Array.isArray(storedBundledPlugins) ? storedBundledPlugins.filter(id => bundledPluginById.has(id)) : bundledPlugins.map(plugin => plugin.id));
const storedDisabledBundledPlugins = JSON.parse(localStorage.getItem(bundledPluginDisabledStorageKey) || '[]');
let disabledBundledPlugins = new Set(Array.isArray(storedDisabledBundledPlugins) ? storedDisabledBundledPlugins.filter(id => installedBundledPlugins.has(id)) : []);
// Calendar Export is a built-in LirisQ capability, not a removable add-on.
const builtInCorePluginIds = new Set(['lirisq.show-calendar-export']);
for (const id of builtInCorePluginIds) { installedBundledPlugins.add(id); disabledBundledPlugins.delete(id); }
// Bot Core is the required host for the Chat Bot configuration. Older builds
// could retain a stale disabled flag through an update, hiding that entire UI.
if (!localStorage.getItem('lirisq-bot-core-default-v1')) {
  installedBundledPlugins.add('lirisq.bot-core');
  disabledBundledPlugins.delete('lirisq.bot-core');
  persistBundledPlugins();
  persistDisabledBundledPlugins();
  localStorage.setItem('lirisq-bot-core-default-v1', 'applied');
}
function persistBundledPlugins() { localStorage.setItem(bundledPluginStorageKey, JSON.stringify([...installedBundledPlugins])); }
function persistDisabledBundledPlugins() { localStorage.setItem(bundledPluginDisabledStorageKey, JSON.stringify([...disabledBundledPlugins])); }
function pluginIsInstalled(id) { return installedBundledPlugins.has(id); }
function pluginIsEnabled(id) { return pluginIsInstalled(id) && lirisqPluginHost?.inventory().find(plugin => plugin.id === id)?.status === 'enabled'; }
const optionalMenuPlugins = {
  analytics: 'lirisq.queue-analytics', songHistory: 'lirisq.song-history', notifications: 'lirisq.stream-notifications'
};
const streamNotificationDeliveryPluginIds = new Set(['lirisq.discord-integration', 'lirisq.x-show-announcer']);
const botPluginIds = new Set(['lirisq.song-requests', 'lirisq.play-controls', 'lirisq.queue-priority', 'lirisq.rules', 'lirisq.command-aliases', 'lirisq.stream-status-monitor', 'lirisq.stream-notifications-bot-hook', 'lirisq.viewer-notification-preferences', 'lirisq.notification-health-monitor', 'lirisq.twitch-live-adapter', 'lirisq.youtube-live-adapter', 'lirisq.tiktok-live-adapter', 'lirisq.douyin-live-adapter', 'lirisq.bilibili-live-adapter', 'lirisq.kick-live-adapter', 'lirisq.x-live-adapter']);
const platformAdapterIds = new Set(['lirisq.discord-integration', 'lirisq.twitch-live-adapter', 'lirisq.youtube-live-adapter', 'lirisq.tiktok-live-adapter', 'lirisq.douyin-live-adapter', 'lirisq.bilibili-live-adapter', 'lirisq.kick-live-adapter', 'lirisq.x-live-adapter']);
// Bot Core is a completed local orchestration layer. Individual adapters and
// optional features retain their own DEV status until their live transport is ready.
const developmentPluginIds = new Set([...botPluginIds, ...platformAdapterIds]);
function appendDevBadge(target) { const badge = document.createElement('span'); badge.className = 'dev-badge'; badge.textContent = 'DEV'; target.append(' ', badge); }
function refreshOptionalNavigation() {
  for (const [view, pluginId] of Object.entries(optionalMenuPlugins)) {
    const button = document.querySelector(`nav button[data-view="${view}"]`);
    if (button) button.hidden = !pluginIsEnabled(pluginId);
  }
  for (const [view, pluginId] of Object.entries(configurationIntegrationPlugins || {})) {
    const button = document.querySelector(`[data-configuration-category="${view}"]`);
    if (!button) continue;
    const inactive = Boolean(pluginId && !pluginIsEnabled(pluginId));
    button.hidden = inactive;
    button.dataset.inactive = String(inactive);
    button.disabled = false;
    if (inactive && button.classList.contains('active')) showConfigurationIntegration('main');
  }
  renderObsConfiguration();
}
function refreshPluginManagementUi() {
  // These controls can be clicked while their Configuration panel is being rebuilt.
  // Refresh only the shared manager/navigation surfaces; page-specific controls redraw
  // themselves when their own page is shown or when their local toggle is used.
  renderOptionalAddonManager();
  renderBotPlugins();
  renderPlatformPluginConfigurations();
  refreshOptionalNavigation();
}
async function uninstallBundledPlugin(id, fromBotCore = false) {
  if (builtinBotFeatureIds.has(id) && !fromBotCore) throw new Error('Uninstall LirisQ Bot Core to remove its built-in features.');
  const item = lirisqPluginHost?.inventory().find(plugin => plugin.id === id);
  if (!pluginIsInstalled(id) && !item) return;
  if (id === 'lirisq.bot-core') {
    for (const dependentId of botPluginIds) {
      if (dependentId === id) continue;
      const dependent = lirisqPluginHost?.inventory().find(plugin => plugin.id === dependentId);
      if (dependent?.status === 'enabled') await lirisqPluginHost.disable(dependentId);
    }
    for (const featureId of builtinBotFeatureIds) if (pluginIsInstalled(featureId)) await uninstallBundledPlugin(featureId, true);
  }
  if (item?.status === 'enabled') await lirisqPluginHost.disable(id);
  if (item) await lirisqPluginHost.unregister(id);
  installedBundledPlugins.delete(id);
  disabledBundledPlugins.delete(id);
  const approvals = JSON.parse(localStorage.getItem('lirisq-plugin-approvals-v1') || '{}');
  delete approvals[id]; localStorage.setItem('lirisq-plugin-approvals-v1', JSON.stringify(approvals));
  persistBundledPlugins(); persistDisabledBundledPlugins(); refreshOptionalNavigation();
}
async function installBundledPlugin(id) {
  const plugin = bundledPluginById.get(id);
  if (!plugin) throw new Error('Unknown bundled plugin');
  if (!lirisqPluginHost.inventory().some(item => item.id === id)) registerLirisQPlugin(plugin);
  installedBundledPlugins.add(id); disabledBundledPlugins.delete(id); persistBundledPlugins(); persistDisabledBundledPlugins();
  if (botPluginIds.has(id) && !pluginIsEnabled('lirisq.bot-core')) await installBundledPlugin('lirisq.bot-core');
  await setBundledPluginEnabled(id, true);
}
async function setBundledPluginEnabled(id, enabled) {
  const plugin = bundledPluginById.get(id); const item = lirisqPluginHost?.inventory().find(entry => entry.id === id);
  if (!plugin || !item) throw new Error('Install this plugin first');
  if (!enabled) {
    if (id === 'lirisq.stream-notifications') for (const dependentId of streamNotificationDeliveryPluginIds) if (pluginIsEnabled(dependentId)) await setBundledPluginEnabled(dependentId, false);
    if (id === 'lirisq.bot-core') for (const dependentId of botPluginIds) if (pluginIsEnabled(dependentId)) await lirisqPluginHost.disable(dependentId);
    const result = await lirisqPluginHost.disable(id); disabledBundledPlugins.add(id); persistDisabledBundledPlugins(); refreshOptionalNavigation(); return result;
  }
  for (const dependencyId of item.dependencies || []) {
    if (!pluginIsInstalled(dependencyId)) await installBundledPlugin(dependencyId);
    else if (!pluginIsEnabled(dependencyId)) await setBundledPluginEnabled(dependencyId, true);
  }
  if (streamNotificationDeliveryPluginIds.has(id) && !pluginIsEnabled('lirisq.stream-notifications')) await setBundledPluginEnabled('lirisq.stream-notifications', true);
  if (botPluginIds.has(id) && !pluginIsEnabled('lirisq.bot-core')) throw new Error('Enable LirisQ Bot in Plugin Manager first');
  const approvals = JSON.parse(localStorage.getItem('lirisq-plugin-approvals-v1') || '{}');
  if (approvals[id]?.version !== item.version || JSON.stringify(approvals[id]?.permissions) !== JSON.stringify(item.permissions)) {
    approvals[id] = { version: item.version, permissions: [...item.permissions] };
    localStorage.setItem('lirisq-plugin-approvals-v1', JSON.stringify(approvals));
  }
  const result = item.status === 'enabled' ? true : await lirisqPluginHost.enable(id);
  disabledBundledPlugins.delete(id); persistDisabledBundledPlugins();
  if (id === 'lirisq.bot-core') for (const dependentId of botPluginIds) {
    if (pluginIsInstalled(dependentId) && !disabledBundledPlugins.has(dependentId)) await setBundledPluginEnabled(dependentId, true);
  }
  refreshOptionalNavigation(); return result;
}
async function reconcileBundledPlugins() {
  for (const plugin of bundledPlugins) if (!pluginIsInstalled(plugin.id)) await uninstallBundledPlugin(plugin.id);
  const installedPlugins = bundledPlugins.filter(plugin => pluginIsInstalled(plugin.id) && !disabledBundledPlugins.has(plugin.id));
  installedPlugins.sort((a, b) => (a.id === 'lirisq.bot-core' ? -1 : b.id === 'lirisq.bot-core' ? 1 : 0));
  for (const plugin of installedPlugins) {
    if (botPluginIds.has(plugin.id) && !pluginIsEnabled('lirisq.bot-core')) continue;
    await setBundledPluginEnabled(plugin.id, true);
  }
  refreshOptionalNavigation();
}
function renderOptionalAddonManager() {
  const settings = document.querySelector('#settings .settings'); if (!settings) return;
  let panel = document.querySelector('#optionalAddonManager');
  if (!panel) {
    panel = document.createElement('section'); panel.id = 'optionalAddonManager'; panel.className = 'optional-addons';
    const setting = document.createElement('div'); setting.className = 'setting';
    const copy = document.createElement('div'); const heading = document.createElement('h3'); heading.textContent = t('plugins.manager.title'); const description = document.createElement('p'); description.textContent = t('plugins.manager.description'); copy.append(heading, description); setting.append(copy);
    const categories = document.createElement('div'); categories.id = 'optionalAddonCategories'; panel.append(setting, categories);
    settings.append(panel);
  }
  const categories = panel.querySelector('#optionalAddonCategories'); categories.replaceChildren();
  const lists = new Map();
  for (const [title, labelKey] of [['GENERAL PLUGINS', 'plugins.category.general'], ['BOT CORE', 'plugins.category.core'], ['PLATFORM ADAPTERS', 'plugins.category.adapters'], ['BOT FEATURES', 'plugins.category.features'], ['SYSTEM INTEGRATIONS', 'plugins.category.system']]) { const section = document.createElement('section'); const heading = document.createElement('h3'); heading.textContent = t(labelKey); const list = document.createElement('div'); list.className = 'plugin-management-grid'; section.append(heading, list); categories.append(section); lists.set(title, list); }
  for (const plugin of bundledPlugins) {
    if (builtInCorePluginIds.has(plugin.id)) continue;
    const installed = pluginIsInstalled(plugin.id); const item = lirisqPluginHost?.inventory().find(entry => entry.id === plugin.id);
    const card = document.createElement('article'); card.className = 'management-card plugin-card' + (installed ? '' : ' uninstalled'); card.dataset.pluginId = plugin.id;
    const title = document.createElement('h3'); title.textContent = localizedPluginName(plugin);
    if (developmentPluginIds.has(plugin.id)) appendDevBadge(title);
    const description = document.createElement('p'); description.textContent = `${localizedPluginDescription(plugin)}${platformAdapterIds.has(plugin.id) ? ` ${t('plugins.devNote')}` : ''}`;
    const detail = document.createElement('p'); detail.textContent = `v${plugin.version}`;
    const actions=document.createElement('div');actions.className='management-actions';
    const install = document.createElement('button'); install.type='button';install.className='btn hot';install.textContent=t('plugins.install');install.hidden=installed;
    install.addEventListener('click',async()=>{try{await installBundledPlugin(plugin.id);refreshPluginManagementUi();}catch(error){say(String(error.message||error));}});
    const toggle=document.createElement('button');toggle.type='button';const enabled=item?.status==='enabled';toggle.className=`btn plugin-toggle ${enabled?'enabled':'disabled'}`;toggle.textContent=enabled?t('plugins.enabled'):t('plugins.disabled');toggle.disabled=!installed;
    toggle.addEventListener('click',async()=>{try{await setBundledPluginEnabled(plugin.id,!enabled);refreshPluginManagementUi();}catch(error){say(String(error.message||error));}});
    const action = document.createElement('button'); action.type = 'button'; action.className = 'btn uninstall'; action.textContent = t('plugins.uninstall'); action.disabled=!installed;
    action.hidden = builtinBotFeatureIds.has(plugin.id);
    action.addEventListener('click', async () => {
      try {
        if (!window.confirm(`Uninstall ${plugin.id} from this browser?`)) return;
        await uninstallBundledPlugin(plugin.id);
        refreshPluginManagementUi(); say(`${plugin.id} ${installed ? 'UNINSTALLED' : 'INSTALLED'}`);
      } catch (error) { say(String(error.message || error)); }
    });
    actions.append(install,toggle,action); card.append(title, description, detail, actions); lists.get(pluginManagerCategories.get(plugin.id) || 'GENERAL PLUGINS').append(card);
  }
}
const notificationTypeDetails = Object.freeze({
  'show.schedule.changed': ['Show schedule updates', 'Creates a draft when a show date, time, or recurrence changes.'],
  'show.availability.changed': ['Show availability changes', 'Creates a draft when a show becomes available or unavailable.'],
  'show.deleted': ['Show cancellations', 'Creates a draft when a scheduled show is removed.'],
  'song.requested': ['New song requests', 'Creates a draft when a viewer request enters the queue.'],
  'song.lane.changed': ['Queue priority changes', 'Creates a draft when a request moves between queue lanes.'],
  'show.reminder': ['Upcoming show reminders', 'Creates a draft at each selected reminder lead time before a show.']
});
function populateNotificationTimezoneSelect(field, timezone) {
  if (!field.options.length) {
    const choose = document.createElement('option'); choose.value = ''; choose.textContent = 'SELECT A SHOW TIME ZONE'; field.append(choose);
    const timezones = typeof Intl.supportedValuesOf === 'function' ? Intl.supportedValuesOf('timeZone') : ['UTC', 'America/Los_Angeles', 'America/New_York', 'Europe/London', 'Europe/Berlin', 'Asia/Tokyo', 'Australia/Sydney'];
    for (const zone of timezones) { const option = document.createElement('option'); option.value = zone; option.textContent = zone; field.append(option); }
  }
  if (!field.value && [...field.options].some(option => option.value === timezone)) field.value = timezone;
}
function renderNotifications() {
  const plugin = window.LirisQStreamNotificationsPlugin;
  const enabled = plugin.status().active;
  renderNotificationDeliveryIntegrations(enabled);
  document.querySelector('#notificationStatus').textContent = enabled ? 'Enabled. Notifications are prepared locally; delivery requires explicit action.' : 'Plugin disabled.';
  document.querySelector('#notificationEnable').textContent = enabled ? 'DISABLE PLUGIN' : 'ENABLE PLUGIN';
  const zoneField = document.querySelector('#notificationZone');
  const preferences=plugin.configuration();
  populateNotificationTimezoneSelect(zoneField, preferences.timezone);
  const ruleField = document.querySelector('#notificationRules');
  if (!ruleField.dataset.initialized) { ruleField.value = plugin.reminders().join(', '); ruleField.dataset.initialized = 'true'; }
  const schedule = document.querySelector('#notificationSchedule');
  if (!zoneField.value) schedule.textContent = 'Select and save a show time zone to preview reminders.';
  else try { const upcoming = plugin.schedulePreview(shows,zoneField.value); schedule.textContent = upcoming.length ? 'Next reminder: ' + upcoming[0].title + ' — ' + new Date(upcoming[0].dueAt).toLocaleString() + ' (' + upcoming[0].minutes + ' minutes before show). ' + upcoming.length + ' upcoming reminder(s) in preview.' : 'No upcoming reminders in the current preview window.'; }
  catch (error) { schedule.textContent = String(error.message || error); }
  document.querySelector('#notificationAutoPrepare').checked=preferences.autoPrepare;
  const typesBox=document.querySelector('#notificationTypePreferences');
  typesBox.replaceChildren();
  for(const [type,allowed] of Object.entries(preferences.types)) {
    const [name, explanation] = notificationTypeDetails[type] || ['Notification event', 'Creates a local notification draft for this event.'];
    const label=document.createElement('label');label.className='notification-type-option';const check=document.createElement('input');check.type='checkbox';check.dataset.notificationType=type;check.checked=allowed;
    const text=document.createElement('span');const heading=document.createElement('strong');heading.textContent=name;const detail=document.createElement('small');detail.textContent=explanation;text.append(heading,detail);label.append(check,text);typesBox.append(label);
  }
  const box = document.querySelector('#notificationOutbox');
  box.replaceChildren();
  const selectedStatus=document.querySelector('#notificationFilter').value;
  const entries = plugin.outbox().filter(row=>selectedStatus==='all'||row.status===selectedStatus);
  if (!entries.length) { box.textContent = 'No notifications yet. Changes after enabling will appear here.'; return; }
  for (const entry of entries.slice(0,100)) {
    const card = document.createElement('div');
    card.style.cssText = 'border:1px solid var(--line);padding:12px;margin:8px 0;overflow-wrap:anywhere';
    const title = document.createElement('strong');
    title.textContent = entry.type + ' — ' + entry.status + ' — ' + new Date(entry.createdAt).toLocaleString();
    const body = document.createElement('p');
    body.textContent = entry.message;
    card.append(title,body);
    const buttons = document.createElement('div');
    buttons.className = 'fields';
    for (const [label, status] of [['APPROVE','approved'],['CANCEL','cancelled']]) {
      if (entry.status === 'delivered' || entry.status === 'cancelled' || entry.status === 'sending' || (status === 'approved' && entry.status === 'approved')) continue;
      const button = document.createElement('button');
      button.className = 'btn'; button.type = 'button'; button.textContent = label;
      button.addEventListener('click', () => { try { plugin.update(entry.id,status); renderNotifications(); } catch(error){document.querySelector('#notificationFeedback').textContent=String(error.message||error);} });
      buttons.append(button);
    }
    if (entry.status === 'approved' || entry.status === 'failed') {
      const discord = window.LirisQDiscordIntegrationPlugin;
      const sendDiscord = document.createElement('button');
      sendDiscord.className = 'btn'; sendDiscord.type = 'button'; sendDiscord.textContent = entry.status === 'failed' ? 'RETRY VIA DISCORD' : 'SEND TO DISCORD';
      sendDiscord.disabled = !enabled || !discord?.status().active;
      sendDiscord.title = sendDiscord.disabled ? 'Enable Stream Notifications and Discord Integration first' : 'Send this approved notification to Discord';
      sendDiscord.addEventListener('click', async () => {
        if (!window.confirm('Send this notification to the configured Discord webhook now?\\n\\n' + entry.message + (entry.status === 'failed' ? '\\n\\nThe previous attempt may have reached Discord despite an error.' : ''))) return;
        sendDiscord.disabled = true;
        const feedback = document.querySelector('#notificationFeedback');
        try { await plugin.sendDiscord(entry.id,discord); renderNotifications(); feedback.textContent = 'Discord delivery acknowledged by the server.'; }
        catch (error) { renderNotifications(); feedback.textContent = 'Discord delivery failed: ' + String(error.message || error); }
      });
      buttons.append(sendDiscord);
      const copy = document.createElement('button');
      copy.className = 'btn'; copy.type = 'button'; copy.textContent = 'COPY MESSAGE';
      copy.addEventListener('click', async () => {
        try { await navigator.clipboard.writeText(entry.message); document.querySelector('#notificationFeedback').textContent = 'Message copied. Copying does not mark it delivered.'; }
        catch (_) { document.querySelector('#notificationFeedback').textContent = 'Clipboard unavailable.'; }
      });
      const open = document.createElement('button');
      open.className = 'btn'; open.type = 'button'; open.textContent = 'OPEN X COMPOSER';
      open.addEventListener('click', () => {
        if (!window.confirm('Open X with this notification draft? You must publish it manually.')) return;
        window.open('https://twitter.com/intent/tweet?text='+encodeURIComponent(entry.message.slice(0,280)),'_blank','noopener,noreferrer');
        document.querySelector('#notificationFeedback').textContent = 'X composer requested. This is not confirmation of publication.';
      });
      const done = document.createElement('button');
      done.className = 'btn'; done.type = 'button'; done.textContent = 'MARK MANUALLY DELIVERED';
      done.addEventListener('click', () => { if (window.confirm('Confirm that you published this notification outside LirisQ?')) { plugin.update(entry.id,'delivered','manual'); renderNotifications(); } });
      buttons.append(copy,open,done);
    }
    if(entry.lastError){const error=document.createElement('p');error.textContent='Delivery error: '+entry.lastError;card.append(error);}
    card.append(buttons);box.append(card);
  }
}
function renderNotificationDeliveryIntegrations(enabled) {
  const notifications = document.querySelector('#notifications .card'); if (!notifications) return;
  let group = notifications.querySelector('#notificationDeliveryIntegrations');
  if (!group) {
    group = document.createElement('section'); group.id = 'notificationDeliveryIntegrations'; group.className = 'optional-addons'; group.innerHTML = '<h3>DELIVERY INTEGRATIONS</h3><p class="queue-note">Stream Notifications owns notification rules, drafts, approval, history, and delivery. Each platform below only holds its connection or delivery setup.</p>';
    const discord = document.querySelector('#discord .card'); const xShows = document.querySelector('#xannouncer .card');
    for (const [title, card, kind] of [['DISCORD ANNOUNCEMENTS', discord, 'discord'], ['X SHOWS', xShows, 'x']]) { if (!card) continue; const section = document.createElement('details'); section.className = 'optional-addons'; section.innerHTML = `<summary>${title}</summary>`; card.id = title === 'DISCORD ANNOUNCEMENTS' ? 'discordAnnouncementCard' : 'xShowsAnnouncementCard'; consolidateNotificationDeliveryCard(card, kind); section.append(card); group.append(section); }
    notifications.append(group);
  }
  group.hidden = !enabled;
  if (enabled) {
    // The shared outbox is the single delivery authority.  Prevent the older
    // Discord-only automatic route from creating duplicate announcements.
    if (window.LIRISQ_DISCORD_INTEGRATION?.status?.().autoPost) window.LIRISQ_DISCORD_INTEGRATION.setAutoPost(false);
    void renderDiscordDashboard(); renderXAnnouncer();
  }
}
function consolidateNotificationDeliveryCard(card, kind) {
  if (card.dataset.notificationDeliveryConsolidated === kind) return;
  card.dataset.notificationDeliveryConsolidated = kind;
  card.querySelector('.eyebrow').textContent = 'DELIVERY INTEGRATION';
  const note = document.createElement('p'); note.className = 'queue-note';
  if (kind === 'discord') {
    note.textContent = 'Configure the private webhook connection here. Create, approve, and send announcements from the Stream Notifications outbox.';
    const actionRow = card.querySelector('#discordEnable')?.closest('.fields');
    card.querySelector('#discordAutoPost').hidden = true;
    card.querySelector('#discordRefresh').hidden = true;
    for (const child of [...card.children]) {
      if (child === actionRow || child.matches('.eyebrow, h2, #discordStatus, #discordServerSetup')) continue;
      child.hidden = true;
    }
    card.querySelector('#discordStatus')?.after(note);
    return;
  }
  note.textContent = 'Enable X delivery here. Create, approve, copy, and open X drafts from the Stream Notifications outbox; LirisQ never posts to X automatically.';
  const actionRow = card.querySelector('#xAnnouncerEnable')?.closest('.fields');
  for (const child of [...card.children]) {
    if (child === actionRow || child.matches('.eyebrow, h2, #xAnnouncerStatus')) continue;
    child.hidden = true;
  }
  card.querySelector('#xAnnouncerStatus')?.after(note);
}
document.querySelector('#notificationEnable')?.addEventListener('click', async () => {
  const plugin=window.LirisQStreamNotificationsPlugin;
  const feedback=document.querySelector('#notificationFeedback');
  try {
    if(plugin.status().active) { stopNotificationDraftScheduler(); await lirisqPluginHost.disable(plugin.id); }
    else {
      const item=lirisqPluginHost.inventory().find(p=>p.id===plugin.id);
      const approvals=JSON.parse(localStorage.getItem('lirisq-plugin-approvals-v1')||'{}');
      if(approvals[plugin.id]?.version!==item.version){
        if(!window.confirm('Enable local Stream Notifications? Changes will create drafts only, never automatic posts.'))return;
        approvals[plugin.id]={version:item.version,permissions:[...item.permissions]};
        localStorage.setItem('lirisq-plugin-approvals-v1',JSON.stringify(approvals));
      }
      await lirisqPluginHost.enable(plugin.id);
      plugin.reconcileShows(shows);
      plugin.reconcileQueue(activeShowId,state);
      startNotificationDraftScheduler();
    }
    feedback.textContent='';renderNotifications();
  } catch(error){feedback.textContent=String(error.message||error);}
});
document.querySelector('#notificationRefresh')?.addEventListener('click',renderNotifications);
document.querySelector('#notificationZone')?.addEventListener('change',renderNotifications);
document.querySelector('#notificationSaveRules')?.addEventListener('click',()=>{
  const feedback=document.querySelector('#notificationFeedback');
  try { const raw=document.querySelector('#notificationRules').value.trim(); const values=raw?raw.split(',').map(value=>Number(value.trim())):[]; window.LirisQStreamNotificationsPlugin.setReminderMinutes(values); feedback.textContent='Reminder rules saved in this browser.';renderNotifications(); }
  catch(error){feedback.textContent=String(error.message||error);}
});
document.querySelector('#notificationPrepareDue')?.addEventListener('click',()=>{
  const feedback=document.querySelector('#notificationFeedback');
  try { const plugin=window.LirisQStreamNotificationsPlugin; if(!plugin.status().active)throw new Error('Enable Stream Notifications first'); const timezone=document.querySelector('#notificationZone').value; if(!timezone)throw new Error('Select and save a show time zone first'); const rows=plugin.prepareDue(shows,timezone,new Date(),5);renderNotifications();feedback.textContent=rows.length+' reminder draft(s) prepared. Nothing was published.'; }
  catch(error){feedback.textContent=String(error.message||error);}
});

let notificationDraftTimer=null;
function stopNotificationDraftScheduler(){if(notificationDraftTimer!==null){clearInterval(notificationDraftTimer);notificationDraftTimer=null;}}
function startNotificationDraftScheduler(){
  stopNotificationDraftScheduler();
  const plugin=window.LirisQStreamNotificationsPlugin;
  if(!plugin?.status().active||!plugin.configuration().autoPrepare)return;
  const tick=()=>{
    if(!plugin.status().active||!plugin.configuration().autoPrepare){stopNotificationDraftScheduler();return;}
    try{const created=plugin.prepareDue(shows,plugin.configuration().timezone,new Date(),2);if(created.length&&document.querySelector('#notifications')?.classList.contains('active'))renderNotifications();}
    catch(error){console.warn('Notification reminder preparation:',error);}
  };
  tick();notificationDraftTimer=setInterval(tick,60000);
}
document.querySelector('#notificationSavePreferences')?.addEventListener('click',()=>{
  const plugin=window.LirisQStreamNotificationsPlugin;
  const feedback=document.querySelector('#notificationFeedback');
  try {
    const types=Object.fromEntries([...document.querySelectorAll('[data-notification-type]')].map(input=>[input.dataset.notificationType,input.checked]));
    plugin.configure({timezone:document.querySelector('#notificationZone').value,autoPrepare:document.querySelector('#notificationAutoPrepare').checked,types});
    startNotificationDraftScheduler();feedback.textContent='Notification preferences saved locally.';renderNotifications();
  }catch(error){feedback.textContent=String(error.message||error);}
});
document.querySelector('#notificationCreateDraft')?.addEventListener('click',()=>{
  const feedback=document.querySelector('#notificationFeedback');
  try{const plugin=window.LirisQStreamNotificationsPlugin;if(!plugin.status().active)throw new Error('Enable Stream Notifications first');plugin.createDraft(document.querySelector('#notificationDraft').value);document.querySelector('#notificationDraft').value='';renderNotifications();feedback.textContent='Draft added to outbox.';}
  catch(error){feedback.textContent=String(error.message||error);}
});
document.querySelector('#notificationFilter')?.addEventListener('change',renderNotifications);
document.querySelector('#notificationExport')?.addEventListener('click',()=>{
  const data=window.LirisQStreamNotificationsPlugin.exportHistory();
  const url=URL.createObjectURL(new Blob([data],{type:'application/json'}));
  const link=document.createElement('a');link.href=url;link.download='lirisq-notifications-'+new Date().toISOString().slice(0,10)+'.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
});
document.querySelector('#notificationClear')?.addEventListener('click',()=>{
  if(!window.confirm('Permanently clear all local notification history? This cannot be undone.'))return;
  const feedback=document.querySelector('#notificationFeedback');
  try{const count=window.LirisQStreamNotificationsPlugin.clearHistory();renderNotifications();feedback.textContent=count+' notification(s) cleared.';}
  catch(error){feedback.textContent=String(error.message||error);}
});
const botPluginDefinitions = [
  ['LirisQSongRequestsPlugin','Song Requests','BOT FEATURES'],
  ['LirisQPlayControlsPlugin','Play Controls','BOT FEATURES'],
  ['LirisQQueuePriorityPlugin','Queue Priority','BOT FEATURES'],
  ['LirisQQueueAdministrationPlugin','Queue Administration','BOT FEATURES'],
  ['LirisQRulesPlugin','Rules','BOT FEATURES'],
  ['LirisQCommandAliasesPlugin','Command Aliases','BOT FEATURES'],
  ['LirisQStreamStatusMonitorPlugin','Stream Status Monitor','BOT FEATURES'],
  ['LirisQStreamNotificationsBotHookPlugin','Stream Notifications','BOT FEATURES'],
  ['LirisQViewerNotificationPreferencesPlugin','Viewer Preferences','BOT FEATURES'],
  ['LirisQNotificationHealthMonitorPlugin','Notification Health','BOT FEATURES'],
  ['LirisQTwitchLiveAdapterPlugin','Twitch','PLATFORM ADAPTERS'],
  ['LirisQYouTubeLiveAdapterPlugin','YouTube Live','PLATFORM ADAPTERS'],
  ['LirisQTikTokLiveAdapterPlugin','TikTok LIVE','PLATFORM ADAPTERS'],
  ['LirisQDouyinLiveAdapterPlugin','Douyin LIVE','PLATFORM ADAPTERS'],
  ['LirisQBilibiliLiveAdapterPlugin','Bilibili LIVE','PLATFORM ADAPTERS'],
  ['LirisQKickLiveAdapterPlugin','Kick','PLATFORM ADAPTERS'],
  ['LirisQXLiveAdapterPlugin','X','PLATFORM ADAPTERS']
];
const builtinBotFeatureIds = new Set(botPluginDefinitions.filter(([, , category]) => category === 'BOT FEATURES').map(([globalName]) => window[globalName]?.id).filter(Boolean));
const botPluginDescriptionFallbacks = Object.freeze({
  'lirisq.twitch-live-adapter': 'Provides signed Twitch EventSub and approved chat delivery after server setup and authorization.',
  'lirisq.youtube-live-adapter': 'Provides authorized YouTube Live Chat transport after server setup and channel authorization.',
  'lirisq.tiktok-live-adapter': 'Provides safe TikTok LIVE event replay only. No public general live-chat transport is configured.',
  'lirisq.douyin-live-adapter': 'Provides safe Douyin LIVE event replay only until an approved official LIVE SDK integration is configured.',
  'lirisq.bilibili-live-adapter': 'Provides safe Bilibili LIVE event replay only until an approved Open Live interaction application is configured.'
});
const pluginManagerCategories = new Map([
  ['lirisq.bot-core', 'BOT CORE'],
  ['lirisq.discord-integration', 'PLATFORM ADAPTERS'],
  ...botPluginDefinitions.map(([globalName, label, category]) => [window[globalName]?.id, category]).filter(([id]) => id)
]);
function renderBotPlugins(){
 renderPlatformPluginConfigurations();
}
document.querySelector('#botPluginRefresh')?.addEventListener('click',renderBotPlugins);
const xPlugin = () => window.LirisQXShowAnnouncerPlugin;
function updateXPreview() {
  const draft = document.querySelector('#xAnnouncerDraft').value;
  const count = xPlugin().characterCount(draft);
  const remaining = 280 - count;
  const counter = document.querySelector('#xAnnouncerCount');
  counter.textContent = count + ' / 280 characters — ' + remaining + ' remaining' + (remaining < 0 ? ' (too long)' : '');
  counter.style.color = remaining < 0 ? 'var(--hot)' : remaining < 20 ? 'var(--gold)' : '';
  document.querySelector('#xAnnouncerPreview').textContent = draft || 'Generate a draft to preview it.';
  document.querySelector('#xAnnouncerOpen').disabled = !xPlugin().status().active || !draft.trim() || remaining < 0;
}

function renderXAnnouncer() {
  const plugin = xPlugin();
  const enabled = plugin.status().active;
  if (document.activeElement !== document.querySelector('#xAnnouncerTimezone')) document.querySelector('#xAnnouncerTimezone').value = plugin.timezone();
  document.querySelector('#xAnnouncerStatus').hidden = true;
  document.querySelector('#xAnnouncerEnable').textContent = enabled ? 'DISABLE PLUGIN' : 'ENABLE PLUGIN';
  const select = document.querySelector('#xAnnouncerShow');
  const selected = select.value;
  select.replaceChildren();
  for (const show of shows || []) {
    const option = document.createElement('option');
    option.value = show.id;
    option.textContent = show.title + ' — ' + show.date + ' ' + show.time;
    select.append(option);
  }
  if ([...select.options].some(option => option.value === selected)) select.value = selected;
  const occurrence = document.querySelector('#xAnnouncerOccurrence');
  const priorDate = occurrence.value;
  occurrence.replaceChildren();
  const show = (shows || []).find(item => item.id === select.value);
  for (const date of show ? plugin.occurrences(show, new Date(), 8, plugin.timezone()) : []) {
    const option = document.createElement('option');
    option.value = date;
    option.textContent = date + ' at ' + (show.time || 'Time TBD');
    occurrence.append(option);
  }
  if ([...occurrence.options].some(option => option.value === priorDate)) occurrence.value = priorDate;
  const templateField = document.querySelector('#xAnnouncerTemplate');
  if (!templateField.dataset.initialized) { templateField.value = plugin.template(); templateField.dataset.initialized = 'true'; }
  const timePreview = document.querySelector('#xAnnouncerTimePreview');
  try {
    timePreview.textContent = show && occurrence.value ? 'Show starts: ' + plugin.timeDetails({ ...show, date: occurrence.value }).readable + '. Use {viewerTime} in a template for a viewer-local conversion link.' : 'Select an upcoming occurrence.';
  } catch (error) { timePreview.textContent = String(error.message || error); }
  document.querySelector('#xAnnouncerGenerate').disabled = !enabled || !select.value || !occurrence.value;
  if (!document.querySelector('#xAnnouncerLink').value) document.querySelector('#xAnnouncerLink').value = plugin.defaultLink();
  updateXPreview();
}
document.querySelector('#xAnnouncerStatus').hidden = true;
document.querySelector('#discordStatus').hidden = true;
document.querySelector('#xAnnouncerShow')?.addEventListener('change', renderXAnnouncer);
document.querySelector('#xAnnouncerOccurrence')?.addEventListener('change', renderXAnnouncer);
document.querySelector('#xAnnouncerSaveTimezone')?.addEventListener('click', () => {
  const feedback = document.querySelector('#xAnnouncerFeedback');
  try { xPlugin().setTimezone(document.querySelector('#xAnnouncerTimezone').value.trim()); feedback.textContent = 'Show time zone saved in this browser.'; renderXAnnouncer(); }
  catch (error) { feedback.textContent = String(error.message || error); }
});
document.querySelector('#xAnnouncerSaveLink')?.addEventListener('click', () => {
  const feedback = document.querySelector('#xAnnouncerFeedback');
  try { xPlugin().setDefaultLink(document.querySelector('#xAnnouncerLink').value.trim()); feedback.textContent = 'Default show link saved in this browser.'; }
  catch (error) { feedback.textContent = String(error.message || error); }
});
document.querySelector('#xAnnouncerPreset')?.addEventListener('change', () => {
  const choice = document.querySelector('#xAnnouncerPreset').value;
  document.querySelector('#xAnnouncerTemplate').value = choice === 'custom' ? xPlugin().template() : xPlugin().presetTemplate(choice);
  document.querySelector('#xAnnouncerFeedback').textContent = 'Preset selected. Generate a draft or save this as your custom template.';
});
document.querySelector('#xAnnouncerEnable')?.addEventListener('click', async () => {
  const plugin = xPlugin();
  try {
    if (plugin.status().active) await lirisqPluginHost.disable(plugin.id);
    else {
      const item = lirisqPluginHost.inventory().find(p => p.id === plugin.id);
      const approvals = JSON.parse(localStorage.getItem('lirisq-plugin-approvals-v1') || '{}');
      if (approvals[plugin.id]?.version !== item.version) {
        if (!window.confirm('Enable X Show Announcer? It opens X only when you click and never posts automatically.')) return;
        approvals[plugin.id] = { version: item.version, permissions: [...item.permissions] };
        localStorage.setItem('lirisq-plugin-approvals-v1', JSON.stringify(approvals));
      }
      await lirisqPluginHost.enable(plugin.id);
    }
    renderXAnnouncer();
  } catch (error) { document.querySelector('#xAnnouncerFeedback').textContent = String(error.message || error); }
});
document.querySelector('#xAnnouncerSave')?.addEventListener('click', () => {
  try { xPlugin().setTemplate(document.querySelector('#xAnnouncerTemplate').value); document.querySelector('#xAnnouncerFeedback').textContent = 'Template saved in this browser.'; }
  catch (error) { document.querySelector('#xAnnouncerFeedback').textContent = String(error.message || error); }
});
document.querySelector('#xAnnouncerReset')?.addEventListener('click', () => {
  xPlugin().resetTemplate();
  document.querySelector('#xAnnouncerTemplate').value = xPlugin().template();
  document.querySelector('#xAnnouncerPreset').value = 'custom';
  document.querySelector('#xAnnouncerFeedback').textContent = 'Default template restored.';
});
document.querySelector('#xAnnouncerGenerate')?.addEventListener('click', () => {
  const show = (shows || []).find(item => item.id === document.querySelector('#xAnnouncerShow').value);
  const link = document.querySelector('#xAnnouncerLink').value.trim();
  const feedback = document.querySelector('#xAnnouncerFeedback');
  try {
    if (link && !/^https?:\/\/\S+$/i.test(link)) throw new Error('Enter an HTTP(S) show link');
    if (!xPlugin().status().active) throw new Error('Enable the plugin first');
    const date = document.querySelector('#xAnnouncerOccurrence').value;
    if (!date) throw new Error('No upcoming show occurrence available');
    xPlugin().setTimezone(document.querySelector('#xAnnouncerTimezone').value.trim());
    const draft = xPlugin().compose({ ...show, date }, link, document.querySelector('#xAnnouncerTemplate').value);
    if (xPlugin().characterCount(draft) > 280) throw new Error('Generated post exceeds 280 characters. Shorten the template or link.');
    document.querySelector('#xAnnouncerDraft').value = draft;
    feedback.textContent = 'Draft generated. Review the show date before publishing.';
    renderXAnnouncer();
  } catch (error) { feedback.textContent = String(error.message || error); }
});
document.querySelector('#xAnnouncerDraft')?.addEventListener('input', updateXPreview);
document.querySelector('#xAnnouncerCopy')?.addEventListener('click', async () => {
  const feedback = document.querySelector('#xAnnouncerFeedback');
  try { await navigator.clipboard.writeText(document.querySelector('#xAnnouncerDraft').value); feedback.textContent = 'Draft copied.'; }
  catch (_) { feedback.textContent = 'Clipboard unavailable. Select and copy the draft manually.'; }
});
document.querySelector('#xAnnouncerOpen')?.addEventListener('click', () => {
  const draft = document.querySelector('#xAnnouncerDraft').value;
  const feedback = document.querySelector('#xAnnouncerFeedback');
  try {
    const url = xPlugin().intentUrl(draft);
    if (!window.confirm('Open X with this draft? You must review and publish the post on X.\n\n' + draft)) return;
    const tab = window.open(url, '_blank', 'noopener,noreferrer');
    feedback.textContent = tab ? 'X composer opened. No post was published by LirisQ.' : 'Popup may be blocked. Copy the draft and open X manually.';
  } catch (error) { feedback.textContent = String(error.message || error); }
});
window.LIRISQ_DISCORD_INTEGRATION = Object.freeze({
  status: () => window.LirisQDiscordIntegrationPlugin.status(),
  drafts: () => window.LirisQDiscordIntegrationPlugin.drafts(),
  clear: () => window.LirisQDiscordIntegrationPlugin.clear(),
  setAutoPost: enabled => window.LirisQDiscordIntegrationPlugin.setAutoPost(enabled),
  sendTest: () => window.LirisQDiscordIntegrationPlugin.sendTest(),
  eventSettings: () => window.LirisQDiscordIntegrationPlugin.eventSettings(),
  setEventEnabled: (event, enabled) => window.LirisQDiscordIntegrationPlugin.setEventEnabled(event, enabled),
  templates: () => window.LirisQDiscordIntegrationPlugin.templates(),
  setTemplate: (event, value) => window.LirisQDiscordIntegrationPlugin.setTemplate(event, value),
  resetTemplates: () => window.LirisQDiscordIntegrationPlugin.resetTemplates(),
  preview: (event, template) => window.LirisQDiscordIntegrationPlugin.preview(event, template),
  sendManual: content => window.LirisQDiscordIntegrationPlugin.sendManual(content),
  deliveryHistory: () => window.LirisQDiscordIntegrationPlugin.deliveryHistory(),
  retryDelivery: id => window.LirisQDiscordIntegrationPlugin.retryDelivery(id)
});
const discordTransportConfigurationKey = 'lirisq-discord-transport-v1';
function discordTransportConfiguration() { return storedJson(discordTransportConfigurationKey, { kind: 'node', phpEndpoint: '' }); }
function discordEndpoint(action) { const config = discordTransportConfiguration(); if (config.kind === 'php' && /^https:\/\//.test(String(config.phpEndpoint || ''))) { const url = new URL(config.phpEndpoint); url.searchParams.set('action', action); return url.toString(); } return `/api/discord/${action}`; }
function renderDiscordServerSetup() {
  const dashboard = document.querySelector('#discord .card, #discordAnnouncementCard'); if (!dashboard) return;
  let setup = dashboard.querySelector('#discordServerSetup');
  if (!setup) { setup = document.createElement('details'); setup.id = 'discordServerSetup'; setup.className = 'optional-addons'; setup.innerHTML = '<summary>DISCORD SERVER SETUP — EASY 1–2–3</summary><div></div>'; dashboard.querySelector('h2')?.after(setup); }
  const config = discordTransportConfiguration(); const content = setup.querySelector('div');
  content.innerHTML = `<p class="queue-note"><strong>1.</strong> Create a Discord channel webhook and keep its URL private. <strong>2.</strong> Choose where LirisQ will hold that URL. <strong>3.</strong> Save the server choice below, enable Discord, and use SEND TEST ANNOUNCEMENT.</p><div class="setting"><div><h3>SERVER COMPANION</h3><p>Node is for a Node-capable host. PHP is for a PHP host such as DreamHost. The browser never receives the webhook URL.</p></div><div><label><input type="radio" name="discordTransport" value="node" ${config.kind !== 'php' ? 'checked' : ''}> NODE SERVER</label><br><label><input type="radio" name="discordTransport" value="php" ${config.kind === 'php' ? 'checked' : ''}> PHP SERVER</label><br><input data-discord-php-endpoint aria-label="PHP Discord endpoint" placeholder="https://your-domain.example/lirisq-api/plugins/discord/discord.php" value="${String(config.phpEndpoint || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"><button type="button" class="btn" data-save-discord-transport>SAVE SERVER CHOICE</button></div></div><div class="twitch-server-guide"><a class="btn" data-discord-server-guide target="_blank" rel="noreferrer"></a></div>`;
  const updateGuide = () => { const kind = content.querySelector('input[name="discordTransport"]:checked').value; const guide = content.querySelector('[data-discord-server-guide]'); guide.href = kind === 'php' ? '/docs/DISCORD-PHP-SETUP.md' : '/docs/DISCORD-NODE-SETUP.md'; guide.textContent = kind === 'php' ? 'OPEN PHP DISCORD SETUP GUIDE' : 'OPEN NODE DISCORD SETUP GUIDE'; };
  content.querySelectorAll('input[name="discordTransport"]').forEach(input => input.addEventListener('change', updateGuide)); updateGuide();
  content.querySelector('[data-save-discord-transport]').addEventListener('click', () => { const kind = content.querySelector('input[name="discordTransport"]:checked').value; const phpEndpoint = content.querySelector('[data-discord-php-endpoint]').value.trim(); if (kind === 'php' && !/^https:\/\//.test(phpEndpoint)) return say('ENTER A PUBLIC HTTPS PHP DISCORD ENDPOINT'); localStorage.setItem(discordTransportConfigurationKey, JSON.stringify({ kind, phpEndpoint })); renderDiscordServerSetup(); void renderDiscordDashboard(); say(`DISCORD ${kind === 'php' ? 'PHP' : 'NODE'} SERVER SELECTED`); });
}
async function renderDiscordDashboard() {
  renderDiscordServerSetup();
  const plugin = window.LIRISQ_DISCORD_INTEGRATION;
  const status = plugin.status();
  const label = document.querySelector('#discordStatus');
  const enable = document.querySelector('#discordEnable');
  const auto = document.querySelector('#discordAutoPost');
  if (!label) return;
  let configured = false;
  try {
    const response = await fetch(discordEndpoint('status'), { cache: 'no-store' });
    configured = response.ok && (await response.json()).configured === true;
  } catch (_) {}
  label.hidden = false;
  label.textContent = (configured ? 'Server webhook configured. ' : 'Server webhook unavailable. ') +
    (status.autoPost ? 'Automatic posting ON. ' : 'Automatic posting OFF. ') +
    status.sent + ' sent, ' + status.failed + ' failed, ' + status.pending + ' pending.' +
    (status.lastError ? ' Last error: ' + status.lastError : '');
  enable.textContent = status.active ? 'DISABLE PLUGIN' : 'ENABLE PLUGIN';
  auto.textContent = status.autoPost ? 'DISABLE AUTO POSTING' : 'ENABLE AUTO POSTING';
  auto.disabled = !status.active || (!status.autoPost && !configured);
  document.querySelector('#discordTest').disabled = !status.active || !configured || status.pending > 0;
  document.querySelector('#discordSendManual').disabled = !status.active || !configured || status.pending > 0;
  const events = plugin.eventSettings();
  for (const [id, event] of [['discordEventQueued', 'song.queued'], ['discordEventStarted', 'song.started'], ['discordEventFinished', 'song.finished']]) {
    const input = document.querySelector('#' + id);
    if (input) { input.checked = events[event]; input.disabled = !status.active; }
  }
  const templates = plugin.templates();
  for (const [id, event] of [['discordTemplateQueued', 'song.queued'], ['discordTemplateStarted', 'song.started'], ['discordTemplateFinished', 'song.finished']]) {
    const field = document.querySelector('#' + id);
    if (field && document.activeElement !== field) field.value = templates[event];
  }
  const preview = document.querySelector('#discordTemplatePreview');
  if (preview) preview.textContent = [['discordTemplateQueued', 'song.queued'], ['discordTemplateStarted', 'song.started'], ['discordTemplateFinished', 'song.finished']].map(([id, event]) => plugin.preview(event, document.querySelector('#' + id).value)).join(' | ');
  const history = document.querySelector('#discordDeliveryHistory');
  history.replaceChildren();
  const filter = document.querySelector('#discordHistoryFilter')?.value || 'all';
  for (const entry of plugin.deliveryHistory().slice().reverse().filter(item => filter === 'all' || item.state === filter)) {
    const row = document.createElement('p');
    const stamp = document.createElement('strong');
    stamp.textContent = entry.state.toUpperCase() + ' — ' + entry.kind + ' — ' + new Date(entry.createdAt).toLocaleTimeString() + ': ';
    const content = document.createElement('span');
    content.textContent = entry.content;
    row.append(stamp, content);
    if (entry.detail) {
      const detail = document.createElement('span');
      detail.textContent = ' (' + entry.detail + ')';
      row.append(detail);
    }
    if (entry.state === 'failed' && status.active && configured && !entry.retrying) {
      const retry = document.createElement('button');
      retry.type = 'button'; retry.className = 'btn'; retry.textContent = 'RETRY';
      retry.addEventListener('click', async () => {
        if (!window.confirm('Retry this failed Discord announcement? It may have been delivered despite the error.\\n\\n' + entry.content)) return;
        retry.disabled = true;
        const feedback = document.querySelector('#discordRetryFeedback');
        try { await plugin.retryDelivery(entry.id); feedback.textContent = 'Retry accepted by Discord.'; }
        catch (error) { feedback.textContent = String(error.message || error); }
        finally { await renderDiscordDashboard(); }
      });
      row.append(' ', retry);
    }
    history.append(row);
  }
  if (!history.children.length) history.textContent = 'No deliveries yet.';
  const drafts = document.querySelector('#discordDrafts');
  drafts.replaceChildren();
  for (const entry of plugin.drafts().slice().reverse()) {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:8px;align-items:center;margin:8px 0';
    const content = document.createElement('span');
    content.textContent = entry.content;
    const copy = document.createElement('button');
    copy.type = 'button'; copy.className = 'btn'; copy.textContent = 'COPY';
    copy.addEventListener('click', () => navigator.clipboard.writeText(entry.content).catch(() => {}));
    row.append(content, copy);
    drafts.append(row);
  }
  if (!drafts.children.length) drafts.textContent = 'No announcements yet.';
}
for (const id of ['discordTemplateQueued', 'discordTemplateStarted', 'discordTemplateFinished']) {
  document.querySelector('#' + id)?.addEventListener('input', () => {
    const plugin = window.LIRISQ_DISCORD_INTEGRATION;
    document.querySelector('#discordTemplatePreview').textContent = [['discordTemplateQueued', 'song.queued'], ['discordTemplateStarted', 'song.started'], ['discordTemplateFinished', 'song.finished']].map(([field, event]) => plugin.preview(event, document.querySelector('#' + field).value)).join(' | ');
  });
}
document.querySelector('#discordSendManual')?.addEventListener('click', async () => {
  const plugin = window.LIRISQ_DISCORD_INTEGRATION;
  const message = document.querySelector('#discordManualMessage').value;
  const feedback = document.querySelector('#discordManualFeedback');
  if (!message.trim() || message.length > 1000) { feedback.textContent = 'Enter a message of 1–1000 characters.'; return; }
  if (!window.confirm('Send this exact announcement to your Discord channel?\\n\\n' + message)) return;
  const button = document.querySelector('#discordSendManual');
  button.disabled = true;
  try {
    await plugin.sendManual(message);
    feedback.textContent = 'Announcement accepted by Discord.';
    document.querySelector('#discordManualMessage').value = '';
  } catch (error) { feedback.textContent = String(error.message || error); }
  finally { await renderDiscordDashboard(); }
});
document.querySelector('#discordSaveTemplates')?.addEventListener('click', async () => {
  const plugin = window.LIRISQ_DISCORD_INTEGRATION;
  const values = [['discordTemplateQueued', 'song.queued'], ['discordTemplateStarted', 'song.started'], ['discordTemplateFinished', 'song.finished']].map(([id, event]) => [event, document.querySelector('#' + id).value]);
  const feedback = document.querySelector('#discordTemplateFeedback');
  try {
    for (const [event, value] of values) {
      if (!value.trim() || value.length > 500 || (value.match(/\\{[^{}]*\\}/g) || []).some(token => !['{title}', '{artist}', '{queue}'].includes(token))) throw new Error('Invalid template: use 1–500 characters and supported placeholders');
    }
    for (const [event, value] of values) plugin.setTemplate(event, value);
    feedback.textContent = 'Templates saved.';
    await renderDiscordDashboard();
  } catch (error) { feedback.textContent = String(error.message || error); }
});
document.querySelector('#discordResetTemplates')?.addEventListener('click', async () => {
  if (!window.confirm('Restore all three Discord announcement templates?')) return;
  window.LIRISQ_DISCORD_INTEGRATION.resetTemplates();
  document.querySelector('#discordTemplateFeedback').textContent = 'Default templates restored.';
  await renderDiscordDashboard();
});
document.querySelector('#discordTest')?.addEventListener('click', async () => {
  if (!window.confirm('Send one test announcement to the configured Discord channel?')) return;
  const button = document.querySelector('#discordTest');
  button.disabled = true;
  try {
    await window.LIRISQ_DISCORD_INTEGRATION.sendTest();
    document.querySelector('#discordStatus').textContent = 'Test announcement accepted by Discord.';
  } catch (error) {
    document.querySelector('#discordStatus').textContent = String(error.message || error);
  } finally {
    await renderDiscordDashboard();
  }
});
for (const [id, event] of [['discordEventQueued', 'song.queued'], ['discordEventStarted', 'song.started'], ['discordEventFinished', 'song.finished']]) {
  document.querySelector('#' + id)?.addEventListener('change', change => {
    window.LIRISQ_DISCORD_INTEGRATION.setEventEnabled(event, change.target.checked);
  });
}
document.querySelector('#discordHistoryFilter')?.addEventListener('change', renderDiscordDashboard);
document.querySelector('#discordRefresh')?.addEventListener('click', renderDiscordDashboard);
document.querySelector('#discordEnable')?.addEventListener('click', async () => {
  try {
    const id = 'lirisq.discord-integration';
    if (window.LIRISQ_DISCORD_INTEGRATION.status().active) await lirisqPluginHost.disable(id);
    else {
      const item = lirisqPluginHost.inventory().find(p => p.id === id);
      const approvals = JSON.parse(localStorage.getItem('lirisq-plugin-approvals-v1') || '{}');
      if (approvals[id]?.version !== item.version) {
        if (!window.confirm('Allow Discord Integration to read queue events?')) return;
        approvals[id] = { version: item.version, permissions: [...item.permissions] };
        localStorage.setItem('lirisq-plugin-approvals-v1', JSON.stringify(approvals));
      }
      await lirisqPluginHost.enable(id);
    }
    await renderDiscordDashboard();
  } catch (error) { document.querySelector('#discordStatus').textContent = String(error); }
});
document.querySelector('#discordAutoPost')?.addEventListener('click', async () => {
  const status = window.LIRISQ_DISCORD_INTEGRATION.status();
  if (!status.autoPost && !window.confirm('Automatically post future song announcements to your configured Discord channel?')) return;
  window.LIRISQ_DISCORD_INTEGRATION.setAutoPost(!status.autoPost);
  await renderDiscordDashboard();
});
function renderAnalyticsDashboard() {
  const data = window.LIRISQ_QUEUE_ANALYTICS.snapshot();
  const lanesPanel = document.querySelector('#analyticsLanes');
  if (lanesPanel) {
    lanesPanel.replaceChildren();
    for (const [name, label] of [['vip', 'VIP'], ['standard', 'STANDARD'], ['unknown', 'UNKNOWN']]) {
      const stats = data.lanes?.[name] || { requests: 0, starts: 0, finishes: 0 };
      const card = document.createElement('div');
      card.className = 'card';
      card.style.padding = '16px';
      const heading = document.createElement('h3');
      heading.textContent = label;
      const details = document.createElement('div');
      details.textContent = stats.requests + ' requests · ' + stats.starts + ' starts · ' + stats.finishes + ' finishes';
      card.append(heading, details);
      lanesPanel.append(card);
    }
  }
  const retentionSelect = document.querySelector('#analyticsRetention');
  if (retentionSelect) retentionSelect.value = String(window.LIRISQ_QUEUE_ANALYTICS.retention());
  const historyPanel = document.querySelector('#analyticsHistory');
  if (historyPanel) {
    const history = window.LIRISQ_QUEUE_ANALYTICS.history();
    historyPanel.replaceChildren();
    if (!history.length) historyPanel.textContent = 'No saved sessions.';
    for (const entry of history.slice().reverse()) {
      const row = document.createElement('div');
      row.textContent = new Date(entry.endedAt).toLocaleString() + ' — ' +
        entry.requests + ' requests, ' + entry.starts + ' started, ' + entry.finishes + ' finished' + (entry.recovered ? ' (recovered checkpoint)' : '');
      historyPanel.append(row);
    }
  }
  const chart = document.querySelector('#analyticsChart');
  if (chart) {
    chart.replaceChildren();
    const points = data.requestsByHour.slice(-24);
    if (!points.length) chart.textContent = 'No hourly request data yet.';
    else {
      const max = Math.max(1, ...points.map(point => point.count));
      const bars = document.createElement('div');
      bars.style.cssText = 'display:flex;align-items:flex-end;gap:6px;min-height:140px;overflow-x:auto;padding:8px 0';
      for (const point of points) {
        const column = document.createElement('div');
        column.style.cssText = 'min-width:32px;flex:1;text-align:center';
        const count = document.createElement('div');
        count.textContent = String(point.count);
        count.style.fontSize = '12px';
        const bar = document.createElement('div');
        bar.style.cssText = 'background:var(--cyan,#61e5f5);border-radius:4px 4px 0 0;min-height:3px';
        bar.style.height = Math.round(point.count / max * 110) + 'px';
        bar.title = point.hour + ': ' + point.count + ' requests';
        const label = document.createElement('div');
        label.textContent = point.hour.slice(11) + ':00';
        label.style.fontSize = '10px';
        column.append(count, bar, label);
        bars.append(column);
      }
      chart.append(bars);
    }
  }
  const history = window.LIRISQ_QUEUE_ANALYTICS.history();
  const selectA = document.querySelector('#analyticsCompareA');
  const selectB = document.querySelector('#analyticsCompareB');
  if (selectA && selectB) {
    const priorA = selectA.value;
    const priorB = selectB.value;
    const fill = (select, prior, fallback) => {
      select.replaceChildren();
      history.forEach((item, index) => {
        const option = document.createElement('option');
        option.value = String(index);
        option.textContent = new Date(item.endedAt).toLocaleString() + (item.recovered ? ' (recovered)' : '');
        select.append(option);
      });
      select.value = history[Number(prior)] && prior !== '' ? prior : String(fallback);
    };
    fill(selectA, priorA, Math.max(0, history.length - 2));
    fill(selectB, priorB, Math.max(0, history.length - 1));
    const comparison = document.querySelector('#analyticsComparison');
    comparison.replaceChildren();
    if (history.length < 2) comparison.textContent = 'Save at least two sessions to compare results.';
    else {
      const first = history[Number(selectA.value)];
      const second = history[Number(selectB.value)];
      for (const [label, key] of [['Requests', 'requests'], ['Started', 'starts'], ['Finished', 'finishes'], ['Average wait (ms)', 'averageWaitMs'], ['Completion rate (%)', 'completionRatePercent']]) {
        const cell = document.createElement('div');
        cell.className = 'card';
        cell.style.padding = '12px';
        const heading = document.createElement('div');
        heading.className = 'queue-note';
        heading.textContent = label;
        const values = document.createElement('div');
        values.textContent = String(first?.[key] ?? '—') + ' vs ' + String(second?.[key] ?? '—');
        cell.append(heading, values);
        comparison.append(cell);
      }
    }
  }
  const status = document.querySelector('#analyticsStatus');
  if (!status) return;
  status.textContent = data.enabled ? 'Recording aggregate queue activity for this session.' : 'Analytics is disabled. No events are being recorded.';
  document.querySelector('#analyticsEnable').textContent = data.enabled ? 'DISABLE ANALYTICS' : 'ENABLE ANALYTICS';
  const metrics = [
    ['Requests', data.requests], ['Songs started', data.starts], ['Songs finished', data.finishes],
    ['Average wait', data.averageWaitMs === null ? '—' : Math.round(data.averageWaitMs / 60000) + ' min'],
    ['Longest wait', data.maxWaitMs === null ? '—' : Math.round(data.maxWaitMs / 60000) + ' min'],
    ['Wait samples', data.waitSamples],
    ['Matched completion rate', data.completionRatePercent === null ? '—' : data.completionRatePercent + '%']
  ];
  const container = document.querySelector('#analyticsMetrics');
  container.replaceChildren(...metrics.map(([label, value]) => {
    const card = document.createElement('div');
    card.className = 'card';
    card.style.padding = '16px';
    const heading = document.createElement('div');
    heading.className = 'queue-note';
    heading.textContent = label;
    const number = document.createElement('h2');
    number.textContent = String(value);
    card.append(heading, number);
    return card;
  }));
  const songsPanel = document.querySelector('#analyticsSongs');
  if (songsPanel) {
    songsPanel.replaceChildren();
    const songs = Array.isArray(data.songs) ? data.songs.slice().reverse() : [];
    if (!songs.length) songsPanel.textContent = data.enabled ? 'No songs recorded in this session yet.' : 'Enable Queue Analytics to record song activity.';
    for (const song of songs) {
      const row = document.createElement('div'); row.className = 'analytics-song-row';
      row.style.cssText = 'display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px 14px;align-items:center;padding:10px 8px;border-bottom:1px solid var(--line);font:500 11px/1.35 "DM Mono",monospace';
      const stamp = song.startedAt || song.finishedAt;
      const time = stamp ? new Date(stamp).toLocaleTimeString([], { hour:'numeric', minute:'2-digit', second:'2-digit' }) : 'UNKNOWN TIME';
      const state = song.finishedAt ? 'FINISHED' : 'PLAYING';
      const identity = document.createElement('div'); identity.style.minWidth = '0';
      const title = document.createElement('strong'); title.textContent = song.title || 'UNTITLED SONG'; title.style.cssText = 'display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--ink)';
      const artist = document.createElement('span'); artist.textContent = song.artist || 'UNKNOWN ARTIST'; artist.style.color = 'var(--muted)';
      identity.append(title, artist);
      const meta = document.createElement('div'); meta.style.cssText = 'display:flex;align-items:center;justify-content:flex-end;gap:6px;flex-wrap:wrap;color:var(--muted);text-align:right';
      const stateTag = document.createElement('span'); stateTag.textContent = state; stateTag.style.cssText = `border:1px solid ${state === 'PLAYING' ? 'var(--cyan)' : 'var(--line)'};color:${state === 'PLAYING' ? 'var(--cyan)' : 'var(--muted)'};padding:1px 4px;font-size:10px`;
      const source = document.createElement('span'); source.textContent = String(song.source || 'queue').toUpperCase();
      const timestamp = document.createElement('time'); timestamp.textContent = time; timestamp.dateTime = stamp || '';
      meta.append(stateTag, source, timestamp); row.append(identity, meta);
      songsPanel.append(row);
    }
  }
  const hours = document.querySelector('#analyticsHours');
  hours.replaceChildren();
  if (!data.requestsByHour.length) { hours.textContent = 'No requests recorded.'; return; }
  for (const { hour, count } of data.requestsByHour) {
    const row = document.createElement('div');
    row.textContent = hour.replace('T', ' ') + ':00 — ' + count + ' request(s)';
    hours.append(row);
  }
}
document.querySelector('#analyticsRetention')?.addEventListener('change', event => {
  try { window.LIRISQ_QUEUE_ANALYTICS.setRetention(Number(event.target.value)); renderAnalyticsDashboard(); }
  catch (error) { document.querySelector('#analyticsStatus').textContent = String(error); }
});
document.querySelector('#analyticsExport')?.addEventListener('click', () => {
  const csv = window.LIRISQ_QUEUE_ANALYTICS.exportCsv();
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'lirisq-queue-analytics.csv';
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
document.querySelector('#analyticsCompareA')?.addEventListener('change', renderAnalyticsDashboard);
document.querySelector('#analyticsCompareB')?.addEventListener('change', renderAnalyticsDashboard);
document.querySelector('#analyticsRefresh')?.addEventListener('click', renderAnalyticsDashboard);
document.querySelector('#analyticsClear')?.addEventListener('click', () => {
  if (!window.confirm('Clear all Queue Analytics session statistics?')) return;
  window.LIRISQ_QUEUE_ANALYTICS.clear();
  renderAnalyticsDashboard();
});
document.querySelector('#analyticsEnable')?.addEventListener('click', async () => {
  try {
    const active = window.LIRISQ_QUEUE_ANALYTICS.snapshot().enabled;
    if (active) await lirisqPluginHost.disable('lirisq.queue-analytics');
    else {
      const plugin = lirisqPluginHost.inventory().find(item => item.id === 'lirisq.queue-analytics');
      const approvals = JSON.parse(localStorage.getItem('lirisq-plugin-approvals-v1') || '{}');
      if (approvals[plugin.id]?.version !== plugin.version ||
          JSON.stringify(approvals[plugin.id]?.permissions) !== JSON.stringify(plugin.permissions)) {
        if (!window.confirm('Allow Queue Analytics to read queue events?')) return;
        approvals[plugin.id] = { version: plugin.version, permissions: [...plugin.permissions] };
        localStorage.setItem('lirisq-plugin-approvals-v1', JSON.stringify(approvals));
      }
      await lirisqPluginHost.enable(plugin.id);
    }
    renderAnalyticsDashboard();
  } catch (error) { document.querySelector('#analyticsStatus').textContent = String(error); }
});
window.LIRISQ_PLUGIN_MANAGER = Object.freeze({
  inventory: () => lirisqPluginHost?.inventory() || [],
  async enable(id) { if (!lirisqPluginHost) throw new Error('Plugin host unavailable'); return lirisqPluginHost.enable(id); },
  async disable(id) { if (!lirisqPluginHost) throw new Error('Plugin host unavailable'); return lirisqPluginHost.disable(id); },
  approve(id) {
    const plugin = lirisqPluginHost?.inventory().find(item => item.id === id);
    if (!plugin) throw new Error('Unknown plugin');
    if (!window.confirm('Approve ' + id + ' permissions: ' + plugin.permissions.join(', ') + '?')) return false;
    const approvals = JSON.parse(localStorage.getItem('lirisq-plugin-approvals-v1') || '{}');
    approvals[id] = { version: plugin.version, permissions: plugin.permissions };
    localStorage.setItem('lirisq-plugin-approvals-v1', JSON.stringify(approvals));
    return true;
  },
  revoke(id) {
    const approvals = JSON.parse(localStorage.getItem('lirisq-plugin-approvals-v1') || '{}');
    delete approvals[id]; localStorage.setItem('lirisq-plugin-approvals-v1', JSON.stringify(approvals));
  }
});
function say(message) { const toast = document.querySelector('#toast'); toast.textContent = message; toast.classList.add('show'); clearTimeout(say.timer); say.timer = setTimeout(() => toast.classList.remove('show'), 2200); }
function external(url, label) { return `<a class="external" href="${url}" target="_blank" rel="noreferrer" aria-label="${label}">↗</a>`; }
function escaped(value) { return String(value).replace(/[&<>'"]/g, character => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' })[character]); }
const manualQueueEntry = document.querySelector('#addSong').closest('.card');
const freePlayPanel = document.createElement('div');
freePlayPanel.id = 'freePlayPanel'; freePlayPanel.hidden = true;
freePlayPanel.innerHTML = '<div class="queue-head"><h2 id="freePlayTitle">MGB FREE PLAY</h2><span class="queue-note" id="freePlayCount"></span></div><ol id="freePlayList" class="queue-list"></ol><p class="queue-note" id="freePlayNote">FREE PLAY IS CONTROLLED BY MGB\'S CAPTURED TAB.</p>';
manualQueueEntry.before(freePlayPanel);
function capturedRow(item, isPlaying = false) {
  const song = escaped(item.song); const artist = escaped(item.artist); const songUrl = item.url === '#' ? null : item.url; const artistUrl = item.artistUrl || songUrl;
  const songContent = songUrl ? `<a class="song" href="${escaped(songUrl)}" target="_blank" rel="noreferrer">${song}</a>${external(escaped(songUrl), `Open ${song}`)}` : `<span class="song">${song}</span>`;
  const artistContent = artistUrl ? `<a class="profile" href="${escaped(artistUrl)}" target="_blank" rel="noreferrer">${artist}</a>` : artist;
  return `<li class="row ${isPlaying ? 'playing' : ''}"><span class="grip" aria-hidden="true"></span><div><div class="songline">${isPlaying ? '<span class="playing-now">NOW PLAYING</span>' : ''}${songContent}<span class="artist">— ${artistContent}</span></div></div></li>`;
}

function row(item, queue, isPlaying = false) {
  return `<li class="row ${isPlaying ? 'playing' : ''}" draggable="true" data-id="${item.id}" data-queue="${queue}">
    <span class="grip" aria-hidden="true">⋮⋮</span>
    <div><div class="songline">${isPlaying ? '<span class="playing-now">NOW PLAYING</span>' : ''}<a class="song" href="${item.url}" target="_blank" rel="noreferrer">${item.song}</a>${external(item.url, `Open ${item.song}`)}<span class="artist">— <a class="profile" href="${profile(item.viewer)}" target="_blank" rel="noreferrer">${item.artist.replace(/^@/, '')}</a></span></div></div>
    <div class="controls"><button class="crown-action promote ${queue === 'vip' ? 'demote-crown' : ''}" data-id="${item.id}" data-queue="${queue}" aria-label="${queue === 'vip' ? 'Demote to Standard' : 'Promote to VIP'}" title="${queue === 'vip' ? 'Demote to Standard' : 'Promote to VIP'}">♛</button><button class="remove" data-id="${item.id}" data-queue="${queue}" aria-label="Remove ${item.song}" title="Remove song">×</button></div>
  </li>`;
}
let observedPlayback = null;
let lastObsOverlayPayload = '';
function publishObsOverlay(playing) {
  if (obsOverlayView) return;
  const payload = { playing, queue: { vip: state.vip, standard: state.standard } };
  const encoded = JSON.stringify(payload);
  if (encoded === lastObsOverlayPayload) return;
  lastObsOverlayPayload = encoded;
  void fetch('/api/obs/overlay', { method:'POST', headers:{'content-type':'application/json'}, body:encoded }).catch(() => {});
}
function render() {
  let queuedPlaying = activeQueuePlaybackId
    ? [...state.vip, ...state.standard].find(item => item.id === activeQueuePlaybackId) || null
    : null;
  if (activeQueuePlaybackId && !queuedPlaying) { activeQueuePlaybackId = null; persistQueuePlayback(); }
  const mgbPlaying = mgbCapturedPlayback.current;
  const playing = mgbPlaying || queuedPlaying;
  const playbackSource = mgbPlaying ? 'mgb' : queuedPlaying ? 'queue' : null;
  publishObsOverlay(playing);
  if (playing?.id !== observedPlayback?.id || playbackSource !== observedPlayback?.source) {
    if (observedPlayback?.source === 'queue') lirisqPluginHost?.emit('song.finished', { id: observedPlayback.id, title: observedPlayback.song, artist: observedPlayback.artist, source: 'queue' });
    if (playing && playbackSource === 'queue') lirisqPluginHost?.emit('song.started', { id: playing.id, title: playing.song, artist: playing.artist, source: 'queue' });
    observedPlayback = playing ? { id: playing.id, song: playing.song, artist: playing.artist, source: playbackSource } : null;
    if (document.querySelector('#songHistory')?.classList.contains('active')) renderSongHistory();
  }
  const freePlay = playbackMode === 'free-play';
  const compactLimit = 3;
  const vipOverflow = state.vip.length > compactLimit;
  const standardSuppressed = !queueViewportExpanded && vipOverflow;
  const vipRows = queueViewportExpanded ? state.vip : state.vip.slice(0, compactLimit);
  const standardRows = queueViewportExpanded ? state.standard : state.standard.slice(0, compactLimit);
  document.querySelector('#vipHeader').hidden = freePlay || state.vip.length === 0;
  document.querySelector('#vipList').hidden = freePlay || state.vip.length === 0;
  document.querySelector('#vipList').innerHTML = vipRows.map(x => row(x, 'vip', x.id === queuedPlaying?.id)).join('') + (!queueViewportExpanded && vipOverflow ? '<li><button class="queue-expander" data-queue-expand="true" aria-label="Expand VIP queue">…</button></li>' : '');
  document.querySelector('#standardHeader').hidden = freePlay;
  document.querySelector('#standardList').hidden = freePlay || standardSuppressed;
  document.querySelector('#standardList').innerHTML = standardSuppressed ? '' : standardRows.map(x => row(x, 'standard', x.id === queuedPlaying?.id)).join('') + (!queueViewportExpanded && state.standard.length > compactLimit ? '<li><button class="queue-expander" data-queue-expand="true" aria-label="Expand Standard queue">…</button></li>' : '');
  document.querySelector('#queue').classList.toggle('queue-viewport-expanded', queueViewportExpanded);
  const queueViewportExpand = document.querySelector('#queueViewportExpand');
  queueViewportExpand.hidden = freePlay;
  queueViewportExpand.textContent = queueViewportExpanded ? '⊡' : '⛶';
  queueViewportExpand.setAttribute('aria-label', queueViewportExpanded ? 'Collapse live queue' : 'Expand live queue');
  queueViewportExpand.title = queueViewportExpanded ? 'Collapse live queue' : 'Expand live queue';
  document.querySelector('#standardHeader').style.marginTop = state.vip.length === 0 ? '0' : '36px';
  document.querySelector('#vipCount').textContent = `${state.vip.length} SONG${state.vip.length === 1 ? '' : 'S'}`;
  document.querySelector('#standardCount').textContent = `${state.standard.length} SONG${state.standard.length === 1 ? '' : 'S'}`;
  document.querySelector('#queueTotal').textContent = `QUEUE LIST TOTAL: ${state.vip.length + state.standard.length} SONG${state.vip.length + state.standard.length === 1 ? '' : 'S'}`;
  document.querySelector('#queueTotal').hidden = freePlay;
  manualQueueEntry.hidden = freePlay;
  freePlayPanel.hidden = !freePlay;
  if (freePlay) {
    const playlist = mgbCapturedPlayback.playlist;
    const current = mgbCapturedPlayback.current;
    document.querySelector('#freePlayTitle').textContent = playlist.length ? 'MGB PLAYLIST' : 'MGB FREE PLAY';
    document.querySelector('#freePlayCount').textContent = playlist.length ? `${playlist.length} SONG${playlist.length === 1 ? '' : 'S'}` : '';
    document.querySelector('#freePlayList').innerHTML = playlist.length ? playlist.map(track => capturedRow(track, track.id === current?.id)).join('') : current ? capturedRow(current, true) : '<li class="row"><div><div class="songline">WAITING FOR MGB CAPTURED TAB</div></div></li>';
    document.querySelector('#freePlayNote').textContent = playlist.length ? 'THIS PLAYLIST IS PROVIDED BY MGB\'S CAPTURED TAB.' : current ? 'MGB HAS NOT PROVIDED A PLAYLIST. SHOWING THE CURRENT SONG ONLY.' : 'FREE PLAY IS CONTROLLED BY MGB\'S CAPTURED TAB.';
  }
  document.querySelector('#playerSong').textContent = playing?.song || 'NO SONG QUEUED'; document.querySelector('#playerSong').href = playing?.url || '#';
  document.querySelector('#playerArtist').textContent = playing?.artist || ''; document.querySelector('#playerArtist').href = playing ? (playing.artistUrl || (playing.viewer ? profile(playing.viewer) : '#')) : '#';
  const playerShowTitle = document.querySelector('.cassette-label .show-name');
  const activeShow = shows?.find(show => show.id === activeShowId);
  const todayKey = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(new Date().getDate()).padStart(2, '0')}`;
  const showIsActiveToday = activeShow && showOccurs(activeShow, new Date(`${todayKey}T00:00:00`)) && !activeShow.noShowDates?.includes(todayKey);
  playerShowTitle.textContent = showIsActiveToday ? activeShow.title : '';
  playerShowTitle.hidden = !showIsActiveToday;
  save();
  if (skinMakerMode === 'queue' && skinQueuePreview) renderSkinMakerQueuePreview();
}
function record() { history.push(clone(state)); if (history.length > 20) history.shift(); }
function findItem(id, queue) { return state[queue].find(item => item.id === id); }
function persistRandomArtist(value) { lastRandomArtist = value || ''; localStorage.setItem(randomArtistKey, lastRandomArtist); }
function primeRandomPlayback() {
  const result = window.LirisQQueuePlayback.primeRandom(state, lastRandomArtist);
  state = result.state; persistRandomArtist(result.lastArtist); save(); render();
}
function recordViewerPlayback(item) { if(!usesServerAudience()||currentAudienceRole()!=='streamer'||!item?.viewerId)return; void fetch(twitchEndpoint('viewer-profile'),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({operation:'activity',activity:'played',viewerId:item.viewerId,song:item.song,artist:item.artist,url:item.url})}); }
function advanceActiveQueue() {
  if (playbackMode === 'free-play') return false;
  if (!activeQueuePlaybackId) {
    const next = state.vip[0] || state.standard[0] || null;
    if (!next) return false;
    activeQueuePlaybackId = next.id;
    recordViewerPlayback(next);
    paused = false;
    persistQueuePlayback();
    render();
    return true;
  }
  const result = window.LirisQQueuePlayback.advance(state, { mode: playbackMode, lastArtist: lastRandomArtist });
  if (result.state.vip.length === state.vip.length && result.state.standard.length === state.standard.length) return false;
  state = result.state;
  activeQueuePlaybackId = state.vip[0]?.id || state.standard[0]?.id || null;
  recordViewerPlayback(state.vip[0] || state.standard[0] || null);
  persistQueuePlayback();
  persistRandomArtist(result.lastArtist); render();
  return true;
}
window.LIRISQ_QUEUE_PLAYER = Object.freeze({ advance: advanceActiveQueue });
window.LIRISQ_QUEUE_COMMAND_SERVICE = Object.freeze({
  snapshot: () => clone(state),
  nowPlaying: () => clone(mgbCapturedPlayback.current || (activeQueuePlaybackId ? [...state.vip, ...state.standard].find(item => item.id === activeQueuePlaybackId) : null) || null),
  rules: () => {
    const show = shows.find(item => item.id === activeShowId);
    return Object.freeze({ mode: playbackMode, maxSongs: show?.maxSongs ?? null, maxPerViewer: show?.maxPerViewer ?? null, vipFirst: true, text: String(localStorage.getItem('lirisq-chatbot-rules-v1') || '').trim() });
  },
  setRulesText: text => { const value = String(text || '').trim(); if (value.length > 1500) throw Error('Rules may not exceed 1500 characters.'); localStorage.setItem('lirisq-chatbot-rules-v1', value); return value; },
  request: ({ viewer, title, artist, url, queue = 'standard' }) => {
    const song = String(title || '').trim(); const cleanArtist = String(artist || '').trim(); const cleanUrl = String(url || '').trim(); if (!song || !cleanArtist || !/^https?:\/\//i.test(cleanUrl) || song.length > 180) throw Error('Use !request <song title> | <artist> | <URL>.');
    state.pending ||= []; const show = shows.find(item => item.id === activeShowId); const all = [...state.vip, ...state.standard, ...state.pending];
    if (show && all.length >= show.maxSongs) throw Error('The queue is full.'); if (show && all.filter(item => item.viewer === viewer).length >= show.maxPerViewer) throw Error('You reached this show’s request limit.');
    const lane = queue === 'vip' ? 'vip' : 'standard'; const item = { id: crypto.randomUUID(), song, artist: cleanArtist, viewer, url: cleanUrl, requestedAt: new Date().toISOString(), requestedQueue: lane }; record(); state.pending.push(item); render(); return clone({ requestId:item.id, song:item.song, artist:item.artist, queue:'pending' });
  },
  requestsFor: viewer => { state.pending ||= []; return clone([...state.vip, ...state.standard, ...state.pending].filter(item => item.viewer === viewer).map(item => ({ requestId:item.id, song:item.song, artist:item.artist, queue:state.pending.some(pending => pending.id === item.id) ? 'pending' : state.vip.some(vip => vip.id === item.id) ? 'vip' : 'standard' }))); },
  removeRequest: ({ viewer, requestId }) => { state.pending ||= []; const queue = state.pending.some(item => item.id === requestId) ? 'pending' : state.vip.some(item => item.id === requestId) ? 'vip' : 'standard'; const item = state[queue].find(entry => entry.id === requestId); if (!item || item.viewer !== viewer) throw Error('That request was not found or is not yours.'); record(); state[queue] = state[queue].filter(entry => entry.id !== requestId); render(); return clone({ requestId, removed:true }); },
  pendingRequests: () => { state.pending ||= []; return clone(state.pending); },
  approveRequest: requestId => { state.pending ||= []; const index = state.pending.findIndex(item => item.id === requestId); if (index < 0) throw Error('Pending request not found.'); record(); const [item] = state.pending.splice(index, 1); const lane = item.requestedQueue === 'vip' ? 'vip' : 'standard'; delete item.requestedQueue; state[lane].push(item); render(); lirisqPluginHost?.emit('song.queued', { id:item.id, title:item.song, artist:item.artist, queue:lane }); return clone({ requestId:item.id, approved:true, queue:lane }); },
  denyRequest: requestId => { state.pending ||= []; const index = state.pending.findIndex(item => item.id === requestId); if (index < 0) throw Error('Pending request not found.'); record(); const [item] = state.pending.splice(index, 1); render(); return clone({ requestId:item.id, denied:true }); },
  moveRequest: (requestId, lane) => { if (!['vip', 'standard'].includes(lane)) throw Error('Invalid queue lane.'); const from = state.vip.some(item => item.id === requestId) ? 'vip' : state.standard.some(item => item.id === requestId) ? 'standard' : null; if (!from) throw Error('Approved request not found.'); if (from === lane) return clone({ requestId, queue:lane, changed:false }); record(); const index = state[from].findIndex(item => item.id === requestId); const [item] = state[from].splice(index, 1); state[lane].push(item); render(); return clone({ requestId, queue:lane, changed:true }); },
  playback: action => {
    if (action === 'play') {
      paused = false;
      if (playbackMode !== 'free-play' && !activeQueuePlaybackId) {
        const next = state.vip[0] || state.standard[0] || null;
        if (next) activeQueuePlaybackId = next.id;
      }
      persistQueuePlayback();
      render();
      return { playing: Boolean(mgbCapturedPlayback.current || activeQueuePlaybackId) };
    }
    if (action === 'pause') { paused = true; persistQueuePlayback(); return { paused:true }; }
    if (action === 'next') return { advanced:advanceActiveQueue() };
    throw Error('Unknown playback action');
  },
  clearAll: () => {
    const removed = state.vip.length + state.standard.length + (state.pending?.length || 0);
    record(); state = { vip:[], standard:[], pending:[] }; activeQueuePlaybackId = null; paused = false;
    persistQueuePlayback(); render();
    return Object.freeze({ removed });
  },
  setMode: mode => {
    if (!['queue','random','free-play'].includes(mode)) throw Error('Use !queue-mode <queue|random|free-play>.');
    playbackMode = mode; localStorage.setItem(playbackModeKey, mode); renderPlaybackModeSetting(); render();
    return Object.freeze({ mode });
  },
  setLimit: maxSongs => {
    const show = shows.find(item => item.id === activeShowId);
    if (!show) throw Error('Select an active show before changing its queue limit.');
    show.maxSongs = maxSongs; saveShows(); render();
    return Object.freeze({ maxSongs, showId:show.id });
  },
  promoteViewerRequest: viewer => { const index = state.standard.findIndex(item => item.viewer === viewer); if (index < 0) return null; record(); const [item] = state.standard.splice(index, 1); state.vip.push(item); render(); return clone({ requestId:item.id, promoted:true, queue:'vip' }); }
});

document.querySelector('#addSong').addEventListener('click', () => {
  const song = document.querySelector('#newSong').value.trim();
  const artist = document.querySelector('#newArtist').value.trim();
  const url = document.querySelector('#newUrl').value.trim();
  if (!song || !artist || !url) return say('SONG TITLE, ARTIST, AND URL ARE REQUIRED');
  const activeShow = shows?.find(show => show.id === activeShowId);
  const totalForShow = state.vip.length + state.standard.length;
  if (activeShow && totalForShow >= activeShow.maxSongs) return say(`THIS SHOW QUEUE IS FULL (${activeShow.maxSongs} SONGS)`);
  const viewerSongs = [...state.vip, ...state.standard].filter(item => item.viewer === 'manual').length;
  if (activeShow && viewerSongs >= activeShow.maxPerViewer) return say(`TWITCH ACCOUNT LIMIT REACHED (${activeShow.maxPerViewer} SONGS)`);
  const queue = 'standard';
  const queuedSong = { id: crypto.randomUUID(), song, artist, viewer: 'manual', url }; record(); state.standard.push(queuedSong); render(); lirisqPluginHost?.emit('song.queued', { id: queuedSong.id, title: song, artist, queue: 'standard' });
  document.querySelectorAll('.fields input').forEach(input => input.value = ''); say(`ADDED TO ${queue.toUpperCase()} QUEUE`);
});
document.querySelector('#undo').addEventListener('click', () => { if (!history.length) return say('NOTHING TO UNDO'); state = history.pop(); render(); say('LAST QUEUE CHANGE UNDONE'); });
document.querySelector('#queue').addEventListener('click', event => {
  const button = event.target.closest('button'); if (!button) return;
  if (button.dataset.queueExpand) { queueViewportExpanded = true; render(); say('LIVE QUEUE EXPANDED'); return; }
  const { id, queue } = button.dataset; if (!id || !queue) return;
  const item = findItem(id, queue); if (!item) return;
  record();
  if (button.classList.contains('remove')) { state[queue] = state[queue].filter(x => x.id !== id); say('SONG REMOVED'); }
  if (button.classList.contains('promote')) { const other = queue === 'vip' ? 'standard' : 'vip'; state[queue] = state[queue].filter(x => x.id !== id); state[other].push(item); lirisqPluginHost?.emit('song.lane.changed', { id, from: queue, queue: other }); say(queue === 'vip' ? 'SONG DEMOTED TO STANDARD' : 'SONG PROMOTED TO VIP'); }
  render();
});
document.querySelector('#queueViewportExpand').addEventListener('click', () => { queueViewportExpanded = !queueViewportExpanded; render(); say(queueViewportExpanded ? 'LIVE QUEUE EXPANDED' : 'LIVE QUEUE COLLAPSED'); });

document.querySelectorAll('.queue-list').forEach(list => {
  list.addEventListener('dragstart', event => { const row = event.target.closest('.row'); if (!row) return; dragging = { id: row.dataset.id, from: row.dataset.queue }; row.classList.add('dragging'); event.dataTransfer.effectAllowed = 'move'; event.dataTransfer.setData('text/plain', row.dataset.id); });
  list.addEventListener('dragover', event => { event.preventDefault(); if (!dragging) return; const over = event.target.closest('.row'); document.querySelectorAll('.row.drop-target').forEach(x => x.classList.remove('drop-target')); if (over && over.dataset.id !== dragging.id) { over.classList.add('drop-target'); const box = over.getBoundingClientRect(); if (event.clientY > box.top + box.height / 2) over.after(document.querySelector(`.row[data-id="${dragging.id}"]`)); else over.before(document.querySelector(`.row[data-id="${dragging.id}"]`)); } });
  list.addEventListener('drop', event => { event.preventDefault(); if (!dragging) return; const target = list.dataset.queue; const before = clone(state); const item = before[dragging.from].find(x => x.id === dragging.id); if (!item) return; const ids = [...list.querySelectorAll('.row')].map(row => row.dataset.id); const lookup = new Map([...before.vip, ...before.standard].map(x => [x.id, x])); lookup.set(item.id, item); state[dragging.from] = before[dragging.from].filter(x => x.id !== item.id); state[target] = ids.map(id => lookup.get(id)).filter(Boolean); history.push(before); if (dragging.from !== target) lirisqPluginHost?.emit('song.lane.changed', { id: item.id, from: dragging.from, queue: target }); dragging = null; render(); say(target === 'vip' ? 'VIP QUEUE REORDERED' : 'STANDARD QUEUE REORDERED'); });
  list.addEventListener('dragend', () => { document.querySelectorAll('.row').forEach(x => x.classList.remove('dragging', 'drop-target')); dragging = null; });
});

const commandHelpView = document.createElement('section');
commandHelpView.id = 'commandHelp'; commandHelpView.className = 'view';
document.querySelector('.shell').append(commandHelpView);
function renderCommandHelp() {
  const core = window.LirisQBotCorePlugin; const table = core?.commandTable || {}; const settings = storedJson(chatbotCommandSettingsKey, {});
  commandHelpView.replaceChildren(); const card = document.createElement('div'); card.className = 'card command-help-page';
  card.innerHTML = '<div class="eyebrow">LIRISQ CHAT BOT</div><h2>COMMAND GUIDE</h2><p class="sub">Only commands currently enabled by the streamer are shown.</p>';
  const syntax = { help:'!help', queue:'!queue', nowplaying:'!nowplaying', request:'!request &lt;song title&gt; | &lt;artist&gt; | &lt;URL&gt;', myrequest:'!myrequest', remove:'!remove [request ID]', rules:'!rules · !rules add &lt;text&gt; · !rules replace &lt;text&gt; · !rules delete', play:'!play', pause:'!pause', next:'!next', promote:'!promote &lt;request ID&gt;', demote:'!demote &lt;request ID&gt;', approval:'!approval [request ID]', deny:'!deny &lt;request ID&gt;', clear:'!clear', 'queue-mode':'!queue-mode &lt;queue|random|free-play&gt;', 'queue-limit':'!queue-limit &lt;number&gt;' };
  const example = { help:'Full command guide: http://localhost:4317/help', queue:'VIP: 2 · Standard: 5', nowplaying:'Now playing: Song — Artist', request:'Your request is pending approval.', myrequest:'Your request is awaiting approval.', remove:'Your request was removed.', rules:'Queue mode: Queue · VIP plays first.', play:'Playback started.', pause:'Playback paused.', next:'Skipped to the next song.', promote:'Request moved to VIP.', demote:'Request moved to Standard.', approval:'Pending: rq-123 · Song — Artist', deny:'Request denied.', clear:'Queue cleared.', 'queue-mode':'Queue mode updated.', 'queue-limit':'Queue limit updated.' };
  for (const permission of ['viewer', 'broadcaster']) {
    const enabled = Object.entries(table).filter(([name, role]) => role === permission && (settings[name] ?? role !== 'broadcaster'));
    if (!enabled.length) continue; const section = document.createElement('section'); section.className = 'command-help-group'; section.innerHTML = `<h3><span class="command-role ${permission}">${permission === 'viewer' ? 'VIEWER' : 'BROADCASTER'}</span> COMMANDS</h3>`;
    for (const [name] of enabled) { const row = document.createElement('article'); row.className = 'command-help-row'; row.innerHTML = `<h3>!${name.toUpperCase()}</h3><p>${commandDescription(name)}</p><p><strong>SYNTAX</strong> <code>${syntax[name] || `!${name}`}</code></p><p><strong>EXAMPLE RESPONSE</strong> ${example[name] || 'Command completed.'}</p>`; section.append(row); }
    card.append(section);
  }
  const twitchServerGuide = document.createElement('section'); twitchServerGuide.className = 'command-help-group';
  twitchServerGuide.innerHTML = '<h3><span class="command-role broadcaster">BROADCASTER</span> TWITCH SERVER SETUP</h3><article class="command-help-row"><h3>CONNECTING TWITCH</h3><p>Twitch is connected by the LirisQ server, not by a chat command. Install Node.js on the hosting machine, run the LirisQ server there, and set its Twitch environment values. The browser never receives your client secret or tokens. YouTube follows the same server-side pattern but needs its own Google credentials and authorization flow.</p><p><strong>REQUIRED</strong> Twitch Client ID, Client Secret, registered redirect URI, public HTTPS EventSub callback URL, and a long EventSub signing secret.</p><p><strong>THEN</strong> Configuration → Main → Twitch Plugin Configuration → Connect Twitch → Activate EventSub.</p><p><strong>DETAILS</strong> <a href="/docs/TWITCH-SETUP.md" target="_blank" rel="noreferrer">Open Twitch server setup guide</a></p></article>';
  card.append(twitchServerGuide);
  commandHelpView.append(card);
}
const pageRoutes = { queue: '/', player: '/player', obsPlayerOverlay: '/obs-player', obsQueueOverlay: '/obs-queue', shows: '/shows', settings: '/configuration', analytics: '/analytics', songHistory: '/song-history', discord: '/discord', xannouncer: '/x-shows', calendarExport: '/calendar-export', notifications: '/notifications', botplugins: '/bot-plugins', skinmaker: '/skin-maker', store: '/skins-store', profile: '/profile', commandHelp: '/help' };
function routeView() {
  if (window.location.protocol === 'file:' && window.location.hash) return window.location.hash.slice(1) || 'queue';
  const current = window.location.pathname.replace(/\/index\.html$/, '') || '/';
  if (current === '/setup') return 'settings';
  return Object.entries(pageRoutes).find(([, route]) => route === current)?.[0] || 'queue';
}
// Populated during configuration mounting.  It must exist before the initial
// audience render can route to Settings.
let configurationIntegrationPlugins = {};
function showPage(view, updateUrl = false) {
  const isOverlay = ['obsPlayerOverlay', 'obsQueueOverlay'].includes(view);
  if (view === 'queue') void refreshMgbBrokerPairing();
  const configurationCategory = Object.hasOwn(configurationIntegrationPlugins, view) ? view : null;
  if (configurationCategory) view = 'settings';
  if (!isOverlay && !mgbIsConnected() && !['settings', 'profile', 'commandHelp'].includes(view)) view = 'settings';
  if (!isOverlay && document.body.dataset.audience === 'viewer' && !['shows', 'profile', 'commandHelp'].includes(view)) view = 'shows';
  if (!isOverlay && document.querySelector(`nav button[data-view="${view}"]`)?.hidden) view = 'settings';
  document.body.classList.toggle('obs-overlay', isOverlay);
  document.querySelectorAll('nav button,.view').forEach(element => element.classList.remove('active'));
  document.querySelector(`nav button[data-view="${view}"]`)?.classList.add('active');
  document.querySelector(`#${view}`).classList.add('active');
  document.title = `LirisQ — ${view === 'settings' ? 'Configuration' : view === 'skinmaker' ? 'Skin Maker' : view === 'player' ? 'Player Mode' : view === 'obsPlayerOverlay' ? 'OBS Player Overlay' : view === 'obsQueueOverlay' ? 'OBS Live Queue Overlay' : view[0].toUpperCase() + view.slice(1)}`;
  if (view === 'skinmaker') { document.querySelector('#skinMakerWorkflow').value = 'editor'; setSkinMakerWorkflow('editor'); }
  if (view === 'profile') renderProfilePage();
  if (view === 'analytics') renderAnalyticsDashboard();
  if (view === 'songHistory') renderSongHistory();
  if (view === 'discord') void renderDiscordDashboard();
  if (view === 'xannouncer') renderXAnnouncer();
  if (view === 'calendarExport') renderCalendarExport();
  if (view === 'notifications') renderNotifications();
  if (view === 'commandHelp') renderCommandHelp();
  if (view === 'botplugins' || view === 'settings') { renderBotPlugins(); renderOptionalAddonManager(); renderSkinPacks(); }
  if (configurationCategory) showConfigurationIntegration(configurationCategory);
  else if (view === 'settings') showConfigurationIntegration('main');
  if (updateUrl) {
    if (window.location.protocol === 'file:') window.location.hash = view;
    else window.history.pushState({ view }, '', pageRoutes[view]);
  }
}
document.querySelectorAll('nav button').forEach(button => button.addEventListener('click', () => showPage(button.dataset.view, true)));
const storeTestLink = document.querySelector('.skins-store-tag');
storeTestLink?.addEventListener('click', () => {
  const destination = new URL(storeTestLink.href);
  destination.searchParams.set('return', window.location.href);
  storeTestLink.href = destination.href;
});
window.addEventListener('popstate', () => showPage(routeView()));
window.addEventListener('hashchange', () => { if (window.location.protocol === 'file:') showPage(routeView()); });
// A completed broker pairing is not itself a live playback connection.  Keep
// the app locked until the authenticated MessagePort is actually established.
function mgbIsConnected() { return window.LIRISQ_MGB_CONNECTION?.status().connected === true; }
function requireMgb() { if (mgbIsConnected()) return true; say('CONNECT MGB TO UNLOCK LIRISQ'); showPage('settings', true); return false; }
function setPaused(value) { if (!requireMgb()) return; paused = value; persistQueuePlayback(); document.body.dataset.playerState = paused ? 'paused' : 'playing'; const button = document.querySelector('#pausePlayer'); button.textContent = paused ? 'RESUME [SPACE]' : 'PAUSE [SPACE]'; button.classList.toggle('hot', !paused); say(paused ? 'QUEUE PAUSED' : 'QUEUE RESUMED'); }
document.querySelector('#pausePlayer').addEventListener('click', () => setPaused(!paused));
document.querySelector('#nextPlayer').addEventListener('click', () => { if (!requireMgb()) return; say(advanceActiveQueue() ? 'NEXT TRACK SELECTED' : 'QUEUE IS EMPTY'); });
window.addEventListener('keydown', event => { if (event.code === 'Space' && document.activeElement.tagName !== 'INPUT') { event.preventDefault(); setPaused(!paused); } });

function renderCalendar() { const calendar = document.querySelector('#calendar'); const y = displayMonth.getFullYear(), m = displayMonth.getMonth(); document.querySelector('#monthTitle').textContent = new Intl.DateTimeFormat(undefined,{month:'long',year:'numeric'}).format(displayMonth).toUpperCase(); const first = new Date(y,m,1), days = new Date(y,m+1,0).getDate(), today = new Date(), localToday = new Date(today.getFullYear(), today.getMonth(), today.getDate()); calendar.innerHTML = ['SUN','MON','TUE','WED','THU','FRI','SAT'].map(x => `<div class="dayname">${x}</div>`).join(''); for(let i=0;i<first.getDay();i++) calendar.innerHTML += '<div class="day blank" aria-hidden="true"></div>'; for(let day=1;day<=days;day++){ const date = new Date(y,m,day); const candidates = (shows || []).filter(show => showOccurs(show, date)); const isToday = date.toDateString() === today.toDateString(), isPast = date < localToday; const dayKey = `${y}-${String(m + 1).padStart(2,'0')}-${String(day).padStart(2,'0')}`; const visible = candidates.filter(show => !show.noShowDates?.includes(dayKey)); const allNoShow = candidates.length > 0 && visible.length === 0; calendar.innerHTML += `<div class="day ${isToday?'today':''} ${isPast?'past':''} ${dayKey === selectedCalendarDate ? 'selected' : ''}" data-date="${dayKey}">${day}${visible.map(show => `<a href="#" class="event" data-show-id="${show.id}">${show.title}<br>${new Date(`1970-01-01T${show.time}:00`).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}</a>`).join('')}${allNoShow?'<button class="no-show" data-no-show-date="${dayKey}">NO SHOW</button>':''}</div>`; } }
document.querySelector('#prevMonth').addEventListener('click',()=>{displayMonth.setMonth(displayMonth.getMonth()-1);renderCalendar()}); document.querySelector('#nextMonth').addEventListener('click',()=>{displayMonth.setMonth(displayMonth.getMonth()+1);renderCalendar()}); renderCalendar();
const localDate = date => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
selectedCalendarDate ||= localDate(new Date());
document.querySelector('#todayCalendar').addEventListener('click', () => { const today = new Date(); displayMonth = new Date(today.getFullYear(), today.getMonth(), 1); selectedCalendarDate = localDate(today); const scheduled = shows.filter(show => showOccurs(show, new Date(`${selectedCalendarDate}T00:00:00`))); renderCalendar(); if (document.body.dataset.audience === 'viewer') renderViewerShow(scheduled, selectedCalendarDate); else renderSelectedShows(scheduled, selectedCalendarDate); });
const nextFriday = () => { const date = new Date(); date.setHours(0, 0, 0, 0); date.setDate(date.getDate() + ((5 - date.getDay() + 7) % 7)); return localDate(date); };
const testShowsFixture = () => [{ id: 'night-drive', title: 'NIGHT DRIVE', date: nextFriday(), time: '19:30', recurrence: 'weekly', notes: 'Test stream queue.', image: 'show-assets/night-drive.png', maxPerViewer: 2, maxSongs: 50, queue: clone(savedTestFixture()), noShowDates: [] }, { id: 'midnight-signal', title: 'MIDNIGHT SIGNAL', date: nextFriday(), time: '22:15', recurrence: 'weekly', notes: 'Second same-day test show.', image: 'show-assets/midnight-signal.png', maxPerViewer: 3, maxSongs: 30, queue: { vip: clone(savedTestFixture().vip.slice(0, 3)), standard: clone(savedTestFixture().standard.slice(0, 5)) }, noShowDates: [] }];
shows = storedJson('lirisq-shows', []);
if (!Array.isArray(shows)) shows = [];
shows.forEach(show => { if (!show.queue?.vip || !show.queue?.standard) show.queue = clone(state); show.noShowDates ||= []; });
activeShowId = localStorage.getItem('lirisq-active-show') || null;
const existingActiveShow = shows.find(show => show.id === activeShowId) || shows[0] || null;
activeShowId = existingActiveShow?.id || null;
state = clone(existingActiveShow?.queue || state);
function saveShows() { localStorage.setItem('lirisq-shows', JSON.stringify(shows)); if (window.LirisQStreamNotificationsPlugin?.status().active) window.LirisQStreamNotificationsPlugin.reconcileShows(shows); }
function renderStreamerView() { const active = shows.find(show => show.id === activeShowId); const [streamerCard, viewerCard] = document.querySelectorAll('#shows > .grid .card'); if (!active) { for (const [card, heading] of [[streamerCard,'STREAMER VIEW'],[viewerCard,'VIEWER VIEW']]) { if (!card) continue; card.classList.remove('show-summary-card'); card.querySelector('.show-summary-backdrop')?.remove(); card.querySelector('.eyebrow').textContent = heading; card.querySelector('h2').textContent = 'NO SHOW SELECTED'; card.querySelector('.sub').textContent = 'CREATE A SHOW OR LOAD TEST DATA TO BEGIN.'; } const viewerNotice = viewerCard?.querySelector('.notice'); if (viewerNotice) viewerNotice.textContent = 'NO VIEWER SHOWS ARE AVAILABLE.'; return; } const showDate = new Date(`${active.date}T00:00:00`).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase(); const showTime = new Date(`1970-01-01T${active.time}:00`).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); const queued = active.queue.vip.length + active.queue.standard.length; const paintSummary = (card, heading, detail) => { card.classList.add('show-summary-card'); let backdrop = card.querySelector('.show-summary-backdrop'); if (active.image) { backdrop ||= document.createElement('div'); backdrop.className = 'show-summary-backdrop'; backdrop.setAttribute('aria-hidden', 'true'); backdrop.innerHTML = `<img src="${active.image}" alt="">`; card.prepend(backdrop); } else backdrop?.remove(); card.querySelector('.eyebrow').textContent = heading; card.querySelector('h2').textContent = active.title; card.querySelector('.sub').textContent = detail; }; paintSummary(streamerCard, 'STREAMER VIEW', `${showDate} · ${showTime} LOCAL · ${queued}/${active.maxSongs} SONGS`); paintSummary(viewerCard, 'VIEWER VIEW', `${showDate} · ${showTime} LOCAL · ${queued}/${active.maxSongs} SONGS`); const viewerNotice = viewerCard.querySelector('.notice'); if (viewerNotice) viewerNotice.textContent = `${active.recurrence.toUpperCase()} · VIEWERS CAN REQUEST UP TO ${active.maxPerViewer} SONGS FOR THIS SHOW.`; }
function showOccurs(show, date) {
  const start = new Date(`${show.date}T00:00:00`); if (date < start) return false;
  if (show.recurrence === 'once') return localDate(date) === show.date;
  const repeatDays = show.repeatDays?.length ? show.repeatDays : [start.getDay()];
  if (show.recurrence === 'weekly') return repeatDays.includes(date.getDay());
  if (show.recurrence === 'biweekly') return repeatDays.includes(date.getDay()) && Math.floor((date - start) / 86400000 / 7) % 2 === 0;
  if (show.recurrence === 'monthly') return date.getDate() === start.getDate();
  return false;
}
const showModal = document.createElement('div');
showModal.className = 'show-modal'; showModal.hidden = true;
showModal.innerHTML = `<div class="show-dialog card" role="dialog" aria-modal="true" aria-labelledby="showEditorTitle"><div class="calendar-top"><div><div class="eyebrow">STREAMER VIEW</div><h2 id="showEditorTitle">ADD SHOW</h2></div><button type="button" class="btn small" data-close-show>×</button></div><div id="showEditorImageBanner" class="show-editor-image-banner" role="button" tabindex="0" aria-expanded="false" aria-label="Expand show image preview"><img id="showEditorImage" alt="Selected show image" hidden><span id="showEditorImageEmpty">SHOW IMAGE PREVIEW</span><span id="showEditorImageHint" class="show-editor-image-hint" hidden>CLICK TO EXPAND</span></div><p class="sub">EACH SHOW HAS ITS OWN QUEUE. VIEWER REQUESTS STOP WHEN THE SHOW QUEUE REACHES ITS LIMIT.</p><div class="show-form"><label>SHOW TITLE<input id="showTitle" maxlength="80" placeholder="E.G. NIGHT DRIVE" required></label><label>START DATE (LOCAL)<input id="showDate" type="date" required></label><label>START TIME (LOCAL)<input id="showTime" type="time" required></label><label>REPEAT STYLE<select id="showRecurrence"><option value="once">DOES NOT REPEAT</option><option value="weekly">EVERY SELECTED WEEK</option><option value="biweekly">EVERY OTHER SELECTED WEEK</option><option value="monthly">MONTHLY (SAME DATE)</option></select></label><div id="showRepeatDays" class="show-repeat-days"><span>REPEAT DAYS</span><div>${['SUN','MON','TUE','WED','THU','FRI','SAT'].map((day,index) => `<button type="button" class="repeat-day" data-repeat-day="${index}" aria-pressed="false">${day}</button>`).join('')}</div><em>SELECT ONE OR MORE DAYS FOR WEEKLY REPEATS</em></div><label>MAX SONGS PER TWITCH ACCOUNT<input id="showViewerMax" type="number" min="1" max="99" value="2" required></label><label>MAX SONGS FOR THIS SHOW<input id="showQueueMax" type="number" min="1" max="999" value="50" required></label><label id="showNoShowWrap" class="show-no-show"><input id="showNoShow" type="checkbox"> <span>NO SHOW FOR THIS DATE</span></label><label class="show-notes">STREAMER NOTES<textarea id="showNotes" maxlength="500" placeholder="Optional notes for your show setup or viewer guidance."></textarea></label></div><div class="show-editor-actions"><button type="button" class="btn" data-close-show>CANCEL</button><button type="button" id="saveShow" class="btn hot">CREATE SHOW & QUEUE</button></div></div>`;
document.body.append(showModal);
const showImageField = document.createElement('label');
showImageField.className = 'show-image-field';
showImageField.innerHTML = `<span>SHOW IMAGE <em>OPTIONAL · PNG, GIF, JPG · CROPPED TO 300 × 300</em></span><div class="show-image-controls"><img id="showImagePreview" alt="Current show image" hidden><div id="showImageEmpty" class="show-image-empty">NO SHOW IMAGE</div><input id="showImage" type="file" accept="image/png,image/jpeg,image/gif"><button id="removeShowImage" class="btn small" type="button" hidden>REMOVE IMAGE</button></div>`;
document.querySelector('.show-form').append(showImageField);
const showImageStyle = document.createElement('style');
showImageStyle.textContent = `.show-editor-image-banner{height:100px;margin:12px 0;position:relative;overflow:hidden;border:1px solid var(--line);background:#0a0e16;display:grid;place-items:center;transition:height 300ms cubic-bezier(.2,.8,.2,1);cursor:default}.show-editor-image-banner:has(img:not([hidden])){cursor:zoom-in}.show-editor-image-banner.expanded{height:var(--show-image-expanded-size);cursor:zoom-out}.show-editor-image-banner:focus-visible{outline:2px solid var(--cyan);outline-offset:2px}.show-editor-image-banner img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}.show-editor-image-banner span{color:var(--muted);font:600 10px 'DM Mono',monospace;letter-spacing:.1em}.show-editor-image-hint{position:absolute;z-index:1;right:9px;bottom:7px;color:var(--ink)!important;background:#070a10b8;padding:3px 5px;font-size:9px!important}.show-editor-image-banner.expanded .show-editor-image-hint{font-size:0!important}.show-editor-image-banner.expanded .show-editor-image-hint::after{content:'CLICK TO SHRINK';font-size:9px}.show-image-field{grid-column:1/-1;display:grid;gap:8px}.show-image-field>span{font:600 11px 'DM Mono',monospace;color:var(--muted)}.show-image-field em{font-style:normal;color:var(--cyan);font-size:10px}.show-image-controls{display:flex;align-items:center;gap:10px;min-height:72px}.show-image-controls img,.show-image-empty{width:68px;height:68px;border:1px solid var(--line);object-fit:cover;background:#0a0e16}.show-image-empty{display:grid;place-items:center;padding:8px;color:var(--muted);font:600 9px 'DM Mono',monospace;text-align:center}.show-image-controls input{max-width:260px;color:var(--muted);font:500 11px 'DM Mono',monospace}`;
document.head.append(showImageStyle);
const showRepeatStyle = document.createElement('style');
showRepeatStyle.textContent = `.show-repeat-days{grid-column:1/-1;display:grid;gap:7px;color:var(--muted);font:500 11px 'DM Mono',monospace}.show-repeat-days>div{display:grid;grid-template-columns:repeat(7,1fr);gap:6px}.repeat-day{min-height:38px;border:1px solid var(--line);background:#0a0e16;color:var(--muted);font:700 11px 'DM Mono',monospace;letter-spacing:0}.repeat-day[aria-pressed="true"]{color:#10131c;background:var(--cyan);border-color:var(--cyan)}.show-repeat-days.is-inactive{opacity:.45}.show-repeat-days em{font-style:normal;font-size:9px;color:var(--muted)}`;
document.head.append(showRepeatStyle);
const calendarPastStyle = document.createElement('style');
calendarPastStyle.textContent = `#calendar .day.blank{visibility:hidden;border:0;background:transparent;pointer-events:none}#calendar .day.past{opacity:.38}#calendar .day.past .event,#calendar .day.past .no-show{filter:saturate(.55)}`;
document.head.append(calendarPastStyle);
const showImageCardStyle = document.createElement('style');
showImageCardStyle.textContent = `.show-card-image{display:block;width:84px;height:84px;object-fit:cover;border:1px solid var(--line);margin:10px 0}.show-summary-card{position:relative;isolation:isolate;overflow:hidden;background:var(--card-background,linear-gradient(135deg,var(--panel),#0f1420))}.show-summary-card>:not(.show-summary-backdrop){position:relative;z-index:1}.show-summary-backdrop,.viewer-show-backdrop{position:absolute;z-index:0;top:0;left:0;right:0;height:82px;overflow:hidden;background:#111827}.show-summary-backdrop img,.viewer-show-backdrop img{width:100%;height:100%;object-fit:cover;filter:brightness(.3) saturate(.75)}.show-summary-backdrop::after,.viewer-show-backdrop::after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,#070a10aa 0%,#101722dd 88%,var(--panel) 100%)}.selected-show{position:relative;isolation:isolate;overflow:hidden;padding:18px 14px 14px;margin:12px -4px 0;border:1px solid var(--line);border-radius:2px}.selected-show-backdrop{position:absolute;z-index:-1;top:0;left:0;right:0;height:82px;overflow:hidden;background:#111827}.selected-show-backdrop img{width:100%;height:100%;object-fit:cover;filter:brightness(.3) saturate(.75)}.selected-show-backdrop::after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,#070a10aa 0%,#101722dd 88%,var(--panel) 100%)}.selected-show h3{position:relative}.viewer-show-panel{position:relative;isolation:isolate;overflow:hidden}.viewer-show-summary{position:relative;z-index:1;cursor:pointer;min-height:82px}.viewer-show-summary h2{margin:0;font-size:26px}.viewer-show-summary .sub{margin-top:8px}.viewer-show-summary-hint{font:500 10px 'DM Mono',monospace;color:var(--cyan);margin-top:10px;transition:opacity 120ms ease}.viewer-show-panel.expanded .viewer-show-summary-hint{opacity:0}.viewer-show-detail{display:grid;grid-template-rows:0fr;opacity:0;transition:grid-template-rows 300ms cubic-bezier(.2,.8,.2,1),opacity 180ms ease}.viewer-show-detail-inner{min-height:0;overflow:hidden}.viewer-show-panel.expanded .viewer-show-detail{grid-template-rows:1fr;opacity:1}`;
document.head.append(showImageCardStyle);
const viewerShowListStyle = document.createElement('style');
viewerShowListStyle.textContent = `.viewer-show-card{position:relative;isolation:isolate;overflow:hidden;margin:12px 0;border:1px solid var(--line);padding:18px 14px 14px;background:var(--card-background,linear-gradient(135deg,var(--panel),#0f1420))}.viewer-show-card>:not(.viewer-show-backdrop){position:relative;z-index:1}.viewer-show-card .viewer-show-backdrop{height:116px}.viewer-show-card .viewer-show-backdrop img{filter:brightness(.58) saturate(1.08)}.viewer-show-card .viewer-show-backdrop::after{background:linear-gradient(180deg,#070a1055 0%,#101722c9 74%,var(--panel) 100%)}.viewer-show-card .viewer-show-detail{display:grid;grid-template-rows:0fr;opacity:0;transition:grid-template-rows 300ms cubic-bezier(.2,.8,.2,1),opacity 180ms ease}.viewer-show-card .viewer-show-detail-inner{min-height:0;overflow:hidden}.viewer-show-card.expanded .viewer-show-detail{grid-template-rows:1fr;opacity:1}.viewer-show-card .viewer-show-summary-hint{margin-bottom:0}.viewer-show-card.expanded .viewer-show-summary-hint{color:var(--muted)}.viewer-show-card .viewer-queue{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:0 16px;list-style:none;padding-left:0}.viewer-show-card .viewer-queue li{min-width:0;overflow:hidden}.viewer-song-marquee{display:block;overflow:hidden;white-space:nowrap}.viewer-song-marquee-track{display:inline-flex;align-items:baseline;gap:6px;min-width:max-content}.viewer-song-marquee.is-marquee .viewer-song-marquee-track{animation:viewer-song-marquee var(--marquee-duration,8s) linear infinite}.viewer-song-marquee .marquee-gap{margin:0 18px;color:var(--muted)}@keyframes viewer-song-marquee{to{transform:translateX(calc(-1 * var(--marquee-distance)))}}`;
document.head.append(viewerShowListStyle);
const selectedDatePreviewStyle = document.createElement('style');
selectedDatePreviewStyle.textContent = `.viewer-date-preview-show{position:relative;isolation:isolate;overflow:hidden;border:1px solid var(--line);padding:16px 12px 12px;margin-top:12px;min-height:82px}.viewer-date-preview-show>:not(.viewer-date-preview-backdrop){position:relative;z-index:1}.viewer-date-preview-show h3{margin:0;font-size:20px}.viewer-date-preview-backdrop{position:absolute;z-index:0;inset:0 0 auto;height:82px;overflow:hidden;background:#111827}.viewer-date-preview-backdrop img{width:100%;height:100%;object-fit:cover;filter:brightness(.52) saturate(1.06)}.viewer-date-preview-backdrop::after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,#070a1066 0%,#101722d9 85%,var(--panel) 100%)}`;
document.head.append(selectedDatePreviewStyle);
let pendingShowImage = undefined;
function displayShowImage(source) { const preview = document.querySelector('#showImagePreview'), empty = document.querySelector('#showImageEmpty'), remove = document.querySelector('#removeShowImage'), banner = document.querySelector('#showEditorImage'), bannerEmpty = document.querySelector('#showEditorImageEmpty'), bannerBox = document.querySelector('#showEditorImageBanner'), hint = document.querySelector('#showEditorImageHint'); preview.hidden = !source; empty.hidden = !!source; remove.hidden = !source; banner.hidden = !source; bannerEmpty.hidden = !!source; hint.hidden = !source; bannerBox.classList.remove('expanded'); bannerBox.setAttribute('aria-expanded', 'false'); if (source) { preview.src = source; banner.src = source; } }
function toggleShowImagePreview() { const banner = document.querySelector('#showEditorImageBanner'); if (document.querySelector('#showEditorImage').hidden) return; if (!banner.classList.contains('expanded')) banner.style.setProperty('--show-image-expanded-size', `${Math.round(banner.getBoundingClientRect().width)}px`); const expanded = banner.classList.toggle('expanded'); banner.setAttribute('aria-expanded', String(expanded)); }
document.querySelector('#showEditorImageBanner').addEventListener('click', toggleShowImagePreview);
document.querySelector('#showEditorImageBanner').addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); toggleShowImagePreview(); } });
function selectedRepeatDays() { return [...document.querySelectorAll('[data-repeat-day][aria-pressed="true"]')].map(button => Number(button.dataset.repeatDay)); }
function syncRepeatDays(repeatDays = null) { const recurrence = document.querySelector('#showRecurrence').value; const repeatBox = document.querySelector('#showRepeatDays'); const startDay = new Date(`${document.querySelector('#showDate').value || localDate(new Date())}T00:00:00`).getDay(); const selected = repeatDays?.length ? repeatDays : (selectedRepeatDays().length ? selectedRepeatDays() : [startDay]); document.querySelectorAll('[data-repeat-day]').forEach(button => { button.setAttribute('aria-pressed', String(selected.includes(Number(button.dataset.repeatDay)))); button.disabled = !['weekly', 'biweekly'].includes(recurrence); }); repeatBox.classList.toggle('is-inactive', !['weekly', 'biweekly'].includes(recurrence)); }
document.querySelector('#showRepeatDays').addEventListener('click', event => { const button = event.target.closest('[data-repeat-day]'); if (!button || button.disabled) return; const selected = selectedRepeatDays(); if (button.getAttribute('aria-pressed') === 'true' && selected.length === 1) return say('SELECT AT LEAST ONE REPEAT DAY'); button.setAttribute('aria-pressed', String(button.getAttribute('aria-pressed') !== 'true')); });
document.querySelector('#showRecurrence').addEventListener('change', () => syncRepeatDays());
document.querySelector('#showDate').addEventListener('change', () => { if (!selectedRepeatDays().length) syncRepeatDays(); });
function cropShowImage(file) { return new Promise((resolve, reject) => { if (!['image/png', 'image/jpeg', 'image/gif'].includes(file.type)) return reject(new Error('Choose a PNG, GIF, or JPG image.')); const reader = new FileReader(); reader.onerror = () => reject(new Error('Could not read image.')); reader.onload = () => { const image = new Image(); image.onerror = () => reject(new Error('Could not load image.')); image.onload = () => { const side = Math.min(image.naturalWidth, image.naturalHeight); const sourceX = (image.naturalWidth - side) / 2, sourceY = (image.naturalHeight - side) / 2; const canvas = document.createElement('canvas'); canvas.width = canvas.height = 300; canvas.getContext('2d').drawImage(image, sourceX, sourceY, side, side, 0, 0, 300, 300); resolve(canvas.toDataURL('image/png')); }; image.src = reader.result; }; reader.readAsDataURL(file); }); }
document.querySelector('#showImage').addEventListener('change', async event => { const file = event.target.files[0]; if (!file) return; try { pendingShowImage = await cropShowImage(file); displayShowImage(pendingShowImage); say('SHOW IMAGE CROPPED TO 300 × 300'); } catch (error) { event.target.value = ''; say(error.message.toUpperCase()); } });
document.querySelector('#removeShowImage').addEventListener('click', () => { pendingShowImage = null; document.querySelector('#showImage').value = ''; displayShowImage(null); say('SHOW IMAGE WILL BE REMOVED WHEN SAVED'); });
const addShow = document.querySelector('#addShow');
const streamerCard = document.querySelector('#shows .grid .card');
document.querySelector('#shows .calendar-top').append(addShow); addShow.style.margin = '0 0 0 auto'; addShow.style.display = 'block';
streamerCard.querySelectorAll('.btn').forEach(button => button.remove());
const selectedShowsPanel = document.createElement('div'); selectedShowsPanel.className = 'grid show-edit-list'; selectedShowsPanel.hidden = true;
document.querySelector('#shows').insertBefore(selectedShowsPanel, streamerCard.parentElement.nextSibling);
const streamerDetails = document.createElement('div'); streamerDetails.className = 'streamer-show-details'; streamerCard.append(streamerDetails);
const viewerPreviewCard = document.querySelectorAll('#shows > .grid .card')[1];
const viewerPreviewDetails = document.createElement('div'); viewerPreviewDetails.className = 'viewer-date-preview'; viewerPreviewCard.append(viewerPreviewDetails);
const viewerShowPanel = document.createElement('div'); viewerShowPanel.id = 'viewerShowPanel'; viewerShowPanel.className = 'card viewer-show-panel'; document.querySelector('#shows').append(viewerShowPanel);
let viewerShowDate = null;
let viewerExpandedShowId = null;
function renderViewerShow(showList = [], dateKey = selectedCalendarDate) {
  const visibleShows = showList.filter(show => !show.noShowDates?.includes(dateKey));
  if (dateKey !== viewerShowDate || !visibleShows.some(show => show.id === viewerExpandedShowId)) viewerExpandedShowId = null;
  viewerShowDate = dateKey;
  if (!visibleShows.length) { viewerShowPanel.innerHTML = `<div class="eyebrow">VIEWER MODE</div><h2>NO SHOW SCHEDULED</h2><p class="sub">SELECT A DATE WITH A SCHEDULED SHOW TO VIEW ITS QUEUE.</p>`; return; }
  const dateLabel = new Date(`${dateKey}T00:00:00`).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase();
  const calendarEnabled = window.LirisQShowCalendarPlugin?.status().active;
  viewerShowPanel.innerHTML = visibleShows.map(show => { const songs = [...show.queue.vip, ...show.queue.standard]; const expanded = viewerExpandedShowId === show.id; const backdrop = show.image ? `<div class="viewer-show-backdrop" aria-hidden="true"><img src="${show.image}" alt=""></div>` : ''; const queueRows = songs.map(item => `<li><span class="viewer-song-marquee"><span class="viewer-song-marquee-track"><a class="song" href="${item.url}" target="_blank" rel="noreferrer">${item.song}</a><span class="artist">— ${item.artist}</span></span></span></li>`).join('') || '<li class="sub">NO SONGS QUEUED YET.</li>'; const calendarControls = calendarEnabled ? `<div class="fields viewer-calendar-export"><label>EVENTS<br><select data-viewer-calendar-scope="${show.id}"><option value="single">THIS SHOW</option><option value="recurring">NEXT 12 OCCURRENCES</option></select></label><label>CALENDAR<br><select data-viewer-calendar-destination="${show.id}"><option value="Apple Calendar">APPLE / iOS</option><option value="Google Calendar on Android">GOOGLE / ANDROID</option><option value="Outlook or your Windows calendar app">OUTLOOK / WINDOWS</option><option value="your calendar app">OTHER CALENDAR</option></select></label><button class="btn hot" data-viewer-calendar-add="${show.id}">ADD TO CALENDAR</button></div><p class="queue-note" data-viewer-calendar-feedback="${show.id}">Choose a calendar, then add this show. Your device confirms the final calendar import.</p>` : '<p class="queue-note">Calendar Export is not available for this stream.</p>'; return `<section class="viewer-show-card ${expanded ? 'expanded' : ''}" data-viewer-show-card="${show.id}">${backdrop}<article class="viewer-show-summary" data-viewer-show-summary="${show.id}" role="button" tabindex="0" aria-expanded="${expanded}" aria-label="View ${show.title} queue"><div class="eyebrow">VIEWER MODE · ${dateLabel}</div><h2>${show.title}</h2><p class="sub">${new Date(`1970-01-01T${show.time}:00`).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})} LOCAL · ${songs.length}/${show.maxSongs} SONGS</p><p class="viewer-show-summary-hint">${expanded ? 'CLICK TO SHRINK' : 'CLICK TO VIEW QUEUE'}</p></article><div class="viewer-show-detail"><div class="viewer-show-detail-inner"><ol class="viewer-queue">${queueRows}</ol>${calendarControls}<div class="fields viewer-request"><input data-viewer-song="${show.id}" placeholder="SONG TITLE" required><input data-viewer-artist="${show.id}" placeholder="ARTIST" required><input data-viewer-url="${show.id}" type="url" placeholder="SONG URL" required><button class="btn hot" data-viewer-request="${show.id}">ADD TO THIS SHOW</button></div></div></div></section>`; }).join('');
  if (calendarEnabled) for (const select of viewerShowPanel.querySelectorAll('[data-viewer-calendar-destination]')) { const showId = select.dataset.viewerCalendarDestination; const detectedDestination = detectViewerCalendarDestination(); const choices = document.createElement('div'); choices.className = 'viewer-calendar-destinations'; choices.dataset.viewerCalendarDestination = showId; choices.dataset.selected = detectedDestination; choices.setAttribute('role', 'group'); choices.setAttribute('aria-label', 'Calendar destination'); choices.innerHTML = ['ios','windows','android','other'].map(destination => `<button type="button" class="viewer-calendar-choice" data-viewer-calendar-choice="${showId}" data-destination="${destination}" aria-pressed="${destination === detectedDestination}" title="${viewerCalendarDestinationNames[destination]}">${calendarProviderIcon(destination === 'ios' ? 'apple' : destination)}</button>`).join(''); select.closest('label').replaceWith(choices); const add = viewerShowPanel.querySelector(`[data-viewer-calendar-add="${showId}"]`); if (add) add.innerHTML = `<span class="calendar-add-icon" aria-hidden="true">${calendarAddIcon()}</span> ADD TO CALENDAR`; const feedback = viewerShowPanel.querySelector(`[data-viewer-calendar-feedback="${showId}"]`); if (feedback) feedback.textContent = `${viewerCalendarDestinationNames[detectedDestination].toUpperCase()} SELECTED FOR THIS DEVICE. CHOOSE ANOTHER ICON IF NEEDED, THEN ADD THIS SHOW.`; }
  if (viewerExpandedShowId) requestAnimationFrame(enableViewerQueueMarquees);
}
function setViewerShowExpanded(showId, expanded) { viewerExpandedShowId = expanded ? showId : null; viewerShowPanel.querySelectorAll('[data-viewer-show-card]').forEach(card => { const active = expanded && card.dataset.viewerShowCard === showId; card.classList.toggle('expanded', active); card.querySelector('[data-viewer-show-summary]').setAttribute('aria-expanded', String(active)); card.querySelector('.viewer-show-summary-hint').textContent = active ? 'CLICK TO SHRINK' : 'CLICK TO VIEW QUEUE'; }); if (expanded) requestAnimationFrame(enableViewerQueueMarquees); }
const renderViewerShowBase = renderViewerShow;
renderViewerShow = function (...args) { renderViewerShowBase(...args); for (const input of viewerShowPanel.querySelectorAll('[data-viewer-artist]')) { const select=document.createElement('select'); select.dataset.viewerRepresentedArtist=input.dataset.viewerArtist; select.innerHTML='<option value="">ADD ARTIST…</option>'; for(const artist of window.LIRISQ_VIEWER_ARTISTS||[]){const option=new Option(artist,artist);option.selected=artist===localStorage.getItem('lirisq-viewer-last-artist');select.append(option);} input.before(select); if(select.value)input.value=select.value; } };
function enableViewerQueueMarquees() { viewerShowPanel.querySelectorAll('.viewer-song-marquee:not(.is-marquee)').forEach(marquee => { if (marquee.scrollWidth <= marquee.clientWidth + 1) return; const track = marquee.querySelector('.viewer-song-marquee-track'); const distance = track.scrollWidth + 36; const copies = [...track.children].map(child => child.cloneNode(true)); const gap = document.createElement('span'); gap.className = 'marquee-gap'; gap.setAttribute('aria-hidden', 'true'); gap.textContent = '·'; track.append(gap, ...copies); marquee.classList.add('is-marquee'); marquee.style.setProperty('--marquee-distance', `${distance}px`); marquee.style.setProperty('--marquee-duration', `${Math.max(6, distance / 24)}s`); }); }
viewerShowPanel.addEventListener('click', async event => {
  const summary = event.target.closest('[data-viewer-show-summary]');
  if (summary) { event.stopPropagation(); const showId = summary.dataset.viewerShowSummary; return setViewerShowExpanded(showId, viewerExpandedShowId !== showId); }
  const calendarChoice = event.target.closest('[data-viewer-calendar-choice]');
  if (calendarChoice) { const showId = calendarChoice.dataset.viewerCalendarChoice; const group = viewerShowPanel.querySelector(`[data-viewer-calendar-destination="${showId}"]`); if (group) { group.dataset.selected = calendarChoice.dataset.destination; group.querySelectorAll('[data-viewer-calendar-choice]').forEach(choice => choice.setAttribute('aria-pressed', String(choice === calendarChoice))); } return; }
  const calendarAdd = event.target.closest('[data-viewer-calendar-add]');
  if (calendarAdd) {
    const showId = calendarAdd.dataset.viewerCalendarAdd; const show = shows.find(item => item.id === showId); const card = calendarAdd.closest('[data-viewer-show-card]');
    const recurring = card?.querySelector(`[data-viewer-calendar-scope="${showId}"]`)?.value === 'recurring'; const destination = viewerCalendarDestinationNames[card?.querySelector(`[data-viewer-calendar-destination="${showId}"]`)?.dataset.selected] || 'your calendar app'; const feedback = card?.querySelector(`[data-viewer-calendar-feedback="${showId}"]`);
    try { feedback.textContent = await addCalendarToDevice(calendarExportPayloadForShow(show, viewerShowDate, recurring), destination); }
    catch (error) { if (error?.name !== 'AbortError') feedback.textContent = String(error.message || error); }
    return;
  }
  const request = event.target.closest('[data-viewer-request]'); if (!request) return;
  const showId = request.dataset.viewerRequest; const show = shows.find(item => item.id === showId);
  const song = document.querySelector(`[data-viewer-song="${showId}"]`)?.value.trim(), artist = document.querySelector(`[data-viewer-artist="${showId}"]`)?.value.trim(), url = document.querySelector(`[data-viewer-url="${showId}"]`)?.value.trim();
  if (!show || !song || !artist || !url) return say('SONG TITLE, ARTIST, AND URL ARE REQUIRED');
  const total = show.queue.vip.length + show.queue.standard.length; const account = serverAudienceIdentity?.login || localStorage.getItem('lirisq-twitch-account') || 'viewer'; const viewerSongs = [...show.queue.vip, ...show.queue.standard].filter(item => item.viewer === account).length;
  if (total >= show.maxSongs) return say('THIS SHOW QUEUE IS FULL'); if (viewerSongs >= show.maxPerViewer) return say('YOUR SHOW REQUEST LIMIT IS REACHED');
  const viewerId = serverAudienceIdentity?.id || ''; if (usesServerAudience() && viewerId) { try { const response=await fetch(twitchEndpoint('viewer-profile'),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({operation:'activity',song,artist,url,activity:'submitted'})}); if(!response.ok)throw Error('PROFILE ACTIVITY COULD NOT BE SAVED'); } catch(error) { return say(String(error.message||error)); } }
  localStorage.setItem('lirisq-viewer-last-artist',artist); show.queue.standard.push({ id: crypto.randomUUID(), song, artist, viewer: account, viewerId, url }); saveShows(); renderViewerShow(shows.filter(item => showOccurs(item, new Date(`${selectedCalendarDate}T00:00:00`))), selectedCalendarDate); say('ADDED TO THIS SHOW');
});
viewerShowPanel.addEventListener('change', event => { const select=event.target.closest('[data-viewer-represented-artist]'); if(!select)return; const input=viewerShowPanel.querySelector(`[data-viewer-artist="${select.dataset.viewerRepresentedArtist}"]`); if(select.value&&input){input.value=select.value;localStorage.setItem('lirisq-viewer-last-artist',select.value);} });
viewerShowPanel.addEventListener('keydown', event => { const summary = event.target.closest('[data-viewer-show-summary]'); if (summary && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); const showId = summary.dataset.viewerShowSummary; setViewerShowExpanded(showId, viewerExpandedShowId !== showId); } });
document.addEventListener('click', event => { if (!viewerExpandedShowId || viewerShowPanel.contains(event.target)) return; setViewerShowExpanded(viewerExpandedShowId, false); });
let editingShowId = null;
let editingShowDate = null;
let editingShowMode = 'single';
function openShowEditor(show, mode = 'single', occurrenceDate = show?.date) { editingShowId = show?.id || null; editingShowMode = mode; editingShowDate = show && mode === 'single' ? occurrenceDate : null; document.querySelector('#showEditorTitle').textContent = show ? (mode === 'recurring' ? 'EDIT RECURRING SHOW' : 'EDIT THIS SHOW') : 'ADD SHOW'; document.querySelector('#saveShow').textContent = show ? 'SAVE SHOW' : 'CREATE SHOW & QUEUE'; document.querySelector('#showTitle').value = show?.title || ''; document.querySelector('#showDate').value = show?.date || localDate(new Date()); document.querySelector('#showTime').value = show?.time || '19:30'; document.querySelector('#showRecurrence').value = show?.recurrence || 'once'; syncRepeatDays(show?.repeatDays); document.querySelector('#showViewerMax').value = show?.maxPerViewer || 2; document.querySelector('#showQueueMax').value = show?.maxSongs || 50; document.querySelector('#showNotes').value = show?.notes || ''; const noShowWrap = document.querySelector('#showNoShowWrap'); noShowWrap.hidden = !editingShowDate; document.querySelector('#showNoShow').checked = Boolean(editingShowDate && show?.noShowDates?.includes(editingShowDate)); noShowWrap.querySelector('span').textContent = editingShowDate ? `NO SHOW FOR ${editingShowDate} (THIS SHOW ONLY)` : 'NO SHOW FOR THIS DATE'; showModal.hidden = false; document.querySelector('#showTitle').focus(); }
const openShowEditorBase = openShowEditor;
openShowEditor = function(show, mode = 'single', occurrenceDate = show?.date) { openShowEditorBase(show, mode, occurrenceDate); pendingShowImage = show?.image || null; document.querySelector('#showImage').value = ''; displayShowImage(pendingShowImage); };
function showImageMarkup(show) { return show?.image ? `<img class="show-card-image" src="${show.image}" alt="${show.title} show image">` : ''; }
let streamerSelectedDate = null;
let streamerExpandedShowId = null;
let streamerViewerPreviewExpandedShowId = null;
function renderSelectedShows(showList = [], dateKey = null) { selectedShowsPanel.hidden = true; if (dateKey !== streamerSelectedDate || !showList.some(show => show.id === streamerExpandedShowId)) streamerExpandedShowId = null; if (dateKey !== streamerSelectedDate || !showList.some(show => show.id === streamerViewerPreviewExpandedShowId)) streamerViewerPreviewExpandedShowId = null; streamerSelectedDate = dateKey; const dateLabel = dateKey ? new Date(`${dateKey}T00:00:00`).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase() : 'SELECTED DATE'; const [streamerSummary, viewerSummary] = document.querySelectorAll('#shows > .grid .card'); streamerSummary.querySelector('.show-summary-backdrop')?.remove(); viewerSummary.querySelector('.show-summary-backdrop')?.remove(); streamerSummary.querySelector('.eyebrow').textContent = `STREAMER VIEW · ${dateLabel}`; streamerSummary.querySelector('h2').textContent = `${showList.length} ${showList.length === 1 ? 'SHOW' : 'SHOWS'}`; streamerSummary.querySelector('.sub').textContent = 'SELECT A SHOW TO EDIT ITS INSTANCE OR RECURRENCE.'; viewerSummary.querySelector('.eyebrow').textContent = `VIEWER VIEW · ${dateLabel}`; viewerSummary.querySelector('h2').textContent = `${showList.length} ${showList.length === 1 ? 'SHOW' : 'SHOWS'}`; viewerSummary.querySelector('.sub').textContent = 'VIEWER-FACING SHOW LIST FOR THIS DATE.'; const viewerNotice = viewerSummary.querySelector('.notice'); if (viewerNotice) viewerNotice.textContent = 'EACH SHOW DISPLAYS ITS LOCAL TIME AND LIVE QUEUE TOTAL.'; streamerDetails.innerHTML = showList.map(show => { const occurrenceDate = dateKey || show.date; const cancelled = Boolean(show.noShowDates?.includes(occurrenceDate)); const total = show.queue.vip.length + show.queue.standard.length; const expanded = streamerExpandedShowId === show.id; const backdrop = show.image ? `<div class="viewer-show-backdrop" aria-hidden="true"><img src="${show.image}" alt=""></div>` : ''; const queueRows = [...show.queue.vip, ...show.queue.standard].map(item => `<li><span class="viewer-song-marquee"><span class="viewer-song-marquee-track"><a class="song" href="${item.url}" target="_blank" rel="noreferrer">${item.song}</a><span class="artist">— ${item.artist}</span></span></span></li>`).join('') || '<li class="sub">NO SONGS QUEUED YET.</li>'; return `<section class="viewer-show-card streamer-show-card ${expanded ? 'expanded' : ''}" data-streamer-show-card="${show.id}">${backdrop}<article class="viewer-show-summary" data-streamer-show-summary="${show.id}" role="button" tabindex="0" aria-expanded="${expanded}" aria-label="View streamer controls for ${show.title}"><div class="eyebrow">${new Date(`1970-01-01T${show.time}:00`).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})} LOCAL</div><h2>${show.title}</h2><p class="sub">${total}/${show.maxSongs} SONGS · ${show.maxPerViewer} PER TWITCH ACCOUNT</p><p class="viewer-show-summary-hint">${expanded ? 'CLICK TO SHRINK' : 'CLICK TO MANAGE SHOW'}</p></article><div class="viewer-show-detail"><div class="viewer-show-detail-inner"><ol class="viewer-queue">${queueRows}</ol><p class="sub">${show.recurrence.toUpperCase()} · ${show.maxPerViewer} SONGS PER TWITCH ACCOUNT</p><div class="streamer-show-actions"><button class="btn" data-edit-show="${show.id}" data-edit-date="${occurrenceDate}">EDIT THIS SHOW</button> <button class="btn" data-edit-recurring="${show.id}">EDIT RECURRING</button> <button class="btn ${cancelled ? '' : 'hot'}" data-no-show-show="${show.id}" data-no-show-date="${occurrenceDate}">${cancelled ? 'RESTORE THIS SHOW' : 'NO SHOW THIS DATE'}</button></div></div></div></section>`; }).join('') || '<p class="sub">NO SHOWS SCHEDULED FOR THIS DATE.</p>'; viewerPreviewDetails.innerHTML = showList.map(show => { const total = show.queue.vip.length + show.queue.standard.length; const expanded = streamerViewerPreviewExpandedShowId === show.id; const backdrop = show.image ? `<div class="viewer-show-backdrop" aria-hidden="true"><img src="${show.image}" alt=""></div>` : ''; const queueRows = [...show.queue.vip, ...show.queue.standard].map(item => `<li><span class="viewer-song-marquee"><span class="viewer-song-marquee-track"><a class="song" href="${item.url}" target="_blank" rel="noreferrer">${item.song}</a><span class="artist">— ${item.artist}</span></span></span></li>`).join('') || '<li class="sub">NO SONGS QUEUED YET.</li>'; return `<section class="viewer-show-card streamer-viewer-preview-card ${expanded ? 'expanded' : ''}" data-streamer-viewer-preview-card="${show.id}">${backdrop}<article class="viewer-show-summary" data-streamer-viewer-preview-summary="${show.id}" role="button" tabindex="0" aria-expanded="${expanded}" aria-label="Preview ${show.title} viewer queue"><div class="eyebrow">${new Date(`1970-01-01T${show.time}:00`).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})} LOCAL</div><h2>${show.title}</h2><p class="sub">${total}/${show.maxSongs} SONGS · ${show.maxPerViewer} PER TWITCH ACCOUNT</p><p class="viewer-show-summary-hint">${expanded ? 'CLICK TO SHRINK' : 'CLICK TO VIEW QUEUE'}</p></article><div class="viewer-show-detail"><div class="viewer-show-detail-inner"><ol class="viewer-queue">${queueRows}</ol><p class="sub">VIEWER QUEUE PREVIEW</p></div></div></section>`; }).join('') || '<p class="sub">NO SHOWS SCHEDULED FOR THIS DATE.</p>'; }
function setStreamerShowExpanded(showId, expanded) { streamerExpandedShowId = expanded ? showId : null; streamerDetails.querySelectorAll('[data-streamer-show-card]').forEach(card => { const active = expanded && card.dataset.streamerShowCard === showId; card.classList.toggle('expanded', active); card.querySelector('[data-streamer-show-summary]').setAttribute('aria-expanded', String(active)); card.querySelector('.viewer-show-summary-hint').textContent = active ? 'CLICK TO SHRINK' : 'CLICK TO MANAGE SHOW'; }); if (expanded) requestAnimationFrame(enableStreamerQueueMarquees); }
function enableStreamerQueueMarquees() { streamerDetails.querySelectorAll('.viewer-song-marquee:not(.is-marquee)').forEach(marquee => { if (marquee.scrollWidth <= marquee.clientWidth + 1) return; const track = marquee.querySelector('.viewer-song-marquee-track'); const distance = track.scrollWidth + 36; const copies = [...track.children].map(child => child.cloneNode(true)); const gap = document.createElement('span'); gap.className = 'marquee-gap'; gap.setAttribute('aria-hidden', 'true'); gap.textContent = '·'; track.append(gap, ...copies); marquee.classList.add('is-marquee'); marquee.style.setProperty('--marquee-distance', `${distance}px`); marquee.style.setProperty('--marquee-duration', `${Math.max(6, distance / 24)}s`); }); }
function setStreamerViewerPreviewExpanded(showId, expanded) { streamerViewerPreviewExpandedShowId = expanded ? showId : null; viewerPreviewDetails.querySelectorAll('[data-streamer-viewer-preview-card]').forEach(card => { const active = expanded && card.dataset.streamerViewerPreviewCard === showId; card.classList.toggle('expanded', active); card.querySelector('[data-streamer-viewer-preview-summary]').setAttribute('aria-expanded', String(active)); card.querySelector('.viewer-show-summary-hint').textContent = active ? 'CLICK TO SHRINK' : 'CLICK TO VIEW QUEUE'; }); }
addShow.addEventListener('click', () => openShowEditor());
showModal.addEventListener('click', event => { if (event.target === showModal || event.target.closest('[data-close-show]')) showModal.hidden = true; });
document.querySelector('#saveShow').addEventListener('click', () => {
  const title = document.querySelector('#showTitle').value.trim(); const date = document.querySelector('#showDate').value; const time = document.querySelector('#showTime').value;
  const maxPerViewer = Number(document.querySelector('#showViewerMax').value), maxSongs = Number(document.querySelector('#showQueueMax').value);
  if (!title || !date || !time || !maxPerViewer || !maxSongs) return say('TITLE, LOCAL DATE/TIME, AND BOTH LIMITS ARE REQUIRED');
  const recurrence = document.querySelector('#showRecurrence').value; const repeatDays = selectedRepeatDays();
  if (['weekly', 'biweekly'].includes(recurrence) && !repeatDays.length) return say('SELECT AT LEAST ONE REPEAT DAY');
  const values = { title: title.toUpperCase(), date, time, recurrence, repeatDays: ['weekly', 'biweekly'].includes(recurrence) ? repeatDays : [], notes: document.querySelector('#showNotes').value.trim(), image: pendingShowImage, maxPerViewer, maxSongs };
  const existing = shows.find(show => show.id === editingShowId);
  if (existing) { Object.assign(existing, values); if (editingShowMode === 'single' && editingShowDate) { existing.noShowDates ||= []; const noShow = document.querySelector('#showNoShow').checked; existing.noShowDates = noShow ? [...new Set([...existing.noShowDates, editingShowDate])] : existing.noShowDates.filter(dateKey => dateKey !== editingShowDate); } activeShowId = existing.id; state = clone(existing.queue); saveShows(); showModal.hidden = true; renderCalendar(); renderStreamerView(); renderSelectedShows([existing], editingShowDate || existing.date); render(); return say(`${title.toUpperCase()} UPDATED`); }
  const newShow = { id: crypto.randomUUID(), ...values, queue: { vip: [], standard: [] }, noShowDates: [] };
  shows.push(newShow); activeShowId = newShow.id; localStorage.setItem('lirisq-active-show', activeShowId); state = clone(newShow.queue);
  saveShows(); showModal.hidden = true; renderCalendar(); renderStreamerView(); renderSelectedShows([newShow], newShow.date); render(); say(`${title.toUpperCase()} CREATED WITH ITS OWN EMPTY QUEUE`);
});
document.querySelector('#calendar').addEventListener('click', event => {
  const eventLink = event.target.closest('.event'); const day = event.target.closest('.day'); if (!day?.dataset.date) return;
  event.preventDefault();
  const dateKey = day.dataset.date;
  selectedCalendarDate = dateKey;
  renderCalendar();
  const scheduled = shows.filter(show => showOccurs(show, new Date(`${dateKey}T00:00:00`)));
  const matchingShows = eventLink ? scheduled.filter(show => show.id === eventLink.dataset.showId) : scheduled;
  if (document.body.dataset.audience === 'viewer') { renderViewerShow(matchingShows, dateKey); return; }
  renderSelectedShows(matchingShows, dateKey);
  if (eventLink && matchingShows[0]) openShowEditor(matchingShows[0], 'single', dateKey);
});
streamerCard.addEventListener('click', event => {
  const summary = event.target.closest('[data-streamer-show-summary]');
  if (summary) { event.stopPropagation(); const showId = summary.dataset.streamerShowSummary; return setStreamerShowExpanded(showId, streamerExpandedShowId !== showId); }
  const editId = event.target.dataset.editShow;
  const editDate = event.target.dataset.editDate;
  const recurringId = event.target.dataset.editRecurring;
  const noShowId = event.target.dataset.noShowShow;
  if (editId || recurringId) {
    const show = shows.find(item => item.id === (editId || recurringId));
    if (show) openShowEditor(show, recurringId ? 'recurring' : 'single', editDate || show.date);
    return;
  }
  if (!noShowId) return;
  const show = shows.find(item => item.id === noShowId); const dateKey = event.target.dataset.noShowDate;
  if (!show || !dateKey) return;
  show.noShowDates ||= [];
  const wasNoShow = show.noShowDates.includes(dateKey);
  show.noShowDates = wasNoShow ? show.noShowDates.filter(date => date !== dateKey) : [...show.noShowDates, dateKey];
  saveShows(); renderCalendar();
  renderSelectedShows(shows.filter(item => showOccurs(item, new Date(`${dateKey}T00:00:00`))), dateKey);
  say(wasNoShow ? `${show.title} RESTORED` : `${show.title} MARKED NO SHOW`);
});
streamerCard.addEventListener('keydown', event => { const summary = event.target.closest('[data-streamer-show-summary]'); if (summary && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); const showId = summary.dataset.streamerShowSummary; setStreamerShowExpanded(showId, streamerExpandedShowId !== showId); } });
document.addEventListener('click', event => { if (!streamerExpandedShowId || streamerCard.contains(event.target)) return; setStreamerShowExpanded(streamerExpandedShowId, false); });
viewerPreviewCard.addEventListener('click', event => { const summary = event.target.closest('[data-streamer-viewer-preview-summary]'); if (!summary) return; event.stopPropagation(); const showId = summary.dataset.streamerViewerPreviewSummary; setStreamerViewerPreviewExpanded(showId, streamerViewerPreviewExpandedShowId !== showId); });
viewerPreviewCard.addEventListener('keydown', event => { const summary = event.target.closest('[data-streamer-viewer-preview-summary]'); if (summary && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); const showId = summary.dataset.streamerViewerPreviewSummary; setStreamerViewerPreviewExpanded(showId, streamerViewerPreviewExpandedShowId !== showId); } });
document.addEventListener('click', event => { if (!streamerViewerPreviewExpandedShowId || viewerPreviewCard.contains(event.target)) return; setStreamerViewerPreviewExpanded(streamerViewerPreviewExpandedShowId, false); });
renderCalendar();
renderStreamerView();
const mgbSetting = document.querySelector('#mgbConnect').closest('.setting');
mgbSetting.classList.add('mgb-required-setting');
document.querySelector('#settings .settings').prepend(mgbSetting);
const mgbRequiredStyle = document.createElement('style');
mgbRequiredStyle.textContent = '.mgb-required-setting{padding:16px;margin:0 -10px;border:1px solid #9b3150;background:#3a1020}.mgb-required-setting.mgb-paired-awaiting{border-color:#2b4d46;background:color-mix(in srgb,var(--panel) 92%,#143a31)}.mgb-required-setting.mgb-connected{border-color:#2b4d46;background:color-mix(in srgb,var(--panel) 92%,#143a31);opacity:.7}.mgb-required-setting #mgbNote{color:#ffb3c9}.mgb-required-setting.mgb-paired-awaiting #mgbNote,.mgb-required-setting.mgb-connected #mgbNote{color:#9abfb1}.mgb-model-opt-in{display:block;margin-top:12px;color:var(--ink);font:500 11px/1.45 \'DM Mono\',monospace}.mgb-model-opt-in input{accent-color:var(--hot);margin-right:8px}.mgb-pairing{margin-top:14px;padding-top:12px;border-top:1px solid #8d3b55}.mgb-paired-awaiting .mgb-pairing{border-top-color:#2b4d46}.mgb-pairing .fields{margin:10px 0 0}.mgb-pairing-code-row{display:flex;align-items:center;gap:9px;margin-top:10px}.mgb-pairing-code{margin:0;color:#fff;font:700 24px/1 \'DM Mono\',monospace;letter-spacing:.16em}.mgb-copy-code{padding:5px 8px;font-size:16px;line-height:1}.mgb-pairing-status{margin:9px 0 0;color:#ffc5d6;font:500 10px/1.45 \'DM Mono\',monospace}.mgb-paired-awaiting .mgb-pairing-status{color:#9abfb1}.mgb-compact-toggle{display:none;width:100%;border:0;background:transparent;color:var(--ink);padding:0;text-align:left;font:700 13px \'DM Mono\',monospace}.mgb-connected:not(.mgb-expanded),.mgb-paired-awaiting:not(.mgb-expanded){padding:11px 14px}.mgb-connected:not(.mgb-expanded)>.mgb-compact-toggle,.mgb-paired-awaiting:not(.mgb-expanded)>.mgb-compact-toggle{display:flex;align-items:center;justify-content:space-between}.mgb-connected:not(.mgb-expanded)>:not(.mgb-compact-toggle),.mgb-paired-awaiting:not(.mgb-expanded)>:not(.mgb-compact-toggle){display:none}.mgb-connected.mgb-expanded>.mgb-compact-toggle,.mgb-paired-awaiting.mgb-expanded>.mgb-compact-toggle{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}.playback-mode-card{display:flex;align-items:center;justify-content:space-between;gap:12px;width:max-content;max-width:100%;margin:12px 0;padding:9px 10px;border:1px solid var(--line);background:var(--panel2)}.playback-mode-card>b{font:700 11px \'DM Mono\',monospace;color:var(--muted);white-space:nowrap}.playback-mode-options{display:flex;gap:4px}.playback-mode-option{border:1px solid transparent;background:transparent;color:var(--muted);padding:5px 7px;font:700 11px \'DM Mono\',monospace}.playback-mode-option.active{border-color:var(--cyan);color:var(--cyan);background:#61e5f512}';
document.head.append(mgbRequiredStyle);
const mgbModelOptIn = document.createElement('label');
mgbModelOptIn.className = 'mgb-model-opt-in';
mgbModelOptIn.innerHTML = '<input id="mgbModelImprovementOptIn" type="checkbox"> STREAMER OPT-IN: I understand that MGB may collect music-playback metadata (such as track title, artist, and playback events) solely to improve MGB gaming model performance.';
mgbSetting.querySelector('div').append(mgbModelOptIn);
const mgbModelImprovementOptIn = mgbModelOptIn.querySelector('input');
mgbModelImprovementOptIn.checked = localStorage.getItem('lirisq-mgb-model-improvement-opt-in') === 'true';
mgbModelImprovementOptIn.addEventListener('change', () => {
  localStorage.setItem('lirisq-mgb-model-improvement-opt-in', String(mgbModelImprovementOptIn.checked));
  refreshMgbLockdown();
});
const mgbPairing = document.createElement('div');
mgbPairing.className = 'mgb-pairing';
mgbPairing.innerHTML = '<h3>PAIR WITH MGB</h3><p class="queue-note">IN MGB, CHOOSE PAIR WITH LIRISQ TO GET A SIX-DIGIT CODE. PASTE IT HERE, THEN PAIR.</p><label>MGB PAIRING CODE<input id="mgbPairingCode" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000"></label><div class="fields"><button id="mgbPair" class="btn hot" type="button" disabled>PAIR WITH MGB</button><button id="mgbRemovePairing" class="btn uninstall" type="button" hidden>REMOVE PAIRING</button></div><p id="mgbPairingStatus" class="mgb-pairing-status" role="status">STREAMER OPT-IN IS REQUIRED BEFORE PAIRING.</p>';
mgbSetting.append(mgbPairing);
const mgbPairingCode = mgbPairing.querySelector('#mgbPairingCode');
const mgbPair = mgbPairing.querySelector('#mgbPair');
const mgbRemovePairing = mgbPairing.querySelector('#mgbRemovePairing');
const mgbPairingStatus = mgbPairing.querySelector('#mgbPairingStatus');
const mgbCompactToggle = document.createElement('button');
mgbCompactToggle.type = 'button'; mgbCompactToggle.className = 'mgb-compact-toggle'; mgbCompactToggle.hidden = true;
mgbCompactToggle.innerHTML = '<span>MGB — PAIRED</span><span aria-hidden="true">▸</span>';
mgbSetting.prepend(mgbCompactToggle);
function setMgbExpanded(expanded) {
  if (!mgbBrokerPaired()) return;
  if (mgbSetting.classList.contains('mgb-expanded') === expanded && mgbCompactToggle.getAttribute('aria-expanded') === String(expanded)) return;
  mgbSetting.classList.toggle('mgb-expanded', expanded);
  mgbCompactToggle.querySelector('span:last-child').textContent = expanded ? '▾' : '▸';
  mgbCompactToggle.setAttribute('aria-expanded', String(expanded));
}
mgbCompactToggle.addEventListener('click', () => setMgbExpanded(!mgbSetting.classList.contains('mgb-expanded')));
function renderMgbPairing() {
  const connected = mgbIsConnected(), optedIn = mgbModelImprovementOptIn.checked;
  const paired = mgbBrokerPaired();
  mgbPairingCode.disabled = paired;
  mgbPair.disabled = paired || !optedIn || !/^\d{6}$/.test(mgbPairingCode.value);
  mgbRemovePairing.hidden = !paired;
  if (mgbPairingError) mgbPairingStatus.textContent = mgbPairingError;
  else if (connected) mgbPairingStatus.textContent = 'PAIRED WITH MGB. PLAYBACK LINK IS ACTIVE.';
  else if (paired) mgbPairingStatus.textContent = mgbPlaybackLinkStatus || 'PAIRED. WAITING FOR MGB PLAYBACK LINK.';
  else if (!optedIn) mgbPairingStatus.textContent = 'STREAMER OPT-IN IS REQUIRED BEFORE PAIRING.';
  else mgbPairingStatus.textContent = 'PASTE THE SIX-DIGIT CODE FROM MGB TO PAIR.';
}
mgbPairingCode.addEventListener('input', () => { mgbPairingError = ''; mgbPairingCode.value = mgbPairingCode.value.replace(/\D/g, '').slice(0, 6); renderMgbPairing(); });
mgbPair.addEventListener('click', async () => {
  try {
    if (!mgbModelImprovementOptIn.checked) throw new Error('Streamer model-improvement opt-in is required');
    const code = mgbPairingCode.value;
    if (!/^\d{6}$/.test(code)) throw new Error('Enter the six-digit code from MGB');
    mgbPairingError = ''; mgbPair.disabled = true; mgbPairingStatus.textContent = 'PAIRING WITH MGB…';
    const result = await mgbBrokerRequest({ action:'join', code, clientId:mgbClientId(), clientSecret:mgbClientSecret() });
    if (!result.paired || !result.pairingId) throw new Error('MGB pairing was not confirmed');
    localStorage.setItem(mgbPairingIdKey, result.pairingId); mgbPairingRestoring = true; mgbPairingCode.value = ''; await refreshMgbBrokerPairing(); refreshMgbLockdown(); say('MGB PAIRING COMPLETE');
  } catch (error) { mgbPairingError = `PAIRING FAILED: ${String(error.message || error)}`; renderMgbPairing(); }
});
mgbRemovePairing.addEventListener('click', async () => {
  const pairingId = mgbPairingId(); if (!pairingId || !window.confirm('Remove this MGB pairing?')) return;
  try {
    mgbRemovePairing.disabled = true; mgbPairingStatus.textContent = 'REMOVING MGB PAIRING…';
    await mgbBrokerRequest({ action:'remove', pairingId, clientId:mgbClientId(), clientSecret:mgbClientSecret() });
    clearMgbBrokerPairing(); refreshMgbLockdown(); say('MGB PAIRING REMOVED');
  } catch (error) { mgbPairingStatus.textContent = String(error.message || error); mgbRemovePairing.disabled = false; }
});
const twitchSetting = document.querySelector('#twitchConnect').closest('.setting');
const twitchBitsSetting = document.querySelector('#bitsThreshold').closest('.setting');
twitchBitsSetting?.remove();
const twitchConnectButton = document.querySelector('#twitchConnect');
const twitchNote = document.querySelector('#twitchNote');
const streamerIdentitySetting = document.createElement('div'); streamerIdentitySetting.className = 'setting';
streamerIdentitySetting.innerHTML = `<div><h3>STREAMER PROFILE</h3><p>CHOOSE THE TWITCH PROFILE THAT WILL OWN THIS LIRISQ INSTALLATION. SAVING A PROFILE DOES NOT AUTHORIZE TWITCH.</p></div><div><input id="streamerProfileName" aria-label="Streamer Twitch profile" placeholder="TWITCH PROFILE"> <button id="designateStreamer" class="btn">SAVE PROFILE</button></div>`;
const streamerProfileInput = streamerIdentitySetting.querySelector('#streamerProfileName');
twitchSetting.before(streamerIdentitySetting);
async function renderStreamerIdentity() {
  const hosted = usesServerAudience();
  if (hosted && currentAudienceRole() !== 'streamer') { streamerProfileInput.value = ''; twitchConnectButton.disabled = true; twitchConnectButton.textContent = 'STREAMER SIGN-IN REQUIRED'; twitchNote.textContent = 'SIGN IN AS THE DESIGNATED STREAMER TO MANAGE THIS INSTALLATION.'; return; }
  const designated = localStorage.getItem('lirisq-streamer-profile') || ''; streamerProfileInput.value = designated;
  twitchConnectButton.disabled = true; twitchConnectButton.textContent = 'CHECKING TWITCH…';
  if (!designated) { twitchNote.textContent = 'SELECT A STREAMER PROFILE FIRST.'; twitchConnectButton.textContent = 'CONNECT TWITCH'; return; }
  try {
    const response = await fetch(twitchEndpoint('status'), { cache: 'no-store' }); const status = response.ok ? await response.json() : null;
    if (!status?.oauthConfigured) { twitchConnectButton.textContent = 'TWITCH SERVER SETUP REQUIRED'; twitchNote.textContent = `PROFILE ${designated.toUpperCase()} SELECTED. ADD THE TWITCH SERVER ENVIRONMENT VALUES BEFORE CONNECTING.`; return; }
    if (status.authorized) { const login = String(status.broadcaster?.login || designated); twitchConnectButton.textContent = 'TWITCH CONNECTED'; twitchNote.textContent = `CONNECTED AS ${login.toUpperCase()}. TWITCH TOKENS ARE HELD ONLY BY THE LOCAL SERVER.`; return; }
    twitchConnectButton.disabled = false; twitchConnectButton.textContent = 'CONNECT TWITCH'; twitchNote.textContent = `PROFILE ${designated.toUpperCase()} SELECTED. CONNECT TWITCH TO AUTHORIZE EVENTSUB AND CHAT.`;
  } catch (_) { twitchConnectButton.textContent = 'TWITCH SERVER UNAVAILABLE'; twitchNote.textContent = 'THE LOCAL TWITCH SERVER IS NOT AVAILABLE.'; }
}
document.querySelector('#twitchConnect').addEventListener('click', () => { window.location.assign(twitchEndpoint('authorize')); });
document.querySelector('#designateStreamer').addEventListener('click', () => { if (twitchTransportConfiguration().kind === 'php') return window.location.assign(twitchEndpoint('authorize')); const account = streamerProfileInput.value.trim().replace(/^@/, ''); if (!/^[a-zA-Z0-9_]{4,25}$/.test(account)) return say('ENTER A VALID TWITCH USERNAME'); localStorage.setItem('lirisq-streamer-profile', account); localStorage.setItem('lirisq-session-role', 'streamer'); window.LirisQTwitchLiveAdapterPlugin?.configure?.({ channel: account, streamerProfile: account }); renderStreamerIdentity(); renderAccountProfile(); renderPlatformPluginConfigurations(); say(`${account.toUpperCase()} DESIGNATED AS STREAMER PROFILE`); });
localStorage.removeItem('lirisq-streamer-oauth');
void renderStreamerIdentity();
function refreshMgbLockdown() {
  const connected = mgbIsConnected(), paired = mgbBrokerPaired(); const button = document.querySelector('#mgbConnect'); const note = document.querySelector('#mgbNote');
  if (button) { button.textContent = connected ? 'MGB CONNECTED' : paired ? 'MGB PAIRED' : 'WAITING FOR MGB'; button.disabled = true; }
  if (note) note.textContent = connected ? 'CONNECTED THROUGH A TRUSTED MGB SESSION. LIRISQ OPERATIONS ARE UNLOCKED.' : paired && mgbPairingRestoring ? 'PAIRED. RESTORING THE TRUSTED MGB PLAYBACK LINK.' : paired ? 'PAIRED. CONNECTING THE TRUSTED MGB PLAYBACK LINK.' : mgbModelImprovementOptIn.checked ? 'OPT-IN RECORDED. LIRISQ IS LOCKED UNTIL MGB ESTABLISHES A TRUSTED SESSION.' : 'REQUIRED. STREAMER MODEL-IMPROVEMENT OPT-IN AND A TRUSTED MGB SESSION ARE REQUIRED.';
  mgbSetting.classList.toggle('mgb-connected', connected);
  mgbSetting.classList.toggle('mgb-paired-awaiting', !connected && paired);
  mgbCompactToggle.hidden = !paired;
  if (paired) setMgbExpanded(false);
  else mgbSetting.classList.remove('mgb-expanded');
  document.body.dataset.mgbLocked = String(!connected);
  renderMgbPairing();
}
document.addEventListener('click', event => {
  // MGB gates streamer operations only. Viewer sign-in and viewer-facing
  // browsing remain available even while the streamer has not paired MGB.
  if (document.body.dataset.audience === 'viewer' || mgbIsConnected() || event.target.closest('#settings,.top,nav button[data-view="settings"]')) return;
  const interactive = event.target.closest('button,input,select,textarea,a');
  if (!interactive) return;
  event.preventDefault(); event.stopImmediatePropagation(); requireMgb();
}, true);
refreshMgbLockdown();
mgbSetting.classList.remove('mgb-startup');
setInterval(refreshMgbLockdown, 1000);
void refreshMgbBrokerPairing();
setInterval(() => { void refreshMgbBrokerPairing(); }, 30000);
document.querySelector('#loadTestData').addEventListener('click', () => { shows = testShowsFixture(); activeShowId = 'night-drive'; state = clone(shows[0].queue); activeQueuePlaybackId = null; paused = false; persistQueuePlayback(); selectedCalendarDate = nextFriday(); displayMonth = new Date(`${selectedCalendarDate}T00:00:00`); localStorage.setItem('lirisq-active-show', activeShowId); saveShows(); history = []; queueViewportExpanded = false; renderCalendar(); renderStreamerView(); if (document.body.dataset.audience === 'viewer') renderViewerShow(shows, selectedCalendarDate); else renderSelectedShows(shows, selectedCalendarDate); render(); say('TWO-SHOW TEST DATA LOADED'); });
document.querySelector('#wipe').addEventListener('click', () => { if (!confirm('Erase all LirisQ test data in this browser?')) return; localStorage.removeItem('lirisq-test-queue'); localStorage.removeItem('lirisq-shows'); localStorage.removeItem('lirisq-active-show'); localStorage.removeItem('lirisq-overflow-demo-seeded'); localStorage.removeItem('lirisq-overflow-demo-v2'); localStorage.removeItem('lirisq-saved-test-data'); localStorage.removeItem('lirisq-saved-test-data-v3'); localStorage.removeItem('lirisq-test-data-restored-v3'); activeQueuePlaybackId = null; paused = false; persistQueuePlayback(); state = freshState(); shows = []; activeShowId = null; saveShows(); save(); history=[]; renderCalendar(); renderStreamerView(); renderSelectedShows([], selectedCalendarDate); render(); say('TEST DATA WIPED'); });
const testDataSetting = document.querySelector('#loadTestData').closest('.setting');
const testDataDisclosure = document.createElement('details'); testDataDisclosure.className = 'test-data-disclosure'; testDataDisclosure.innerHTML = '<summary>TEST DATA &amp; RESET</summary>';
testDataSetting.replaceWith(testDataDisclosure); testDataDisclosure.append(testDataSetting);
const skinPicker = document.createElement('select');
skinPicker.hidden = true;
skinPicker.setAttribute('aria-hidden', 'true');
skinPicker.innerHTML = '<option value="default">DEFAULT / NO SKIN</option><option value="cassette">CASSETTE / DARK</option><option value="jukebox">JUKEBOX / DARK</option><option value="liner">LINER / DARK</option>';
document.body.append(skinPicker);
const lirisqApplicationVersion = '1.0.2';
document.querySelector('.status').innerHTML = `<span class="dot">●</span> LIRISQ v${lirisqApplicationVersion} &middot; BETA`;
const accountProfile = document.createElement('a'); accountProfile.className = 'account-profile'; accountProfile.href = '/profile';
document.querySelector('.top').append(accountProfile);
const viewerModeButton = document.createElement('button'); viewerModeButton.className = 'btn small viewer-mode-toggle'; accountProfile.before(viewerModeButton);
let viewerPreview = localStorage.getItem('lirisq-viewer-preview') === 'true';
// A fresh browser is always a viewer. Existing configured streamer browsers
// are migrated into the streamer role so an upgrade never hides their console.
function currentAudienceRole() { return usesServerAudience() ? serverAudienceRole : (localStorage.getItem('lirisq-session-role') === 'streamer' || Boolean(localStorage.getItem('lirisq-streamer-profile')) ? 'streamer' : 'viewer'); }
function applyAudienceMode() { const streamer = currentAudienceRole() === 'streamer'; const viewer = !streamer || viewerPreview; document.body.dataset.audience = viewer ? 'viewer' : 'streamer'; viewerModeButton.hidden = !streamer; viewerModeButton.textContent = viewerPreview ? 'RETURN TO STREAMER' : 'VIEWER MODE'; if (viewer) { showPage('shows'); renderViewerShow(shows.filter(show => showOccurs(show, new Date(`${selectedCalendarDate}T00:00:00`))), selectedCalendarDate); } }
function renderAccountProfile() { const role = currentAudienceRole(); const account = usesServerAudience() ? (serverAudienceIdentity?.login || (role === 'streamer' ? 'STREAMER' : 'VIEWER')) : (role === 'streamer' ? (localStorage.getItem('lirisq-streamer-profile') || localStorage.getItem('lirisq-twitch-account') || 'NO PROFILE') : (localStorage.getItem('lirisq-twitch-account') || 'viewer')); accountProfile.href = pageRoutes.profile; accountProfile.innerHTML = `<span class="account-role">${role === 'streamer' ? 'STREAMER PROFILE' : 'VIEWER PROFILE'}</span><span>${account}</span>`; applyAudienceMode(); }
viewerModeButton.addEventListener('click', () => { viewerPreview = !viewerPreview; localStorage.setItem('lirisq-viewer-preview', String(viewerPreview)); applyAudienceMode(); });
const profileView = document.createElement('section'); profileView.id = 'profile'; profileView.className = 'view'; document.querySelector('main.shell').append(profileView);
async function renderProfilePage() { const role = currentAudienceRole(); const hosted = usesServerAudience(); const account = hosted ? (serverAudienceIdentity?.login || '') : (localStorage.getItem('lirisq-twitch-account') || ''); if (role === 'streamer') { const designated = hosted ? (serverAudienceIdentity?.login || 'STREAMER') : (localStorage.getItem('lirisq-streamer-profile') || 'NOT SELECTED'); const profile = `<div class="card profile-page"><div class="eyebrow">STREAMER PROFILE</div><h2>${(account || designated).toUpperCase()}</h2><p class="sub" data-streamer-twitch-status>STREAMER PROFILE: ${designated.toUpperCase()} · CHECKING TWITCH CONNECTION…</p><button class="btn hot" data-open-configuration>OPEN STREAMER CONFIGURATION</button></div>`; profileView.innerHTML = profile; const statusLine = profileView.querySelector('[data-streamer-twitch-status]'); try { const response = await fetch(twitchEndpoint('status'), { cache:'no-store' }); const status = response.ok ? await response.json() : null; if (!status) throw Error('unavailable'); statusLine.textContent = status.authorized ? `STREAMER PROFILE: ${designated.toUpperCase()} · TWITCH CONNECTED` : status.oauthConfigured ? `STREAMER PROFILE: ${designated.toUpperCase()} · TWITCH READY TO CONNECT` : `STREAMER PROFILE: ${designated.toUpperCase()} · TWITCH SETUP REQUIRED`; } catch (_) { statusLine.textContent = `STREAMER PROFILE: ${designated.toUpperCase()} · TWITCH SERVER UNAVAILABLE`; } } else { profileView.innerHTML = `<div class="card profile-page"><div class="eyebrow">VIEWER PROFILE</div><h2>${account ? account.toUpperCase() : 'CONNECT YOUR TWITCH'}</h2><p class="sub">SIGN IN WITH TWITCH TO request songs for a show and keep your per-show request limit.</p><button class="btn hot" data-viewer-twitch-login>${account ? 'CHANGE TWITCH LOGIN' : 'CONNECT TWITCH'}</button><button class="btn" data-streamer-setup>STREAMER SIGN-IN</button></div>`; } }
profileView.addEventListener('click', event => { if (event.target.closest('[data-open-configuration]')) return showPage('settings', true); if (event.target.closest('[data-streamer-setup]')) { if (usesServerAudience()) return twitchTransportConfiguration().kind === 'php' ? window.location.assign(twitchEndpoint('authorize')) : say('SERVER SIGN-IN IS LOADING'); viewerPreview = false; localStorage.setItem('lirisq-viewer-preview', 'false'); localStorage.setItem('lirisq-session-role', 'streamer'); renderAccountProfile(); return showPage('settings', true); } if (!event.target.closest('[data-viewer-twitch-login]')) return; if (usesServerAudience()) return twitchTransportConfiguration().kind === 'php' ? window.location.assign(twitchEndpoint('viewer-authorize')) : say('VIEWER SIGN-IN IS LOADING'); const account = prompt('Twitch account to sign in with for this test build:', localStorage.getItem('lirisq-twitch-account') || ''); if (account === null) return; const clean = account.trim().replace(/^@/, ''); if (!/^[a-zA-Z0-9_]{4,25}$/.test(clean)) return say('ENTER A VALID TWITCH USERNAME'); localStorage.setItem('lirisq-twitch-account', clean); localStorage.setItem('lirisq-session-role', 'viewer'); renderAccountProfile(); renderProfilePage(); say(`VIEWER SIGNED IN AS ${clean.toUpperCase()} (TEST)`); });
const renderProfilePageBase = renderProfilePage;
renderProfilePage = async function () {
  await renderProfilePageBase();
  if (currentAudienceRole() !== 'viewer' || !usesServerAudience() || !serverAudienceIdentity?.id) return;
  const card = profileView.querySelector('.profile-page'); if (!card) return;
  const section = document.createElement('section'); section.className = 'optional-addons viewer-profile-artists'; section.innerHTML = '<h3>ARTISTS I REPRESENT</h3><p class="queue-note">These artists are linked to your Twitch profile. Your most recently used artist becomes the default for your next show request.</p><div class="fields"><select data-profile-artist><option value="">ADD ARTIST…</option></select><input data-profile-artist-name maxlength="160" placeholder="ARTIST NAME"><button class="btn" data-add-profile-artist>ADD ARTIST</button></div><div data-profile-artists></div><h3>LAST 25 SUBMITTED / PLAYED</h3><ol class="queue-list" data-profile-activity></ol><details class="test-data-disclosure"><summary>DELETE VIEWER PROFILE</summary><p class="queue-note">This permanently removes your linked artists and your last 25 submitted/played songs from LirisQ.</p><button class="btn hot" data-delete-viewer-profile>DELETE MY USER PROFILE</button></details>'; card.append(section);
  const endpoint = twitchEndpoint('viewer-profile'); const load = async () => { const response=await fetch(endpoint,{cache:'no-store'}); if(!response.ok)throw Error('Viewer profile is unavailable'); return response.json(); }; const write=async body=>{const response=await fetch(endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});const result=await response.json();if(!response.ok)throw Error(result.error||'Profile could not be saved');return result;};
  try { const profile=await load(); window.LIRISQ_VIEWER_ARTISTS=profile.artists; const select=section.querySelector('[data-profile-artist]'); profile.artists.forEach(artist=>select.append(new Option(artist,artist))); const artists=section.querySelector('[data-profile-artists]'); artists.replaceChildren(...profile.artists.map(artist=>{const row=document.createElement('div');row.className='setting';row.innerHTML=`<span>${escaped(artist)}</span><button class="btn small" data-remove-profile-artist="${escaped(artist)}">REMOVE</button>`;return row;})); const activity=section.querySelector('[data-profile-activity]');activity.replaceChildren(...(profile.activity.length?profile.activity.map(item=>{const row=document.createElement('li');row.className='row';row.textContent=`${item.activity.toUpperCase()} · ${item.song} — ${item.artist}`;return row;}):[Object.assign(document.createElement('li'),{textContent:'NO SONG ACTIVITY YET.'})])); } catch(error){section.querySelector('[data-profile-artists]').textContent=String(error.message||error);}
  section.addEventListener('click',async event=>{const remove=event.target.closest('[data-remove-profile-artist]');if(remove){await write({operation:'remove-artist',artist:remove.dataset.removeProfileArtist});return renderProfilePage();}if(event.target.closest('[data-add-profile-artist]')){const artist=section.querySelector('[data-profile-artist-name]').value.trim();if(!artist)return say('ENTER AN ARTIST NAME');await write({operation:'add-artist',artist});return renderProfilePage();}if(event.target.closest('[data-delete-viewer-profile]')){if(!confirm('Are you sure? This will wipe your LirisQ user profile.'))return;await write({operation:'delete-profile'});serverAudienceIdentity=null;renderAccountProfile();showPage('profile',true);}});
};
accountProfile.addEventListener('click', event => { event.preventDefault(); showPage('profile', true); });
renderAccountProfile();
skinPicker.querySelector('option[value="liner"]')?.remove();
if (localStorage.getItem('lirisq-editable-skin-custom-basic') && !skinPicker.querySelector('option[value="custom-basic"]')) skinPicker.insertAdjacentHTML('beforeend', '<option value="custom-basic">MY BASIC SKIN PACK</option>');
if (!skinPicker.querySelector('option[value="record"]')) skinPicker.insertAdjacentHTML('beforeend', '<option value="record">RECORD / ART DECO</option>');
if (!skinPicker.querySelector('option[value="vhs"]')) skinPicker.insertAdjacentHTML('beforeend', '<option value="vhs">VHS / CRT NIGHT</option>');
const legacySkins = { 'CASSETTE / DARK': 'cassette', 'JUKEBOX / DARK': 'jukebox', 'LINER / DARK': 'default' };
const storedSkin = localStorage.getItem('lirisq-test-skin') || 'cassette';
const selectedSkin = legacySkins[storedSkin] || (['default', 'cassette', 'jukebox', 'record', 'vhs', 'custom-basic'].includes(storedSkin) ? storedSkin : 'cassette');
document.body.dataset.skin = selectedSkin;
skinPicker.value = selectedSkin;
localStorage.setItem('lirisq-test-skin', selectedSkin);
skinPicker.addEventListener('change', () => {
  applyCompleteSkin(skinPicker.value);
  say(`${skinPicker.options[skinPicker.selectedIndex].text} SKIN APPLIED`);
});
const skinPackSetting = document.createElement('div');
skinPackSetting.className = 'optional-addons skin-pack-setting';
skinPackSetting.innerHTML = `<div class="setting"><div><h3>${t('skins.manager')}</h3><p>INSTALL OR UNINSTALL COMPLETE SKIN PACKS. SELECTED SKINS ARE HIGHLIGHTED BELOW.</p></div><button id="openSkinMaker" class="btn" type="button">${t('skins.openMaker')}</button></div><h3>${t('skins.packs')}</h3><div id="skinPackCards" class="skin-management-grid"></div><h3>${t('skins.skins')}</h3><div id="skinCards" class="skin-management-grid"></div>`;
skinPackSetting.querySelector('#openSkinMaker').addEventListener('click', () => showPage('skinmaker', true));
document.querySelector('#settings .settings').append(skinPackSetting);
const skinPackThumbnailStyle = document.createElement('style');
skinPackThumbnailStyle.textContent = '.skin-pack-card,.skin-card{aspect-ratio:auto;min-height:0}.skin-pack-thumbnail-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:5px;margin:8px 0}.skin-pack-thumbnail,.skin-card-thumbnail{display:block;width:100%;aspect-ratio:3/2;object-fit:cover;object-position:center;border:1px solid var(--line);background:var(--panel)}.skin-pack-thumbnail[hidden],.skin-card-thumbnail[hidden]{display:none}.skin-card-thumbnail{margin:8px 0}';
document.head.append(skinPackThumbnailStyle);
const installedPackStorageKey = 'lirisq-installed-skin-packs';
let installedSkinPacks = JSON.parse(localStorage.getItem(installedPackStorageKey) || 'null') || ['lirisq-original-pack-01'];
function syncInstalledSkinChoices() {
  const available = new Set(Object.values(window.LIRISQ_SKIN_PACKS || {}).filter(pack => installedSkinPacks.includes(pack.id)).flatMap(pack => pack.skins));
  for (const key of ['cassette', 'record', 'jukebox', 'vhs']) skinPicker.querySelector(`option[value="${key}"]`)?.remove();
  const labels = { cassette: 'CASSETTE / DARK', record: 'RECORD / ART DECO', jukebox: 'JUKEBOX / GLOW', vhs: 'VHS / CRT NIGHT' };
  for (const key of ['cassette', 'record', 'jukebox', 'vhs']) if (available.has(key)) skinPicker.insertAdjacentHTML('beforeend', `<option value="${key}">${labels[key]}</option>`);
  if (![...skinPicker.options].some(option => option.value === document.body.dataset.skin)) {
    document.body.dataset.skin = 'default'; localStorage.setItem('lirisq-test-skin', 'default'); skinPicker.value = 'default';
  }
}
function renderSkinPacks() {
  syncInstalledSkinChoices();
  const packCards=document.querySelector('#skinPackCards'), skinCards=document.querySelector('#skinCards');packCards.replaceChildren();skinCards.replaceChildren();
  const labels={cassette:'CASSETTE / DARK',record:'RECORD / ART DECO',jukebox:'JUKEBOX / GLOW',vhs:'VHS / CRT NIGHT'};
  for(const pack of Object.values(window.LIRISQ_SKIN_PACKS||{})){
    const installed=installedSkinPacks.includes(pack.id);const card=document.createElement('article');card.className='management-card skin-pack-card'+(installed?'':' uninstalled');
    card.innerHTML=`<h3>${pack.name}</h3><p>${pack.publisher} · ${t('skins.count',{count:pack.skins.length})} · ${installed?`${t('skins.installed')} v${pack.version}`:t('skins.notInstalled')}</p>`;
    const previews = pack.skins.map(id => ({ id, skin: window.LIRISQ_SKIN_PACKAGES?.[id] })).map(({ id, skin }) => ({ id, source: skin?.previews?.player || skin?.assets?.playerBackground })).filter(item => item.source);
    if (previews.length) { const grid = document.createElement('div'); grid.className = 'skin-pack-thumbnail-grid'; for (const preview of previews) { const image = document.createElement('img'); image.className = 'skin-pack-thumbnail'; image.src = preview.source; image.alt = `${labels[preview.id] || preview.id} preview`; image.addEventListener('error', () => { image.hidden = true; }); grid.append(image); } card.querySelector('p').after(grid); }
    else if (pack.thumbnail) { const image = document.createElement('img'); image.className = 'skin-pack-thumbnail'; image.src = pack.thumbnail; image.alt = `${pack.name} thumbnail`; image.addEventListener('error', () => { image.hidden = true; }); card.querySelector('p').after(image); }
    const actions=document.createElement('div');actions.className='management-actions';const install=document.createElement('button');install.className='btn hot';install.textContent=installed?t('skins.reinstall'):t('skins.install');install.addEventListener('click',()=>{installedSkinPacks=[...new Set([...installedSkinPacks,pack.id])];localStorage.setItem(installedPackStorageKey,JSON.stringify(installedSkinPacks));renderSkinPacks();});const remove=document.createElement('button');remove.className='btn uninstall';remove.textContent=t('skins.uninstall');remove.disabled=!installed;remove.addEventListener('click',()=>{if(!window.confirm(`${t('skins.uninstall')} ${pack.name}?`))return;installedSkinPacks=installedSkinPacks.filter(id=>id!==pack.id);localStorage.setItem(installedPackStorageKey,JSON.stringify(installedSkinPacks));if(pack.skins.includes(document.body.dataset.skin))applyCompleteSkin('default');renderSkinPacks();});actions.append(install,remove);card.append(actions);packCards.append(card);
    for(const skin of pack.skins){const selected=document.body.dataset.skin===skin;const skinCard=document.createElement('article');skinCard.className='management-card skin-card'+(selected?' selected':'')+(installed?'':' uninstalled');skinCard.innerHTML=`<h3>${labels[skin]||skin}</h3><p>${selected?`${t('skins.selected')} ${t('skins.skins').slice(0,-1)}`:installed?`${t('skins.installed')} · ${t('skins.ready')}`:t('skins.installPack')}</p>`;const preview=window.LIRISQ_SKIN_PACKAGES?.[skin]?.previews?.player||window.LIRISQ_SKIN_PACKAGES?.[skin]?.assets?.playerBackground;if(preview){const image=document.createElement('img');image.className='skin-card-thumbnail';image.src=preview;image.alt=`${labels[skin]||skin} preview`;image.addEventListener('error',()=>{image.hidden=true;});skinCard.querySelector('p').after(image);}const actions=document.createElement('div');actions.className='management-actions';const select=document.createElement('button');select.className='btn hot';select.textContent=selected?t('skins.selected'):t('skins.select');select.disabled=!installed||selected;select.addEventListener('click',()=>{applyCompleteSkin(skin);renderSkinPacks();});actions.append(select);skinCard.append(actions);skinCards.append(skinCard);}
  }
}
renderSkinPacks();
const defaultSkinLayout = { name: 'DEFAULT / NO SKIN', image: '', queueImage: '', theme: { ink:'#e9edf9', muted:'#8992aa', panel:'#121724', line:'#2a3348', accent:'#ff3e80' }, positions: { show: { x: 50, y: 16 }, song: { x: 50, y: 30 }, artist: { x: 50, y: 43 }, leftReel: { x: 28, y: 45 }, rightReel: { x: 72, y: 45 }, vipTitle: { x: 18, y: 22 }, standardTitle: { x: 18, y: 55 }, manualEntry: { x: 50, y: 90 } }, typography: {} };
const cassetteFallback = { name: 'CASSETTE / DARK', image: 'skins/cassette/assets/cassette-skin.png', queueImage: 'skins/cassette/assets/cassette-liner.png', positions: clone(defaultSkinLayout.positions), typography: {} };
let editableSkin = JSON.parse(localStorage.getItem('lirisq-editable-skin') || 'null') || clone(defaultSkinLayout);
let skinMakerMode = 'player';
let activeSkinEditorKey = '';
const skinMaker = document.querySelector('#skinmaker');
const skinWorkspace = document.createElement('div'); skinWorkspace.className = 'skin-workspace';
while (skinMaker.firstChild) skinWorkspace.append(skinMaker.firstChild);
const skinSelection = document.createElement('div'); skinSelection.className = 'card skin-selection';
skinSelection.innerHTML = `<div class="eyebrow">SKIN MAKER</div><h2>SKIN WORKSPACE</h2><p class="sub">CHOOSE WHETHER TO EDIT AN EXISTING SKIN PACKAGE OR START A SIMPLE CUSTOM PACKAGE.</p><label class="skin-workflow-field">WORKSPACE<select id="skinMakerWorkflow" aria-label="Skin Maker workspace"><option value="editor" selected>EDITOR</option><option value="ez">EZ CREATOR</option></select></label><div id="skinEditorPanel"><h3>SELECT A SKIN TO EDIT</h3><p class="sub">THE EDITOR IS LOCKED UNTIL YOU CHOOSE A SKIN. ITS ARTWORK, QUEUE BACKDROP, AND TYPE TREATMENT WILL THEN LOAD.</p><select id="skinEditorPicker" aria-label="Skin to edit"><option value="" selected>DEFAULT / NO SKIN</option><option value="cassette">CASSETTE / DARK</option><option value="record">RECORD / ART DECO</option><option value="jukebox">JUKEBOX / GLOW</option><option value="vhs">VHS / CRT NIGHT</option></select><p class="skin-selection-status" id="skinSelectionStatus">SELECT A SKIN TO UNLOCK THE EDITOR.</p></div><div id="ezCreatorPanel" hidden><h3>EZ CREATOR — BASIC SKIN PACKAGE</h3><p class="sub">A SIMPLE STEP-BY-STEP CREATOR FOR A PLAYER BACKGROUND, QUEUE BACKGROUND, TYPE, COLORS, AND PLACEMENT.</p><button class="btn hot" id="openEzCreator">START EZ CREATOR</button></div>`;
skinMaker.append(skinSelection, skinWorkspace); skinMaker.classList.add('skin-maker-locked');
const basicSkinGuide = document.createElement('div');
basicSkinGuide.className = 'card basic-skin-guide';
basicSkinGuide.hidden = true;
basicSkinGuide.innerHTML = `<div class="eyebrow">EZ CREATOR — EASY 1–2–3</div><h2>MAKE A SKIN WITHOUT CODE</h2><ol><li><strong>NAME IT.</strong> Enter the skin name below.</li><li><strong>PLAYER.</strong> Stay on Player, upload its background, choose a Google Font and color, then drag Show, Song, and Artist into place.</li><li><strong>LIVE QUEUE.</strong> Switch to Queue, upload its background, choose its Google Font and color, then drag VIP, Standard, and Manual Entry into place.</li></ol><div class="premium-motion-form"><div><h3>PREMIUM MOTION PACK</h3><p class="sub">OPTIONAL: CHOOSE A PACKAGE-OWNED MOTION PRESET. THIS IS STORED WITH THE SKIN, SEPARATE FROM ITS STORE LISTING.</p></div><label><input id="premiumMotionEnabled" type="checkbox"> INCLUDE MOTION WITH THIS SKIN</label><label>MOTION PRESET<select id="premiumMotionPreset"><option value="none">NO MOTION</option><option value="cassette-reels">CASSETTE REELS</option><option value="record-spin">RECORD SPIN</option><option value="jukebox-lights">JUKEBOX LIGHT PULSE</option><option value="vhs-tracking">VHS TRACKING</option></select></label></div><div class="premium-skin-form"><div><h3>MGB STORE INCLUSION</h3><p class="sub">OPTIONAL: PREPARE LISTING METADATA FOR THE SEPARATE PRIVATE MGBSTORE PROJECT. THIS TEST BUILD DOES NOT SHIP OR DISTRIBUTE THE STORE.</p></div><label><input id="premiumSkinEnabled" type="checkbox"> INCLUDE IN STORE EXPORT</label><label>STORE TITLE<input id="premiumSkinTitle" placeholder="MIDNIGHT CASSETTE"></label><label>SHORT DESCRIPTION<input id="premiumSkinDescription" placeholder="A CUSTOM PLAYER AND LIVE-QUEUE SKIN"></label><label>PRICE (USD)<input id="premiumSkinPrice" inputmode="decimal" placeholder="4.99"></label><button id="savePremiumSkin" class="btn hot" type="button">SAVE STORE METADATA</button><button id="exportStoreManifest" class="btn" type="button">EXPORT STORE MANIFEST</button></div><p class="sub">YOUR BACKGROUNDS, TYPE, COLORS, POSITIONS, AND OPTIONAL MOTION ARE SAVED AS A BROWSER-LOCAL CUSTOM SKIN PACKAGE.</p>`;
skinWorkspace.prepend(basicSkinGuide);
const skinNameInput = document.querySelector('#skinName');
const skinNameLabel = document.createElement('label'); skinNameLabel.className = 'skin-name-field'; skinNameLabel.textContent = 'SKIN NAME';
skinNameInput.before(skinNameLabel); skinNameLabel.append(skinNameInput);
let typographyKey = 'song';
const typographyControls = document.createElement('div');
typographyControls.className = 'skin-typography fields';
typographyControls.innerHTML = `<label>TEXT<select id="typeTarget"><option value="show">SHOW TITLE</option><option value="song" selected>SONG TITLE</option><option value="artist">ARTIST</option></select></label><label>GOOGLE FONT<select id="typeFont"><option value="'Bebas Neue', sans-serif">BEBAS NEUE</option><option value="'Space Grotesk', sans-serif">SPACE GROTESK</option><option value="'Caveat', cursive">CAVEAT</option><option value="'DM Mono', monospace">DM MONO</option><option value="'Limelight', serif">LIMELIGHT</option></select></label><label class="type-color-control">FONT COLOR<span><input id="typeColor" type="color" value="#ffffff" aria-label="Font color picker"><input id="typeColorHex" value="#FFFFFF" maxlength="7" aria-label="Font color hex value"></span></label><label>SIZE <output id="typeSizeValue">32 PX</output><input id="typeSize" type="range" min="9" max="72" value="32"></label>`;
const typographyStyle = document.createElement('style');
typographyStyle.textContent = `.skin-typography .type-color-control span{display:flex;align-items:center;gap:6px}.skin-typography input[type="color"]{width:46px;min-width:46px;height:38px;padding:3px;cursor:pointer}.skin-typography #typeColorHex{width:92px;min-width:92px;text-transform:uppercase;font:600 12px 'DM Mono',monospace}`;
document.head.append(typographyStyle);
const premiumCreatorStyle = document.createElement('style');
premiumCreatorStyle.textContent = `.premium-skin-form,.premium-motion-form{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:18px 0;padding:15px;border:1px solid var(--line);background:color-mix(in srgb,var(--panel) 75%,transparent)}.premium-skin-form>div,.premium-motion-form>div{grid-column:1/-1}.premium-skin-form h3,.premium-motion-form h3{margin:0}.premium-skin-form label,.premium-motion-form label{display:grid;gap:5px;font:600 11px 'DM Mono',monospace;color:var(--muted)}.premium-skin-form label:has(input[type="checkbox"]),.premium-motion-form label:has(input[type="checkbox"]){display:flex;align-items:center;gap:8px;grid-column:1/-1;color:var(--ink)}.premium-skin-form input:not([type="checkbox"]),.premium-motion-form select{width:100%;padding:8px;background:#0a0e16;color:var(--ink);border:1px solid var(--line)}.premium-skin-form button{justify-self:start}@media(max-width:620px){.premium-skin-form,.premium-motion-form{grid-template-columns:1fr}}`;
document.head.append(premiumCreatorStyle);
const jukeboxSurfaceStyle = document.createElement('style');
jukeboxSurfaceStyle.textContent = `body[data-skin="jukebox"] .cassette-label{inset:0!important;left:0!important;right:0!important;top:0!important;height:100%!important;padding:0!important;background:none!important;border:0!important;border-radius:0!important}body[data-skin="jukebox"] .cassette-label .show-name,body[data-skin="jukebox"] .cassette-label .song-name,body[data-skin="jukebox"] .cassette-label .artist-name{position:absolute!important;transform:translate(-50%,-50%)!important}`;
document.head.append(jukeboxSurfaceStyle);
skinWorkspace.querySelector('.fields').after(typographyControls);
const editorPresets = window.LIRISQ_SKIN_PACKAGES || {
  cassette: clone(cassetteFallback),
  record: { name: 'RECORD / ART DECO', image: 'skins/record/assets/record-skin.png', queueImage: 'skins/record/assets/record-liner-notes.png', positions: { show: { x: 50, y: 40 }, song: { x: 50, y: 49 }, artist: { x: 50, y: 58 }, leftReel: { x: 28, y: 45 }, rightReel: { x: 72, y: 45 }, vipTitle: { x: 18, y: 22 }, standardTitle: { x: 18, y: 55 }, manualEntry: { x: 50, y: 90 } } },
  jukebox: { name: 'JUKEBOX / GLOW', image: 'skins/jukebox/assets/jukebox-player.png', queueImage: 'skins/jukebox/assets/jukebox-queue.png', positions: { show: { x: 50, y: 40 }, song: { x: 50, y: 49 }, artist: { x: 50, y: 58 }, leftReel: { x: 28, y: 45 }, rightReel: { x: 72, y: 45 }, vipTitle: { x: 18, y: 22 }, standardTitle: { x: 18, y: 55 }, manualEntry: { x: 50, y: 90 } } }
};
editorPresets['custom-basic'] = { ...clone(defaultSkinLayout), name: 'MY BASIC SKIN PACK', assets: { playerBackground: '', queueBackground: '' }, editor: { ink: '#ffffff', labelBackground: '#101724bb', grid: '#61e5f566', outline: '#61e5f5' } };
let liveSkin = selectedSkin === 'default' ? clone(defaultSkinLayout) : packageLayout(selectedSkin);
liveSkin.positions ||= clone(editorPresets[selectedSkin === 'default' ? 'cassette' : selectedSkin].positions);
liveSkin.positions.manualEntry ||= { x: 50, y: 90 };
liveSkin.typography ||= {};
function packageLayout(key) {
  const base = clone(editorPresets[key]);
  if (base.defaults?.positions) base.positions = clone(base.defaults.positions);
  const packageDefaults = JSON.parse(localStorage.getItem(`lirisq-package-defaults-${key}`) || 'null');
  if (packageDefaults?.schema === 'lirisq-skin-defaults/v1' && packageDefaults.packageId === key) {
    base.positions = { ...base.positions, ...packageDefaults.positions };
    base.defaults ||= {}; base.defaults.positions = clone(base.positions);
    base.typography = { ...base.typography, ...packageDefaults.typography };
  }
  const saved = JSON.parse(localStorage.getItem(`lirisq-editable-skin-${key}`) || 'null');
  // Older browser drafts were not package-bound. Ignore them in the live renderer.
  if (!saved || saved.packageId !== key) return base;
  return { ...base, ...saved, assets: { ...base.assets, ...saved.assets }, positions: { ...base.positions, ...saved.positions }, typography: { ...base.typography, ...saved.typography } };
}
function skinDefaultsPayload(key, layout) { return { schema: 'lirisq-skin-defaults/v1', packageId: key, positions: clone(layout.positions), typography: clone(layout.typography || {}) }; }
function persistPackageDefaults(key, layout) {
  if (!['cassette', 'record', 'jukebox', 'vhs'].includes(key)) return;
  const payload = skinDefaultsPayload(key, layout);
  localStorage.setItem(`lirisq-package-defaults-${key}`, JSON.stringify(payload));
  editorPresets[key].positions = clone(payload.positions); editorPresets[key].defaults ||= {}; editorPresets[key].defaults.positions = clone(payload.positions);
  editorPresets[key].typography = { ...editorPresets[key].typography, ...payload.typography };
  if (window.location.protocol !== 'http:' && window.location.protocol !== 'https:') return;
  fetch(`/api/skin-defaults/${key}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload) }).catch(() => say('PACK DEFAULTS ARE SAVED LOCALLY — SERVER WRITE UNAVAILABLE'));
}
async function loadPackageDefaultFiles() {
  if (window.location.protocol !== 'http:' && window.location.protocol !== 'https:') return;
  await Promise.all(['cassette', 'record', 'jukebox', 'vhs'].map(async key => {
    try {
      const response = await fetch(`skins/${key}/defaults.json`, { cache: 'no-store' }); const payload = await response.json();
      if (payload?.schema !== 'lirisq-skin-defaults/v1' || payload.packageId !== key) return;
      localStorage.setItem(`lirisq-package-defaults-${key}`, JSON.stringify(payload));
      editorPresets[key].positions = { ...editorPresets[key].positions, ...payload.positions }; editorPresets[key].defaults ||= {}; editorPresets[key].defaults.positions = clone(editorPresets[key].positions);
      editorPresets[key].typography = { ...editorPresets[key].typography, ...payload.typography };
    } catch { /* A pack without a defaults sidecar keeps its package.js defaults. */ }
  }));
  applyCompleteSkin(document.body.dataset.skin);
}
function skinAsset(key, area) {
  const skin = key === activeSkinEditorKey ? editableSkin : (editorPresets[key] || editorPresets.cassette);
  return area === 'queue' ? skin.assets?.queueBackground : (skin.assets?.playerStage || skin.assets?.playerBackground);
}
function applyCompleteSkin(key) {
  if (key === 'default') { liveSkin = clone(defaultSkinLayout); document.body.dataset.skin = 'default'; localStorage.setItem('lirisq-test-skin', 'default'); applySkinLayout(); return; }
  liveSkin = packageLayout(key);
  document.body.dataset.skin = key; skinPicker.value = key; localStorage.setItem('lirisq-test-skin', key); applySkinLayout();
}
function syncPremiumSkinControls() {
  const store = editableSkin.store || {}; const enabled = activeSkinEditorKey === 'custom-basic' && !!store.premium;
  const motion = editableSkin.premiumMotion || {};
  document.querySelector('#premiumSkinEnabled').checked = enabled;
  document.querySelector('#premiumSkinTitle').value = store.title || editableSkin.name || '';
  document.querySelector('#premiumSkinDescription').value = store.description || '';
  document.querySelector('#premiumSkinPrice').value = store.price ? String(store.price).replace(/[^0-9.]/g, '') : '';
  document.querySelector('#premiumMotionEnabled').checked = activeSkinEditorKey === 'custom-basic' && !!motion.enabled;
  document.querySelector('#premiumMotionPreset').value = motion.preset || 'none';
}
function capturePremiumMotionMetadata() {
  if (activeSkinEditorKey !== 'custom-basic') return;
  const enabled = document.querySelector('#premiumMotionEnabled').checked;
  const preset = document.querySelector('#premiumMotionPreset').value;
  editableSkin.premiumMotion = { enabled: enabled && preset !== 'none', preset: enabled ? preset : 'none' };
}
function capturePremiumSkinMetadata(strict = false) {
  if (activeSkinEditorKey !== 'custom-basic') return true;
  const enabled = document.querySelector('#premiumSkinEnabled').checked;
  if (!enabled) { delete editableSkin.store; return true; }
  const title = document.querySelector('#premiumSkinTitle').value.trim() || editableSkin.name.trim();
  const description = document.querySelector('#premiumSkinDescription').value.trim();
  const rawPrice = document.querySelector('#premiumSkinPrice').value.trim(); const numericPrice = Number(rawPrice);
  if (!title || !description || !Number.isFinite(numericPrice) || numericPrice <= 0) { if (strict) say('ADD A TITLE, DESCRIPTION, AND VALID PRICE FOR THE PREMIUM LISTING'); return false; }
  editableSkin.store = { premium:true, title, description, price:`$${numericPrice.toFixed(2)}`, version:editableSkin.store?.version || '0.1.0' };
  return true;
}
function selectSkinForEditing(key) {
  activeSkinEditorKey = key;
  basicSkinGuide.hidden = key !== 'custom-basic';
  if (!key) { applyEditorStyle(); skinMaker.classList.add('skin-maker-locked'); delete skinMaker.dataset.editorSkin; document.querySelector('#skinSelectionStatus').textContent = 'DEFAULT / NO SKIN — SELECT A SKIN TO UNLOCK THE EDITOR.'; return; }
  // The editor and live view must begin from the identical package-bound layout.
  editableSkin = packageLayout(key);
  editableSkin.positions.manualEntry ||= clone(editorPresets[key].positions.manualEntry); editableSkin.typography ||= {};
  document.querySelector('#skinName').value = editableSkin.name || 'MY BASIC SKIN PACK';
  syncPremiumSkinControls();
  applyEditorStyle(key);
  skinMaker.classList.remove('skin-maker-locked'); skinMaker.dataset.editorSkin = key; document.querySelector('#skinSelectionStatus').textContent = key === 'custom-basic' ? 'EASY 1–2–3 READY — START WITH YOUR SKIN NAME AND PLAYER BACKGROUND.' : `${key.toUpperCase()} FILES LOADED — ARTWORK, QUEUE BACKDROP, AND TYPE STYLE READY.`;
  setSkinMakerMode('player');
}
function applyEditorStyle(key) {
  const style = editorPresets[key]?.editor || {};
  const values = { ink: style.ink || '#27221e', labelBackground: style.labelBackground || 'transparent', grid: style.grid || '#64e8f525', outline: style.outline || 'var(--hot)' };
  Object.entries(values).forEach(([name, value]) => skinMaker.style.setProperty(`--skin-editor-${name}`, value));
}
function setSkinMakerWorkflow(mode) {
  const ezCreator = mode === 'ez';
  document.querySelector('#skinEditorPanel').hidden = ezCreator;
  document.querySelector('#ezCreatorPanel').hidden = !ezCreator;
  if (ezCreator) {
    selectSkinForEditing('custom-basic');
    document.querySelector('#skinSelectionStatus').textContent = 'EZ CREATOR READY — FOLLOW THE THREE STEPS BELOW.';
  } else {
    document.querySelector('#skinEditorPicker').value = '';
    selectSkinForEditing('');
  }
}
document.querySelector('#skinMakerWorkflow').addEventListener('change', event => setSkinMakerWorkflow(event.target.value));
document.querySelector('#openEzCreator').addEventListener('click', () => setSkinMakerWorkflow('ez'));
document.querySelector('#skinEditorPicker').addEventListener('change', event => selectSkinForEditing(event.target.value));
if (editableSkin.positions.reels) { const legacy = editableSkin.positions.reels; editableSkin.positions.leftReel = { x: legacy.x - 22, y: legacy.y }; editableSkin.positions.rightReel = { x: legacy.x + 22, y: legacy.y }; delete editableSkin.positions.reels; }
editableSkin.queueImage ||= 'skins/cassette/assets/cassette-liner.png'; editableSkin.positions.vipTitle ||= { x: 18, y: 22 }; editableSkin.positions.standardTitle ||= { x: 18, y: 55 }; editableSkin.positions.manualEntry ||= { x: 50, y: 90 };
editableSkin.typography ||= {};
function setLayerPosition(element, position) { element.style.left = `${position.x}%`; element.style.top = `${position.y}%`; }
function applyTypography(element, key, layout) { if (!element) return; const type = layout.typography?.[key]; element.style.fontFamily = type?.font || ''; element.style.fontSize = type?.size ? `${type.size}px` : ''; element.style.color = type?.color || ''; element.style.textShadow = type?.shadow || ''; }
function ensureGoogleFont(font) { const family = String(font || '').match(/['"]?([^,'"]+)/)?.[1]?.trim(); if (!family || family === 'Arial') return; const id = `lirisq-google-font-${family.replace(/\W+/g, '-').toLowerCase()}`; if (document.getElementById(id)) return; const link = document.createElement('link'); link.id = id; link.rel = 'stylesheet'; link.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(family).replace(/%20/g, '+')}:wght@400;500;600;700&display=swap`; document.head.append(link); }
function ensurePackageStylesheet(skin) { const stylesheet = skin?.fonts?.stylesheet; if (!stylesheet) return; const id = `lirisq-skin-styles-${stylesheet.replace(/[^a-z0-9]/gi, '-')}`; if (document.getElementById(id)) return; const link = document.createElement('link'); link.id = id; link.rel = 'stylesheet'; link.href = stylesheet; document.head.append(link); }
function applySkinLayout() {
  const layout = liveSkin;
  const activeSkinKey = document.body.dataset.skin;
  const packageSkin = editorPresets[activeSkinKey];
  ensurePackageStylesheet(packageSkin);
  Object.values(layout.typography || {}).forEach(type => ensureGoogleFont(type.font));
  Object.entries(layout.theme || {}).forEach(([name, value]) => document.body.style.setProperty(`--${name}`, value));
  document.body.style.setProperty('--card-background', layout.theme?.cardBackground || 'linear-gradient(135deg,var(--panel),#0f1420)');
  document.body.removeAttribute('data-skins-ready');
  const playerImage = document.querySelector('.cassette-art');
  let tonearm = document.querySelector('.record-tonearm');
  if (!tonearm) { tonearm = document.createElement('img'); tonearm.className = 'record-tonearm'; tonearm.alt = ''; tonearm.setAttribute('aria-hidden', 'true'); playerImage.after(tonearm); }
  const canvasImage = document.querySelector('#skinCanvasImage');
  let pendingAssets = 2;
  const revealSkin = () => { pendingAssets -= 1; if (pendingAssets <= 0) { document.body.setAttribute('data-skins-ready', 'true'); document.body.classList.remove('boot'); } };
  playerImage.addEventListener('load', revealSkin, { once: true });
  playerImage.addEventListener('error', revealSkin, { once: true });
  const isRecord = activeSkinKey === 'record';
  const isJukebox = activeSkinKey === 'jukebox';
  const isVhs = activeSkinKey === 'vhs';
  // A package owns its assets. A saved layout may replace that package's artwork.
  const playerSource = layout.assets?.playerBackground || packageSkin?.assets?.playerBackground || '';
  const overlaySource = layout.assets?.playerOverlay || packageSkin?.assets?.playerOverlay || '';
  const stageSource = layout.assets?.playerStage || packageSkin?.assets?.playerStage || '';
  const playerStage = document.querySelector('.cassette-stage');
  playerStage.style.backgroundImage = stageSource ? `url("${stageSource}")` : '';
  playerStage.style.aspectRatio = layout.player?.aspectRatio || packageSkin?.player?.aspectRatio || '3 / 2';
  playerImage.hidden = !playerSource;
  tonearm.hidden = !overlaySource;
  if (overlaySource) tonearm.src = overlaySource;
  if (playerSource) { playerImage.src = playerSource; if (playerImage.complete) revealSkin(); }
  else { playerImage.removeAttribute('src'); revealSkin(); }
  ['show', 'song', 'artist', 'leftReel', 'rightReel'].forEach(key => {
    const position = layout.positions[key];
    if (!key.includes('Reel')) { const target = document.querySelector(`.cassette-label .${key === 'show' ? 'show-name' : key === 'song' ? 'song-name' : 'artist-name'}`); target.style.left = `${position.x}%`; target.style.right = 'auto'; target.style.top = `${position.y}%`; target.style.transform = 'translate(-50%, -50%)'; applyTypography(target, key, layout); }
  });
  const left = document.querySelector('.reel.left'), right = document.querySelector('.reel.right');
  left.style.left = `${layout.positions.leftReel.x - 6.5}%`; left.style.right = 'auto'; left.style.top = `${layout.positions.leftReel.y - 6.5}%`;
  right.style.left = `${layout.positions.rightReel.x - 6.5}%`; right.style.right = 'auto'; right.style.top = `${layout.positions.rightReel.y - 6.5}%`;
  const manualEntry = document.querySelector('#queue .cassette-liner > .card');
  if (manualEntry) manualEntry.style.transform = `translate(${layout.positions.manualEntry.x - 50}%, ${(layout.positions.manualEntry.y - 90) * 4}px)`;
  const shiftQueueX = (elements, position, baselineX) => elements.forEach(element => { if (element) element.style.transform = `translateX(${position.x - baselineX}%)`; });
  shiftQueueX([document.querySelector('#vipHeader'), document.querySelector('#vipList')], layout.positions.vipTitle, 18);
  shiftQueueX([document.querySelector('#standardHeader'), document.querySelector('#standardList')], layout.positions.standardTitle, 18);
  applyTypography(document.querySelector('#vipHeader h2'), 'vipTitle', layout);
  applyTypography(document.querySelector('#standardHeader h2'), 'standardTitle', layout);
  applyTypography(manualEntry?.querySelector('.eyebrow'), 'manualEntry', layout);
  const queueSurface = document.querySelector('.cassette-liner');
  const queueSource = layout.assets?.queueBackground || packageSkin?.assets?.queueBackground || '';
  if (queueSource) { const queueImage = new Image(); queueImage.onload = revealSkin; queueImage.onerror = revealSkin; queueImage.src = queueSource; }
  else revealSkin();
  if (activeSkinKey === 'cassette') {
    queueSurface.style.backgroundImage = `url("${queueSource}")`;
    queueSurface.style.backgroundPosition = 'center, center';
    queueSurface.style.backgroundRepeat = 'no-repeat, no-repeat';
    queueSurface.style.backgroundSize = '100% 100%, 100% 100%';
  } else if (isRecord || isJukebox || isVhs || activeSkinKey === 'custom-basic') {
    queueSurface.style.backgroundImage = `url("${queueSource}")`;
    queueSurface.style.backgroundPosition = 'center';
    queueSurface.style.backgroundRepeat = 'no-repeat';
    queueSurface.style.backgroundSize = '100% 100%';
  } else {
    queueSurface.style.backgroundImage = 'none';
  }
}
function setSkinMakerMode(mode) {
  skinMakerMode = mode;
  skinMaker.dataset.editorMode = mode;
  document.querySelectorAll('.skin-mode').forEach(button => button.classList.toggle('active', button.dataset.skinMode === mode));
  const canvasImage = document.querySelector('#skinCanvasImage');
  canvas.style.aspectRatio = mode === 'player' ? (editableSkin.player?.aspectRatio || editorPresets[activeSkinEditorKey]?.player?.aspectRatio || '3 / 2') : '3 / 2';
  const layers = [...document.querySelectorAll('.skin-layer')];
  if (mode === 'queue') {
    canvasImage.src = skinAsset(activeSkinEditorKey || document.body.dataset.skin, 'queue');
    document.querySelector('#skinMakerEyebrow').textContent = 'SKIN MAKER — QUEUE LAYOUT';
    document.querySelector('#skinMakerHelp').textContent = 'PLACE THE VIP AND STANDARD QUEUE HEADERS, PLUS THE MANUAL ENTRY SECTION, ON THE QUEUE BACKGROUND.';
    layers.forEach(layer => layer.hidden = true);
    const show = document.querySelector('[data-layer="vipTitle"]') || document.querySelector('[data-layer="show"]'); const song = document.querySelector('[data-layer="standardTitle"]') || document.querySelector('[data-layer="song"]'); const manual = document.querySelector('[data-layer="manualEntry"]') || document.querySelector('[data-layer="artist"]');
    show.hidden = song.hidden = manual.hidden = false; show.dataset.layer = 'vipTitle'; song.dataset.layer = 'standardTitle'; manual.dataset.layer = 'manualEntry'; show.textContent = 'VIP QUEUE'; song.textContent = 'STANDARD QUEUE'; manual.textContent = 'MANUAL ENTRY'; show.classList.remove('song-layer'); song.classList.remove('song-layer'); manual.classList.remove('song-layer');
    setLayerPosition(show, editableSkin.positions.vipTitle); setLayerPosition(song, editableSkin.positions.standardTitle); setLayerPosition(manual, editableSkin.positions.manualEntry); applyTypography(show, 'vipTitle', editableSkin); applyTypography(song, 'standardTitle', editableSkin); applyTypography(manual, 'manualEntry', editableSkin);
    renderSkinMakerQueuePreview();
  } else {
    canvasImage.src = skinAsset(activeSkinEditorKey || document.body.dataset.skin, 'player');
    document.querySelector('#skinMakerEyebrow').textContent = 'SKIN MAKER — PLAYER LAYOUT';
    const usesCassetteReels = activeSkinEditorKey === 'cassette';
    document.querySelector('#skinMakerHelp').textContent = usesCassetteReels ? 'UPLOAD A BACKGROUND, THEN DRAG THE LABELS AND EACH CASSETTE REEL ANIMATION ON THE GRID.' : 'UPLOAD A BACKGROUND, THEN DRAG THE SHOW, SONG, AND ARTIST LABELS ON THE GRID.';
    const show = document.querySelector('[data-layer="vipTitle"]') || document.querySelector('[data-layer="show"]'); const song = document.querySelector('[data-layer="standardTitle"]') || document.querySelector('[data-layer="song"]'); const artist = document.querySelector('[data-layer="manualEntry"]') || document.querySelector('[data-layer="artist"]');
    show.hidden = song.hidden = artist.hidden = false; show.dataset.layer = 'show'; song.dataset.layer = 'song'; artist.dataset.layer = 'artist'; show.textContent = document.querySelector('.show-name').textContent; song.textContent = document.querySelector('#playerSong').textContent; artist.textContent = document.querySelector('#playerArtist').textContent; song.classList.add('song-layer'); document.querySelector('[data-layer="leftReel"]').hidden = !usesCassetteReels; document.querySelector('[data-layer="rightReel"]').hidden = !usesCassetteReels;
    setLayerPosition(show, editableSkin.positions.show); setLayerPosition(song, editableSkin.positions.song); setLayerPosition(artist, editableSkin.positions.artist); applyTypography(show, 'show', editableSkin); applyTypography(song, 'song', editableSkin); applyTypography(artist, 'artist', editableSkin);
    if (usesCassetteReels) { setLayerPosition(document.querySelector('[data-layer="leftReel"]'), editableSkin.positions.leftReel); setLayerPosition(document.querySelector('[data-layer="rightReel"]'), editableSkin.positions.rightReel); }
    skinQueuePreview.innerHTML = '';
  }
  syncTypographyControls();
}
function syncTypographyControls() {
  const target = document.querySelector('#typeTarget');
  const options = skinMakerMode === 'queue' ? [['vipTitle', 'VIP QUEUE'], ['standardTitle', 'STANDARD QUEUE'], ['manualEntry', 'MANUAL ENTRY']] : [['show', 'SHOW TITLE'], ['song', 'SONG TITLE'], ['artist', 'ARTIST']];
  if (!options.some(([key]) => key === typographyKey)) typographyKey = options[0][0];
  target.innerHTML = options.map(([key, label]) => `<option value="${key}">${label}</option>`).join(''); target.value = typographyKey;
  const type = editableSkin.typography?.[typographyKey] || {};
  const layer = document.querySelector(`.skin-layer[data-layer="${typographyKey}"]`);
  const displayed = layer ? getComputedStyle(layer) : null;
  const displayedFont = type.font || displayed?.fontFamily || 'Caveat, cursive';
  const fontOption = [...document.querySelector('#typeFont').options].find(option => displayedFont.includes(option.value.split(',')[0].replace(/[']/g, ''))) || document.querySelector('#typeFont').options[0];
  document.querySelector('#typeFont').value = fontOption.value;
  const color = type.color || '#ffffff'; document.querySelector('#typeColor').value = color; document.querySelector('#typeColorHex').value = color.toUpperCase();
  document.querySelector('#typeSize').value = type.size || Math.round(parseFloat(displayed?.fontSize || (typographyKey === 'song' ? 32 : 20)));
  document.querySelector('#typeSizeValue').textContent = `${document.querySelector('#typeSize').value} PX`;
}
function updateTypography() {
  const font = document.querySelector('#typeFont').value; const size = Number(document.querySelector('#typeSize').value); const color = document.querySelector('#typeColor').value;
  ensureGoogleFont(font);
  editableSkin.typography ||= {}; editableSkin.typography[typographyKey] = { font, size, color };
  const layer = document.querySelector(`.skin-layer[data-layer="${typographyKey}"]`); applyTypography(layer, typographyKey, editableSkin);
  saveEditableSkin();
}
document.querySelector('#typeTarget').addEventListener('change', event => { typographyKey = event.target.value; syncTypographyControls(); });
document.querySelector('#typeFont').addEventListener('change', updateTypography);
document.querySelector('#typeColor').addEventListener('input', () => { document.querySelector('#typeColorHex').value = document.querySelector('#typeColor').value.toUpperCase(); updateTypography(); });
document.querySelector('#typeColorHex').addEventListener('change', event => { const color = event.target.value.trim(); if (!/^#[0-9a-f]{6}$/i.test(color)) { event.target.value = document.querySelector('#typeColor').value.toUpperCase(); return say('ENTER A 6-DIGIT HEX COLOR'); } document.querySelector('#typeColor').value = color; event.target.value = color.toUpperCase(); updateTypography(); });
document.querySelector('#typeSize').addEventListener('input', () => { document.querySelector('#typeSizeValue').textContent = `${document.querySelector('#typeSize').value} PX`; updateTypography(); });
function saveEditableSkin() { if (!activeSkinEditorKey) return say('SELECT A SKIN BEFORE SAVING'); editableSkin.name = document.querySelector('#skinName').value.trim() || 'UNTITLED SKIN'; capturePremiumMotionMetadata(); capturePremiumSkinMetadata(); editableSkin.packageId = activeSkinEditorKey; if (activeSkinEditorKey === 'custom-basic') { if (!skinPicker.querySelector('option[value="custom-basic"]')) skinPicker.insertAdjacentHTML('beforeend', '<option value="custom-basic"></option>'); skinPicker.querySelector('option[value="custom-basic"]').textContent = editableSkin.name.toUpperCase(); } persistPackageDefaults(activeSkinEditorKey, editableSkin); try { localStorage.setItem(`lirisq-editable-skin-${activeSkinEditorKey}`, JSON.stringify(editableSkin)); say(`${editableSkin.name.toUpperCase()} DEFAULTS SAVED`); } catch { say('IMAGE IS TOO LARGE TO SAVE LOCALLY — LAYOUT SAVED'); const withoutImage = clone(editableSkin); delete withoutImage.assets; localStorage.setItem(`lirisq-editable-skin-${activeSkinEditorKey}`, JSON.stringify(withoutImage)); } }
let draggedLayer = null;
const canvas = document.querySelector('#skinCanvas');
const skinQueuePreview = document.createElement('div');
skinQueuePreview.className = 'skin-queue-preview';
canvas.append(skinQueuePreview);
function renderSkinMakerQueuePreview() {
  if (skinMakerMode !== 'queue') return;
  const row = item => `<div class="skin-queue-row">${item.song} <span>— ${item.artist}</span></div>`;
  const queueBlock = (queue, position, extraClass = '') => `<div class="skin-queue-block ${extraClass}" style="left:${position.x}%;top:${position.y + 5}%"><div class="skin-queue-rows">${queue.slice(0, 3).map(row).join('') || '<div class="skin-queue-row empty">NO SONGS YET</div>'}${queue.length > 3 ? '<div class="skin-queue-row more">…</div>' : ''}</div></div>`;
  skinQueuePreview.innerHTML = `${queueBlock(state.vip, editableSkin.positions.vipTitle, 'vip')}${queueBlock(state.standard, editableSkin.positions.standardTitle, 'standard')}`;
  const actualManualEntry = document.querySelector('#queue .cassette-liner > .card').cloneNode(true);
  actualManualEntry.classList.add('skin-manual-preview'); actualManualEntry.removeAttribute('id'); actualManualEntry.style.left = `${editableSkin.positions.manualEntry.x}%`; actualManualEntry.style.top = `${editableSkin.positions.manualEntry.y}%`;
  actualManualEntry.querySelectorAll('[id]').forEach(element => element.removeAttribute('id'));
  actualManualEntry.querySelectorAll('input,button').forEach(element => { element.disabled = true; });
  skinQueuePreview.append(actualManualEntry);
}
canvas.addEventListener('pointerdown', event => { const layer = event.target.closest('.skin-layer'); if (!layer) return; if (['show', 'song', 'artist', 'vipTitle', 'standardTitle', 'manualEntry'].includes(layer.dataset.layer)) { typographyKey = layer.dataset.layer; syncTypographyControls(); } draggedLayer = layer; layer.classList.add('dragging'); layer.setPointerCapture(event.pointerId); });
  canvas.addEventListener('pointermove', event => { if (!draggedLayer) return; const rect = canvas.getBoundingClientRect(); const x = Math.max(0, Math.min(100, Math.round(((event.clientX - rect.left) / rect.width) * 100))); const y = Math.max(0, Math.min(100, Math.round(((event.clientY - rect.top) / rect.height) * 100))); const key = draggedLayer.dataset.layer; editableSkin.positions[key] = { x, y }; setLayerPosition(draggedLayer, editableSkin.positions[key]); renderSkinMakerQueuePreview(); });
canvas.addEventListener('pointerup', event => { if (!draggedLayer) return; draggedLayer.classList.remove('dragging'); draggedLayer.releasePointerCapture(event.pointerId); draggedLayer = null; const activeMode = skinMakerMode; saveEditableSkin(); setSkinMakerMode(activeMode); say('LAYOUT AUTO-SAVED'); });
document.querySelector('#skinBackground').addEventListener('change', event => { const file = event.target.files[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => { editableSkin.assets ||= {}; if (skinMakerMode === 'queue') editableSkin.assets.queueBackground = reader.result; else editableSkin.assets.playerBackground = reader.result; setSkinMakerMode(skinMakerMode); say('BACKGROUND READY — DRAG LAYERS TO PLACE'); }; reader.readAsDataURL(file); });
document.querySelector('#saveSkin').addEventListener('click', saveEditableSkin);
const exportSkinDefaults = document.createElement('button');
exportSkinDefaults.id = 'exportSkinDefaults'; exportSkinDefaults.className = 'btn'; exportSkinDefaults.type = 'button'; exportSkinDefaults.textContent = 'EXPORT PACK DEFAULTS';
document.querySelector('#saveSkin').after(exportSkinDefaults);
exportSkinDefaults.addEventListener('click', () => { if (!activeSkinEditorKey || activeSkinEditorKey === 'custom-basic') return say('SELECT AN INSTALLED SKIN PACKAGE'); const payload = skinDefaultsPayload(activeSkinEditorKey, editableSkin); const download = document.createElement('a'); download.href = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })); download.download = 'defaults.json'; document.body.append(download); download.click(); download.remove(); URL.revokeObjectURL(download.href); say('PACK DEFAULTS EXPORTED'); });
document.querySelector('#savePremiumSkin').addEventListener('click', () => { if (!capturePremiumSkinMetadata(true)) return; document.querySelector('#premiumSkinEnabled').checked = true; saveEditableSkin(); say('PREMIUM STORE METADATA SAVED — READY FOR MGBSTORE EXPORT'); });
document.querySelector('#premiumMotionEnabled').addEventListener('change', saveEditableSkin);
document.querySelector('#premiumMotionPreset').addEventListener('change', saveEditableSkin);
document.querySelector('#exportStoreManifest').addEventListener('click', () => {
  if (!capturePremiumSkinMetadata(true)) return;
  capturePremiumMotionMetadata();
  editableSkin.name = document.querySelector('#skinName').value.trim() || 'UNTITLED SKIN';
  const manifest = { schema:'mgbstore-skin-manifest/v1', package:{ name:editableSkin.name, version:editableSkin.store?.version || '0.1.0', store:editableSkin.store, premiumMotion:editableSkin.premiumMotion, assets:editableSkin.assets, typography:editableSkin.typography, positions:editableSkin.positions } };
  const download = document.createElement('a'); download.href = URL.createObjectURL(new Blob([JSON.stringify(manifest, null, 2)], { type:'application/json' })); download.download = `${editableSkin.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'premium-skin'}-mgbstore.json`; document.body.append(download); download.click(); download.remove(); URL.revokeObjectURL(download.href); saveEditableSkin(); say('MGBSTORE MANIFEST EXPORTED');
});
document.querySelector('#loadSkin').addEventListener('click', () => { if (!activeSkinEditorKey) return say('SELECT A SKIN FIRST'); editableSkin = packageLayout(activeSkinEditorKey); editableSkin.positions.manualEntry ||= clone(editorPresets[activeSkinEditorKey].positions.manualEntry); setSkinMakerMode(skinMakerMode); say('PACKAGE-BOUND SKIN LOADED'); });
const duplicateSkinButton = document.createElement('button');
duplicateSkinButton.className = 'btn'; duplicateSkinButton.type = 'button'; duplicateSkinButton.textContent = 'DUPLICATE';
document.querySelector('#newSkin').before(duplicateSkinButton);
duplicateSkinButton.addEventListener('click', () => { editableSkin = clone(editableSkin); editableSkin.name = `${editableSkin.name || 'SKIN'} COPY`; document.querySelector('#skinName').value = editableSkin.name; saveEditableSkin(); say('SKIN DUPLICATED — EDIT AND SAVE YOUR COPY'); });
document.querySelector('#newSkin').addEventListener('click', () => { editableSkin = clone(defaultSkinLayout); editableSkin.name = 'NEW SKIN'; document.querySelector('#skinBackground').value = ''; setSkinMakerMode(skinMakerMode); say('NEW SKIN STARTED'); });
document.querySelectorAll('.skin-mode').forEach(button => button.addEventListener('click', () => setSkinMakerMode(button.dataset.skinMode)));
document.body.dataset.playerState = 'playing';
applySkinLayout();
renderStreamerView();
const playbackModeSetting = document.createElement('div');
playbackModeSetting.className = 'playback-mode-card';
playbackModeSetting.innerHTML = '<b>PLAY MODE</b><div class="playback-mode-options" role="group" aria-label="Play mode"><button type="button" class="playback-mode-option" data-playback-mode="queue">QUEUE</button><button type="button" class="playback-mode-option" data-playback-mode="random">RANDOM</button><button type="button" class="playback-mode-option" data-playback-mode="free-play">FREE PLAY</button></div>';
function renderPlaybackModeSetting() { playbackModeSetting.querySelectorAll('[data-playback-mode]').forEach(button => { const active = button.dataset.playbackMode === playbackMode; button.classList.toggle('active', active); button.setAttribute('aria-pressed', String(active)); }); }
playbackModeSetting.addEventListener('click', event => { const button = event.target.closest('[data-playback-mode]'); if (!button) return; playbackMode = button.dataset.playbackMode; localStorage.setItem(playbackModeKey, playbackMode); if (playbackMode === 'random') primeRandomPlayback(); else render(); renderPlaybackModeSetting(); say(`${playbackMode === 'free-play' ? 'FREE PLAY' : playbackMode === 'random' ? 'RANDOM' : 'QUEUE MODE'} SAVED`); });
renderPlaybackModeSetting();
const mainConfigurationPanel = document.createElement('section');
mainConfigurationPanel.id = 'mainConfiguration';
const localeSetting = document.createElement('div');
localeSetting.className = 'setting';
const localeCopy = document.createElement('div'); const localeTitle = document.createElement('h3'); localeTitle.textContent = t('configuration.language.title'); const localeDescription = document.createElement('p'); localeDescription.textContent = t('configuration.language.description'); localeCopy.append(localeTitle, localeDescription);
const localeSelect = document.createElement('select'); localeSelect.id = 'lirisqLocale'; localeSelect.setAttribute('aria-label', 'Display language');
for (const [value, label] of [['en', 'English'], ['es', 'Español'], ['fr', 'Français'], ['de', 'Deutsch'], ['pt', 'Português']]) { const option = document.createElement('option'); option.value = value; option.textContent = label; localeSelect.append(option); }
localeSelect.value = lirisqI18n?.availableLocales().includes(lirisqI18n?.getLocale()) ? lirisqI18n.getLocale() : (lirisqI18n?.getLocale().split('-')[0] || 'en');
localeSetting.append(localeCopy, localeSelect);
localeSelect.addEventListener('change', () => { const locale = lirisqI18n?.setLocale(localeSelect.value) || 'en'; localStorage.setItem(localePreferenceKey, locale); localeTitle.textContent = t('configuration.language.title'); localeDescription.textContent = t('configuration.language.description'); renderOptionalAddonManager(); renderSkinPacks(); renderPlatformPluginConfigurations(); localizeUi(); say('DISPLAY LANGUAGE SAVED'); });
const broadcastTimezoneKey = 'lirisq-broadcast-timezone-v1';
const detectedBroadcastTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
const broadcastTimezoneSetting = document.createElement('div');
broadcastTimezoneSetting.className = 'setting';
const broadcastTimezoneSelect = document.createElement('select'); broadcastTimezoneSelect.id = 'broadcastTimezone'; broadcastTimezoneSelect.setAttribute('aria-label', 'Broadcast time zone');
const broadcastTimezones = typeof Intl.supportedValuesOf === 'function' ? Intl.supportedValuesOf('timeZone') : [detectedBroadcastTimezone, 'UTC', 'America/Los_Angeles', 'America/New_York', 'Europe/London', 'Europe/Berlin', 'Asia/Tokyo', 'Australia/Sydney'];
const savedBroadcastTimezone = localStorage.getItem(broadcastTimezoneKey) || detectedBroadcastTimezone;
for (const timezone of [...new Set([savedBroadcastTimezone, ...broadcastTimezones])]) { const option = document.createElement('option'); option.value = timezone; option.textContent = timezone; broadcastTimezoneSelect.append(option); }
broadcastTimezoneSelect.value = savedBroadcastTimezone;
broadcastTimezoneSetting.innerHTML = `<div><h3>BROADCAST TIME ZONE</h3><p id="broadcastTimezoneNote">DETECTED: ${detectedBroadcastTimezone}. THIS SETTING PERSISTS AND CAN OVERRIDE THE LOCAL DEVICE ZONE.</p></div>`;
broadcastTimezoneSetting.append(broadcastTimezoneSelect);
broadcastTimezoneSelect.addEventListener('change', () => { localStorage.setItem(broadcastTimezoneKey, broadcastTimezoneSelect.value); document.querySelector('#broadcastTimezoneNote').textContent = broadcastTimezoneSelect.value === detectedBroadcastTimezone ? `USING DETECTED LOCAL TIME ZONE: ${detectedBroadcastTimezone}.` : `BROADCAST TIME ZONE OVERRIDE SAVED: ${broadcastTimezoneSelect.value}.`; say('BROADCAST TIME ZONE SAVED'); });
window.LIRISQ_BROADCAST_TIMEZONE = Object.freeze({ get: () => localStorage.getItem(broadcastTimezoneKey) || detectedBroadcastTimezone });
const updateManifestKey = 'lirisq-update-manifest-url-v1';
const updateChannelPreferenceKey = 'lirisq-update-channel-v1';
const updateInstalledVersionKey = 'lirisq-installed-version-v1';
const defaultUpdateManifestUrl = 'https://raw.githubusercontent.com/moonscythe/LirisQ-distribution/main/latest/manifest.json';
const betaUpdateManifestUrl = 'https://raw.githubusercontent.com/moonscythe/LirisQ-distribution/beta/latest/manifest.json';
let updateChannel = Object.freeze({ channel:'public', label:'Public', manifestUrl:defaultUpdateManifestUrl, repositoryUrl:'https://github.com/moonscythe/LirisQ-distribution' });
const updateSetting = document.createElement('details');
updateSetting.className = 'optional-addons update-configuration-section';
updateSetting.innerHTML = `<summary>UPDATES</summary><p class="queue-note">See the installed version, review changes before installing, and keep your saved configuration. Update manifests describe releases only; they cannot run downloaded code.</p><div class="setting"><div><h3>SOFTWARE UPDATE</h3><p data-update-status>INSTALLED VERSION: ${lirisqApplicationVersion}. CHECK FOR RELEASE NOTES AND AVAILABLE PATCHES.</p><p class="queue-note" data-update-channel>UPDATE CHANNEL: LOADING…</p></div><div class="update-actions"><button type="button" class="btn" data-check-updates disabled>CHECK FOR UPDATES</button><button type="button" class="btn hot" data-install-update disabled>INSTALL UPDATE</button></div></div><details class="optional-addons"><summary>UPDATE SOURCE</summary><div class="setting"><div><h3>RELEASE CHANNEL</h3><p>Development and Beta use your protected server channel. Public uses approved public releases. Your choice persists until changed.</p></div><div><select data-update-channel-select aria-label="LirisQ release channel"><option value="development">DEVELOPMENT</option><option value="beta">BETA</option><option value="public">PUBLIC</option></select><button type="button" class="btn" data-save-update-channel>SAVE CHANNEL</button></div></div><div class="setting"><div><h3>MANIFEST URL</h3><p>Use a trusted custom source only for recovery or a controlled test.</p></div><div><input data-update-manifest aria-label="LirisQ update manifest URL" value=""><button type="button" class="btn" data-save-update-source>SAVE SOURCE</button><button type="button" class="btn" data-clear-update-source>USE CHANNEL DEFAULT</button></div></div></details><div data-update-details class="queue-note"></div>`;
let pendingUpdatePlan = null;
function renderUpdatePlan(plan) {
  const status = updateSetting.querySelector('[data-update-status]'); const details = updateSetting.querySelector('[data-update-details]');
  status.textContent = plan.available ? `INSTALLED: v${plan.currentVersion}. LATEST: v${plan.latestVersion}. REVIEW THE CHANGES BEFORE DOWNLOADING.` : `LIRISQ v${plan.currentVersion} IS UP TO DATE.`;
  details.replaceChildren();
  for (const release of plan.releases) { const article = document.createElement('article'); article.className = 'notice'; const title = document.createElement('strong'); title.textContent = `v${release.version}${release.summary ? ` — ${release.summary}` : ''}`; const list = document.createElement('ul'); release.changes.forEach(change => { const item = document.createElement('li'); item.textContent = change; list.append(item); }); article.append(title, list); details.append(article); }
  const install=updateSetting.querySelector('[data-install-update]'); pendingUpdatePlan=plan; install.disabled=!plan.available||plan.executable!==true; if(plan.available&&plan.executable===false){const note=document.createElement('p');note.textContent=plan.error||'THE RELEASE PATH IS INCOMPLETE; INSTALLATION IS BLOCKED.';details.append(note);} if(plan.available&&plan.executable===true){const note=document.createElement('p');note.textContent=`READY TO INSTALL ${plan.packages.length} VERIFIED PACKAGE${plan.packages.length===1?'':'S'} IN ORDER.`;details.append(note);}
}
function visibleUpdateChannels() { return updateChannel.channel === 'development' ? ['development','beta','public'] : updateChannel.channel === 'beta' ? ['beta','public'] : ['public']; }
function selectedUpdateChannel() { const saved=localStorage.getItem(updateChannelPreferenceKey); return visibleUpdateChannels().includes(saved) ? saved : updateChannel.channel; }
function selectedUpdateManifest() { const choice=selectedUpdateChannel(); if(choice==='public')return defaultUpdateManifestUrl; if(choice==='beta')return betaUpdateManifestUrl; return `./updates/channel.php?channel=${choice}`; }
function refreshUpdateChannelDisplay() { const override = localStorage.getItem(updateManifestKey); const choice=selectedUpdateChannel(); const select=updateSetting.querySelector('[data-update-channel-select]'); select.innerHTML=visibleUpdateChannels().map(channel=>`<option value="${channel}">${channel.toUpperCase()}</option>`).join(''); updateSetting.querySelector('[data-update-channel]').textContent = `UPDATE CHANNEL: ${choice.toUpperCase()}${override ? ' (CUSTOM MANIFEST)' : ''}.`; select.value=choice; updateSetting.querySelector('[data-update-manifest]').value = override || selectedUpdateManifest(); }
function trustedUpdateManifestUrl(value) { try { const target = new URL(value, window.location.href); return target.protocol === 'https:' || target.origin === window.location.origin ? target.href : ''; } catch (_) { return ''; } }
async function loadUpdateChannel() {
  try { const response = await fetch('./lirisq-release-channel.json', { cache:'no-store' }); const value = await response.json(); if (!response.ok || value.schema !== 'lirisq-release-channel/v1' || !trustedUpdateManifestUrl(value.manifestUrl)) throw Error('Invalid release channel'); updateChannel = Object.freeze({ channel:String(value.channel || 'public'), label:String(value.label || 'Public'), manifestUrl:value.manifestUrl, repositoryUrl:String(value.repositoryUrl || '') }); }
  catch (_) { /* A package without its channel file safely remains on the public channel. */ }
  refreshUpdateChannelDisplay();
  updateSetting.querySelector('[data-check-updates]').disabled = false;
}
updateSetting.querySelector('[data-save-update-source]').addEventListener('click', () => { const value = updateSetting.querySelector('[data-update-manifest]').value.trim(); if (!trustedUpdateManifestUrl(value)) return say('ENTER A TRUSTED HTTPS OR SAME-SITE UPDATE MANIFEST URL'); localStorage.setItem(updateManifestKey, value); refreshUpdateChannelDisplay(); say('UPDATE SOURCE OVERRIDE SAVED'); });
updateSetting.querySelector('[data-clear-update-source]').addEventListener('click', () => { localStorage.removeItem(updateManifestKey); refreshUpdateChannelDisplay(); say('USING THE BUILD UPDATE SOURCE'); });
updateSetting.querySelector('[data-save-update-channel]').addEventListener('click', () => { localStorage.setItem(updateChannelPreferenceKey, updateSetting.querySelector('[data-update-channel-select]').value); localStorage.removeItem(updateManifestKey); refreshUpdateChannelDisplay(); say('UPDATE CHANNEL SAVED'); });
updateSetting.querySelector('[data-check-updates]').addEventListener('click', async () => {
  const status = updateSetting.querySelector('[data-update-status]'); const url = localStorage.getItem(updateManifestKey) || selectedUpdateManifest();
  const trustedUrl = trustedUpdateManifestUrl(url); if (!trustedUrl) { status.textContent = 'ENTER A TRUSTED HTTPS OR SAME-SITE UPDATE MANIFEST URL.'; return; }
  status.textContent = `CHECKING ${updateChannel.label.toUpperCase()} UPDATES…`;
  try { const response = await fetch(trustedUrl, { cache:'no-store' }); if (!response.ok) throw Error(`Update manifest request failed (${response.status})`); const plan = window.LirisQUpdateManager.packagePlan(lirisqApplicationVersion, await response.json()); renderUpdatePlan(plan); }
  catch (error) { status.textContent = `UPDATE CHECK UNAVAILABLE: ${String(error.message || error)}`; }
});
updateSetting.querySelector('[data-install-update]').addEventListener('click', async () => { if(!pendingUpdatePlan?.executable||!pendingUpdatePlan.available)return; const status=updateSetting.querySelector('[data-update-status]'); const button=updateSetting.querySelector('[data-install-update]'); const channel=selectedUpdateChannel(); button.disabled=true; status.textContent=`VERIFYING AND INSTALLING THE ${channel.toUpperCase()} RELEASE CHAIN…`; try { const response=await fetch('./updates/apply.php',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({channel})}); const result=await response.json(); if(!response.ok)throw Error(result.error||'Update installation failed'); status.textContent=result.updated?`LIRISQ UPDATED TO v${result.version}. BACKUP: ${result.backup}. REFRESHING…`:`LIRISQ v${result.version} IS ALREADY UP TO DATE.`; setTimeout(()=>location.reload(),900); } catch(error){status.textContent=`UPDATE INSTALLATION FAILED: ${String(error.message||error)}`;button.disabled=false;} });
void loadUpdateChannel();
try { const previouslyInstalled = localStorage.getItem(updateInstalledVersionKey) || lirisqApplicationVersion; if (window.LirisQUpdateManager.compareVersions(lirisqApplicationVersion, previouslyInstalled) >= 0) localStorage.setItem(updateInstalledVersionKey, lirisqApplicationVersion); } catch (_) { /* Local state remains usable if a pre-release version is malformed. */ }
mainConfigurationPanel.append(mgbSetting, playbackModeSetting, broadcastTimezoneSetting, localeSetting, updateSetting);
const obsConfigurationKey = 'lirisq-obs-configuration-v1';
const obsConfigurationSetting = document.createElement('details');
obsConfigurationSetting.className = 'optional-addons'; obsConfigurationSetting.open = true;
function renderObsConfiguration() {
  const enabled = pluginIsEnabled('lirisq.obs-integration');
  obsConfigurationSetting.hidden = !enabled;
  if (!enabled) return;
  const saved = storedJson(obsConfigurationKey, {});
  const overlayOrigin = window.location.origin === 'null' ? 'http://127.0.0.1:4317' : window.location.origin;
  obsConfigurationSetting.innerHTML = `<summary>OBS CONFIGURATION</summary><p class="queue-note">Add either browser-source URL below in OBS. They mirror LirisQ's Player Mode and Live Queue using only the local test server; they do not expose MGB pairing information. OBS WebSocket scene control remains separate and is not available yet.</p><div class="setting"><div><h3>PLAYER MODE OVERLAY</h3><p>Transparent, stream-facing current song and artist.</p></div><div><input id="obsPlayerOverlayUrl" aria-label="Player Mode overlay URL" readonly value="${overlayOrigin}/obs-player"> <button type="button" class="btn" data-copy-obs-overlay="obsPlayerOverlayUrl">COPY URL</button></div></div><div class="setting"><div><h3>LIVE QUEUE OVERLAY</h3><p>Transparent now-playing, VIP, and Standard Queue display.</p></div><div><input id="obsQueueOverlayUrl" aria-label="Live Queue overlay URL" readonly value="${overlayOrigin}/obs-queue"> <button type="button" class="btn" data-copy-obs-overlay="obsQueueOverlayUrl">COPY URL</button></div></div><div class="setting"><div><h3>OBS WEBSOCKET</h3><p>Use the address and port from OBS WebSocket Server settings. Password storage is intentionally not supported until secure transport is implemented.</p></div><div><input id="obsEndpoint" aria-label="OBS WebSocket address" placeholder="ws://127.0.0.1:4455" value="${String(saved.endpoint || 'ws://127.0.0.1:4455').replace(/"/g, '&quot;')}"> <label><input id="obsSceneEvents" type="checkbox" ${saved.sceneEvents !== false ? 'checked' : ''}> RECEIVE SCENE EVENTS</label> <button type="button" class="btn" id="saveObsConfiguration">SAVE OBS SETTINGS</button><p id="obsConfigurationNote" class="queue-note">LOCAL SETTINGS ONLY — OBS CONNECTION IS PENDING.</p></div></div>`;
  obsConfigurationSetting.querySelectorAll('[data-copy-obs-overlay]').forEach(button => button.addEventListener('click', () => navigator.clipboard.writeText(obsConfigurationSetting.querySelector(`#${button.dataset.copyObsOverlay}`).value).then(() => say('OBS BROWSER SOURCE URL COPIED')).catch(() => say('COPY THE URL FROM THE FIELD'))));
  obsConfigurationSetting.querySelector('#saveObsConfiguration').addEventListener('click', () => { const configuration = { endpoint: obsConfigurationSetting.querySelector('#obsEndpoint').value.trim() || 'ws://127.0.0.1:4455', sceneEvents: obsConfigurationSetting.querySelector('#obsSceneEvents').checked }; localStorage.setItem(obsConfigurationKey, JSON.stringify(configuration)); window.LirisQOBSIntegrationPlugin?.configure?.(configuration); obsConfigurationSetting.querySelector('#obsConfigurationNote').textContent = 'OBS SETTINGS SAVED LOCALLY — CONNECTION IS PENDING.'; say('OBS CONFIGURATION SAVED'); });
  window.LirisQOBSIntegrationPlugin?.configure?.(saved);
}
mainConfigurationPanel.append(obsConfigurationSetting, testDataDisclosure);
configurationIntegrationPlugins = {
  main: null, botplugins: 'lirisq.bot-core', skins: null, plugins: null
};
// Platform adapters are configured from Main.  Chat Bot owns command and
// feature controls, while the adapters own their profile/channel bindings.
let platformPluginConfigurationPanel = document.createElement('section');
platformPluginConfigurationPanel.id = 'platformPluginConfigurations';
let chatBotConfigurationPanel = null;
mainConfigurationPanel.insertBefore(platformPluginConfigurationPanel, testDataDisclosure);
const platformPluginConfigurations = [
  ['lirisq.twitch-live-adapter', 'TWITCH', 'LirisQTwitchLiveAdapterPlugin'],
  ['lirisq.youtube-live-adapter', 'YOUTUBE LIVE', 'LirisQYouTubeLiveAdapterPlugin'],
  ['lirisq.tiktok-live-adapter', 'TIKTOK LIVE', 'LirisQTikTokLiveAdapterPlugin'],
  ['lirisq.douyin-live-adapter', 'DOUYIN LIVE', 'LirisQDouyinLiveAdapterPlugin'],
  ['lirisq.bilibili-live-adapter', 'BILIBILI LIVE', 'LirisQBilibiliLiveAdapterPlugin'],
  ['lirisq.kick-live-adapter', 'KICK', 'LirisQKickLiveAdapterPlugin'],
  ['lirisq.x-live-adapter', 'X', 'LirisQXLiveAdapterPlugin']
];
const platformProfileLinksKey = 'lirisq-platform-profile-links-v1';
const chatbotCommandSettingsKey = 'lirisq-chatbot-command-settings-v1';
const chatbotModeratorDefaultsKey = 'lirisq-chatbot-broadcaster-defaults-v2';
const chatbotModeratorAccessKey = 'lirisq-chatbot-moderator-access-v1';
const chatbotCommandAliasesKey = 'lirisq-chatbot-command-aliases-v1';
const chatbotRulesKey = 'lirisq-chatbot-rules-v1';
const chatbotFeaturesExpandedKey = 'lirisq-chatbot-features-expanded-v1';
const platformVipEligibilityKey = 'lirisq-platform-vip-eligibility-v1';
function storedJson(key, fallback) { try { return JSON.parse(localStorage.getItem(key) || '') || fallback; } catch (_) { return fallback; } }
function platformAdapterConfiguration(id, saved = {}) {
  const streamerProfile = localStorage.getItem('lirisq-streamer-profile') || '';
  const channelId = String(saved.channelId || saved.profileName || '').trim();
  if (id === 'lirisq.twitch-live-adapter') return { channel: streamerProfile, streamerProfile, apiUrl:twitchEndpoint('chat') };
  if (id === 'lirisq.youtube-live-adapter') return { channelId, profileName: String(saved.profileName || '').trim(), streamerProfile: saved.linkedToStreamer === false ? '' : streamerProfile, linkedToStreamer: saved.linkedToStreamer !== false, serverMode:youtubeTransportConfiguration().kind, apiUrl:youtubeTransportConfiguration().phpEndpoint };
  if (id === 'lirisq.kick-live-adapter') return { channelId, profileName: String(saved.profileName || '').trim(), streamerProfile: saved.linkedToStreamer === false ? '' : streamerProfile, linkedToStreamer: saved.linkedToStreamer !== false };
  return { channelId, roomId: channelId, profileName: String(saved.profileName || '').trim(), streamerProfile: saved.linkedToStreamer === false ? '' : streamerProfile, linkedToStreamer: saved.linkedToStreamer !== false };
}
function platformRoleConfigurationNote(id) {
  if (id === 'lirisq.twitch-live-adapter') return 'THE AUTHENTICATED TWITCH EVENT PROVIDES THE CHANNEL, BROADCASTER, AND MODERATOR CLAIMS. THIS PROFILE LINK DOES NOT GRANT CHAT PERMISSIONS.';
  if (id === 'lirisq.youtube-live-adapter') return 'THE AUTHENTICATED YOUTUBE LIVECHAT EVENT PROVIDES OWNER AND MODERATOR CLAIMS. THE CHANNEL ID BINDS THOSE CLAIMS TO THIS CONFIGURATION.';
  if (id === 'lirisq.kick-live-adapter') return 'THE AUTHENTICATED KICK WEBHOOK PROVIDES BROADCASTER OR MODERATOR BADGES. THE CHANNEL ID BINDS THOSE CLAIMS TO THIS CONFIGURATION.';
  return 'AUTHENTICATED ROLE VERIFICATION IS NOT AVAILABLE FOR THIS PLATFORM YET. ALL CHAT USERS REMAIN VIEWERS UNTIL OFFICIAL ROLE TRANSPORT IS ADDED.';
}
function platformVipEligibilitySettings() { return { twitchBits:500, youtubeAmount:5, youtubeCurrency:'USD', kickKicks:500, ...storedJson(platformVipEligibilityKey, {}) }; }
function savePlatformVipEligibilitySettings(update = {}) { const settings = { ...platformVipEligibilitySettings(), ...update }; localStorage.setItem(platformVipEligibilityKey, JSON.stringify(settings)); window.LirisQBotCorePlugin?.configure?.({ vipEligibility:settings }); return settings; }
function vipEligibilitySetting(platform) {
  const settings = platformVipEligibilitySettings(); const setting = document.createElement('div'); setting.className = 'setting';
  if (platform === 'twitch') {
    setting.innerHTML = `<div><h3>TWITCH VIP ELIGIBILITY</h3><p>An active verified subscription has ongoing VIP eligibility. A verified Bits support event at or above this amount grants one VIP request.</p></div><div><label>MINIMUM BITS<br><input type="number" min="1" max="1000000" value="${Number(settings.twitchBits)}" aria-label="Minimum Twitch Bits for a VIP request"></label> <button type="button" class="btn">SAVE</button><p class="queue-note">SAVED LOCALLY.</p></div>`;
    setting.querySelector('button').addEventListener('click', () => { const bits = Number(setting.querySelector('input').value); try { savePlatformVipEligibilitySettings({ twitchBits:bits }); say('TWITCH VIP THRESHOLD SAVED'); } catch (error) { say(String(error.message || error)); } });
  } else if (platform === 'youtube') {
    setting.innerHTML = `<div><h3>YOUTUBE VIP ELIGIBILITY</h3><p>An active verified channel membership has ongoing VIP eligibility. A matching verified Super Chat or Super Sticker grants one VIP request.</p></div><div><label>MINIMUM SUPPORT<br><input type="number" min="0.01" step="0.01" value="${Number(settings.youtubeAmount)}" aria-label="Minimum YouTube support amount"></label> <label>CURRENCY<br><input maxlength="3" value="${String(settings.youtubeCurrency).replace(/"/g, '&quot;')}" aria-label="YouTube support currency"></label> <button type="button" class="btn">SAVE</button><p class="queue-note">MATCHES VERIFIED EVENTS IN THIS CURRENCY.</p></div>`;
    setting.querySelector('button').addEventListener('click', () => { const inputs = setting.querySelectorAll('input'); try { savePlatformVipEligibilitySettings({ youtubeAmount:Number(inputs[0].value), youtubeCurrency:inputs[1].value.trim().toUpperCase() }); say('YOUTUBE VIP THRESHOLD SAVED'); } catch (error) { say(String(error.message || error)); } });
  } else {
    setting.innerHTML = `<div><h3>KICK VIP ELIGIBILITY</h3><p>Verified subscriptions and gifted-subscription recipients have ongoing VIP eligibility. A verified KICKs gift at or above this amount grants one VIP request.</p></div><div><label>MINIMUM KICKS<br><input type="number" min="1" max="1000000" value="${Number(settings.kickKicks)}" aria-label="Minimum Kick KICKs for a VIP request"></label> <button type="button" class="btn">SAVE</button><p class="queue-note">SAVED LOCALLY.</p></div>`;
    setting.querySelector('button').addEventListener('click', () => { const kicks = Number(setting.querySelector('input').value); try { savePlatformVipEligibilitySettings({ kickKicks:kicks }); say('KICK VIP THRESHOLD SAVED'); } catch (error) { say(String(error.message || error)); } });
  }
  return setting;
}
function commandDescription(name) {
  const english = ({ help:'Lists available chat commands.', queue:'Shows the current queue.', nowplaying:'Shows the song playing now.', request:'Submits a song for streamer approval before it enters the queue.', myrequest:'Shows the viewer’s own request.', remove:'Removes the viewer’s own request.', rules:'Shows the queue rules. A verified broadcaster, or an allowed moderator, can add, replace, or delete the saved rules.', play:'Starts playback.', pause:'Pauses playback.', next:'Skips to the next song.', promote:'Moves an approved request to VIP priority.', demote:'Moves an approved request to Standard priority.', approval:'Lists pending requests, or approves a request by ID.', deny:'Declines a pending request by ID.', clear:'Clears the queue.', 'queue-mode':'Changes Queue, Random, or Free Play mode.', 'queue-limit':'Sets the maximum queue length.' })[name] || 'Runs this Bot Core command.';
  return (lirisqI18n?.getLocale() || 'en').split('-')[0] === 'en' ? english : t('chat.command.generic', { command:`!${name}` });
}
function defaultCommandEnabled(name, permission) { return permission !== 'broadcaster' && name !== 'vip'; }
function commandVariables(name) { return ({ request:'&lt;song title&gt; | &lt;artist&gt; | &lt;URL&gt;', remove:'[request ID]', rules:'add &lt;text&gt; | replace &lt;text&gt; | delete', approval:'[request ID]', deny:'&lt;request ID&gt;', promote:'&lt;request ID&gt;', demote:'&lt;request ID&gt;', clear:'', 'queue-mode':'&lt;queue|random|free-play&gt;', 'queue-limit':'&lt;number&gt;' })[name] ?? ''; }
function botPluginLifecycleControls(id) {
  const installed = pluginIsInstalled(id); const enabled = pluginIsEnabled(id);
  const controls = document.createElement('div'); controls.className = 'bot-plugin-lifecycle';
  const install = document.createElement('button'); install.type = 'button'; install.className = 'btn hot'; install.textContent = t('plugins.install'); install.hidden = installed;
  const toggle = document.createElement('button'); toggle.type = 'button'; toggle.className = `btn plugin-toggle ${enabled ? 'enabled' : 'disabled'}`; toggle.textContent = enabled ? t('plugins.enabled') : t('plugins.disabled'); toggle.disabled = !installed;
  const uninstall = document.createElement('button'); uninstall.type = 'button'; uninstall.className = 'btn uninstall'; uninstall.textContent = t('plugins.uninstall'); uninstall.disabled = !installed; uninstall.hidden = builtinBotFeatureIds.has(id);
  const refresh = () => refreshPluginManagementUi();
  install.addEventListener('click', async () => { try { await installBundledPlugin(id); refresh(); } catch (error) { say(String(error.message || error)); } });
  toggle.addEventListener('click', async () => { try { await setBundledPluginEnabled(id, !enabled); refresh(); } catch (error) { say(String(error.message || error)); } });
  uninstall.addEventListener('click', async () => { try { await uninstallBundledPlugin(id); refresh(); } catch (error) { say(String(error.message || error)); } });
  controls.append(install, toggle, uninstall); return controls;
}
function applyCommandAliases() {
  const aliasesPlugin = window.LirisQCommandAliasesPlugin;
  const aliases = pluginIsEnabled('lirisq.command-aliases') ? storedJson(chatbotCommandAliasesKey, {}) : {};
  aliasesPlugin?.configure?.({ aliases });
  window.LirisQBotCorePlugin?.configure?.({ commandAliases: aliases });
}
function renderCommandAliases(commandTable) {
  if (!pluginIsEnabled('lirisq.command-aliases')) return null;
  const details = document.createElement('details'); details.className = 'optional-addons'; details.open = true;
  details.innerHTML = `<summary>${t('ui.commandAliases')}</summary><p class="queue-note">Choose an existing command, then give it another name. Type the alias without !; it saves only in this browser.</p><div class="fields" data-alias-rows></div><div class="fields"><button type="button" class="btn" data-add-alias>ADD ALIAS</button><button type="button" class="btn hot" data-save-aliases>SAVE ALIASES</button></div><p class="queue-note" data-alias-feedback></p>`;
  const rows = details.querySelector('[data-alias-rows]'); const feedback = details.querySelector('[data-alias-feedback]');
  const entries = Object.entries(storedJson(chatbotCommandAliasesKey, {})).filter(([alias, command]) => /^[a-z][a-z0-9_-]*$/i.test(alias) && Object.hasOwn(commandTable, command));
  const addRow = (command = Object.keys(commandTable)[0] || '', alias = '') => {
    const row = document.createElement('div'); row.className = 'fields'; row.dataset.aliasRow = '';
    const select = document.createElement('select'); select.setAttribute('aria-label', 'Command to alias');
    for (const name of Object.keys(commandTable)) { const option = document.createElement('option'); option.value = name; option.textContent = `!${name}`; option.selected = name === command; select.append(option); }
    const input = document.createElement('input'); input.type = 'text'; input.maxLength = 48; input.placeholder = 'ALIAS (NO !)'; input.value = alias; input.setAttribute('aria-label', `Alias for ${command}`);
    const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'btn'; remove.textContent = 'REMOVE'; remove.addEventListener('click', () => row.remove());
    row.append(select, input, remove); rows.append(row);
  };
  entries.forEach(([alias, command]) => addRow(command, alias));
  if (!entries.length) addRow();
  details.querySelector('[data-add-alias]').addEventListener('click', () => addRow());
  details.querySelector('[data-save-aliases]').addEventListener('click', () => {
    const aliases = {}; let invalid = false;
    rows.querySelectorAll('[data-alias-row]').forEach(row => {
      const command = row.querySelector('select').value; const alias = row.querySelector('input').value.trim().replace(/^!+/, '').toLowerCase();
      if (!alias) return;
      if (!/^[a-z][a-z0-9_-]*$/.test(alias) || Object.hasOwn(commandTable, alias) || aliases[alias]) { invalid = true; return; }
      aliases[alias] = command;
    });
    if (invalid) { feedback.textContent = 'Use a unique alias that starts with a letter and does not replace an existing command.'; return; }
    localStorage.setItem(chatbotCommandAliasesKey, JSON.stringify(aliases)); applyCommandAliases(); feedback.textContent = Object.keys(aliases).length ? `${Object.keys(aliases).length} ALIAS${Object.keys(aliases).length === 1 ? '' : 'ES'} SAVED.` : 'NO CUSTOM ALIASES SAVED.'; say('COMMAND ALIASES SAVED');
  });
  return details;
}
function renderPlatformPluginConfigurations() {
  if (!platformPluginConfigurationPanel || !chatBotConfigurationPanel) return;
  window.LirisQBotCorePlugin?.configure?.({ vipEligibility:platformVipEligibilitySettings() });
  const links = storedJson(platformProfileLinksKey, {});
  platformPluginConfigurationPanel.replaceChildren();
  chatBotConfigurationPanel.replaceChildren();
  const platformDetails = [];
  for (const [id, label, globalName] of platformPluginConfigurations) {
    if (!pluginIsEnabled(id)) continue;
    const saved = links[id] || {};
    window[globalName]?.configure?.(platformAdapterConfiguration(id, saved));
    const details = document.createElement('details'); details.className = 'optional-addons';
    details.innerHTML = `<summary>${t('adapter.configuration',{platform:label})}</summary><p class="queue-note">${t('adapter.description',{platform:label})}</p>`;
    if (developmentPluginIds.has(id)) appendDevBadge(details.querySelector('summary'));
    if (id === 'lirisq.twitch-live-adapter') {
      details.querySelector('.queue-note').textContent = 'Connect the selected broadcaster with Twitch, then activate the signed EventSub subscriptions. Credentials and tokens stay on the LirisQ server.';
      if (streamerIdentitySetting) details.append(streamerIdentitySetting);
      if (twitchSetting) details.append(twitchSetting);
      const serverSetup = document.createElement('details'); serverSetup.className = 'optional-addons';
      const transportConfig = twitchTransportConfiguration();
      serverSetup.innerHTML = `<summary>TWITCH SERVER SETUP</summary><p class="queue-note">Choose the server companion that owns Twitch credentials. Node is for this local test build; PHP is for a hosted PHP deployment. YouTube uses the same server-side model, but its Google OAuth setup will have separate values.</p><div class="setting"><div><h3>SERVER COMPANION</h3><p>The browser only stores this public endpoint choice. Twitch secrets and tokens stay on the selected server.</p></div><div><label><input type="radio" name="twitchTransport" value="node" ${transportConfig.kind !== 'php' ? 'checked' : ''}> LOCAL NODE TEST SERVER</label><br><label><input type="radio" name="twitchTransport" value="php" ${transportConfig.kind === 'php' ? 'checked' : ''}> HOSTED PHP TWITCH PLUGIN</label><br><input data-twitch-php-endpoint aria-label="PHP Twitch endpoint" placeholder="https://your-domain.example/lirisq-api/plugins/twitch/twitch.php" value="${String(transportConfig.phpEndpoint || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"><button type="button" class="btn" data-save-twitch-transport>SAVE SERVER CHOICE</button></div></div><div class="setting"><div><h3>SERVER VALUES</h3><p><code>LIRISQ_TWITCH_CLIENT_ID</code><br><code>LIRISQ_TWITCH_CLIENT_SECRET</code><br><code>LIRISQ_TWITCH_REDIRECT_URI</code><br><code>LIRISQ_TWITCH_EVENTSUB_CALLBACK_URL</code><br><code>LIRISQ_TWITCH_EVENTSUB_SECRET</code></p></div><div><p class="queue-note">For Node, these are process environment values. For PHP, they go in its private configuration file outside the public web root. Register the redirect URI exactly in Twitch. The EventSub callback must be stable and public HTTPS. Do not put any secret in this browser configuration.</p></div></div><div class="twitch-server-guide"><a class="btn" data-twitch-server-guide target="_blank" rel="noreferrer"></a></div><p class="queue-note">After the server is ready: save the streamer profile, choose CONNECT TWITCH, approve Twitch access, then choose ACTIVATE EVENTSUB.</p>`;
      const updateServerGuide = () => { const kind = serverSetup.querySelector('input[name="twitchTransport"]:checked').value; const guide = serverSetup.querySelector('[data-twitch-server-guide]'); guide.href = kind === 'php' ? '/docs/TWITCH-PHP-SETUP.md' : '/docs/TWITCH-SETUP.md'; guide.textContent = kind === 'php' ? 'OPEN PHP SERVER SETUP GUIDE' : 'OPEN NODE SERVER SETUP GUIDE'; };
      serverSetup.querySelectorAll('input[name="twitchTransport"]').forEach(input => input.addEventListener('change', updateServerGuide)); updateServerGuide();
      serverSetup.querySelector('[data-save-twitch-transport]').addEventListener('click', () => { const kind = serverSetup.querySelector('input[name="twitchTransport"]:checked').value; const phpEndpoint = serverSetup.querySelector('[data-twitch-php-endpoint]').value.trim(); if (kind === 'php' && !/^https:\/\//.test(phpEndpoint)) return say('ENTER A PUBLIC HTTPS PHP TWITCH ENDPOINT'); localStorage.setItem(twitchTransportConfigurationKey, JSON.stringify({ kind, phpEndpoint, managedByDeployment:false })); window.LirisQTwitchLiveAdapterPlugin?.configure?.(platformAdapterConfiguration('lirisq.twitch-live-adapter')); void renderStreamerIdentity(); say(`TWITCH ${kind === 'php' ? 'PHP' : 'NODE'} SERVER SELECTED`); });
      details.append(serverSetup);
      details.append(vipEligibilitySetting('twitch'));
      const transport = document.createElement('div'); transport.className = 'setting'; transport.innerHTML = '<div><h3>TWITCH EVENTSUB TRANSPORT</h3><p>Creates signed subscriptions for stream status, subscriptions, gifts, Bits, and chat. Only verified Twitch events enter Bot Core.</p></div><div><button type="button" class="btn hot" data-twitch-subscribe>ACTIVATE EVENTSUB</button><p class="queue-note" data-twitch-transport-status>CHECKING SERVER READINESS…</p></div>';
      details.append(transport);
      const activation = transport.querySelector('[data-twitch-subscribe]');
      void fetch(twitchEndpoint('status'), { cache: 'no-store' }).then(response => response.ok ? response.json() : null).then(status => { const note = transport.querySelector('[data-twitch-transport-status]'); if (!status) { activation.disabled = true; return note.textContent = 'TWITCH SERVER IS UNAVAILABLE.'; } activation.disabled = !status.configured || !status.authorized; const enabled = Array.isArray(status.subscriptions) ? status.subscriptions.filter(subscription => subscription.status === 'enabled').length : 0; note.textContent = status.configured && status.authorized ? `${enabled} ACTIVE EVENTSUB SUBSCRIPTION${enabled === 1 ? '' : 'S'} · ${Number(status.receivedEvents) || 0} VERIFIED EVENT${Number(status.receivedEvents) === 1 ? '' : 'S'} RECEIVED.` : !status.oauthConfigured ? 'SERVER SETUP REQUIRED — ADD TWITCH CLIENT ID, CLIENT SECRET, REDIRECT URI, EVENTSUB CALLBACK URL, AND SIGNING SECRET.' : !status.authorized ? 'CONNECT THE SELECTED TWITCH BROADCASTER BEFORE ACTIVATING EVENTSUB.' : 'A PUBLIC HTTPS CALLBACK AND EVENTSUB SIGNING SECRET ARE REQUIRED.'; }).catch(() => { activation.disabled = true; transport.querySelector('[data-twitch-transport-status]').textContent = 'TWITCH SERVER IS UNAVAILABLE.'; });
      activation.addEventListener('click', async () => { activation.disabled = true; const note = transport.querySelector('[data-twitch-transport-status]'); note.textContent = 'CREATING TWITCH EVENTSUB SUBSCRIPTIONS…'; try { const response = await fetch(twitchEndpoint('subscriptions'), { method:'POST', headers:{'content-type':'application/json'}, body:'{}' }); const result = await response.json(); if (!response.ok) throw Error(result.error || 'Twitch EventSub activation failed'); const failures = result.results.filter(item => item.error); note.textContent = failures.length ? `SOME SUBSCRIPTIONS NEED ATTENTION: ${failures.map(item => item.type).join(', ').toUpperCase()}.` : 'EVENTSUB SUBSCRIPTIONS CREATED. TWITCH IS VERIFYING THE CALLBACK.'; } catch (error) { note.textContent = String(error.message || error); } finally { activation.disabled = false; } });
    } else if (id === 'lirisq.youtube-live-adapter') {
      const setting = document.createElement('div'); setting.className = 'setting';
      setting.innerHTML = `<div><h3>YOUTUBE CHANNEL</h3><p>Save the channel identity that will be authorized on the selected server companion. Google credentials and refresh tokens never go in this browser.</p></div><div><input data-platform-profile aria-label="YouTube profile" placeholder="YOUTUBE PROFILE / DISPLAY NAME" value="${String(saved.profileName || '').replace(/"/g, '&quot;')}"> <input data-platform-channel aria-label="YouTube channel ID" placeholder="YOUTUBE CHANNEL ID" value="${String(saved.channelId || saved.profileName || '').replace(/"/g, '&quot;')}"> <button type="button" class="btn">SAVE YOUTUBE CONFIGURATION</button><p class="queue-note"></p></div>`;
      const profile = setting.querySelector('[data-platform-profile]'); const channel = setting.querySelector('[data-platform-channel]'); const note = setting.querySelector('.queue-note'); note.textContent = saved.channelId || saved.profileName ? `CHANNEL ID SAVED LOCALLY AS ${(saved.channelId || saved.profileName).toUpperCase()}.` : 'SET A YOUTUBE CHANNEL ID BEFORE AUTHORIZING THE SERVER.';
      setting.querySelector('button').addEventListener('click', () => { links[id] = { profileName:profile.value.trim(), channelId:channel.value.trim(), linkedToStreamer:true }; localStorage.setItem(platformProfileLinksKey, JSON.stringify(links)); window[globalName]?.configure?.(platformAdapterConfiguration(id, links[id])); note.textContent = links[id].channelId ? `CHANNEL ID ${links[id].channelId.toUpperCase()} SAVED.` : 'SET A YOUTUBE CHANNEL ID BEFORE AUTHORIZING THE SERVER.'; say('YOUTUBE PLATFORM CONFIGURATION SAVED'); });
      details.append(setting);
      const serverSetup = document.createElement('details'); serverSetup.className = 'optional-addons'; const transportConfig = youtubeTransportConfiguration();
      serverSetup.innerHTML = `<summary>YOUTUBE SERVER SETUP</summary><p class="queue-note">Select where future Google OAuth and YouTube Live Chat transport will run. This saves only the public server choice; secrets stay on that server.</p><div class="setting"><div><h3>SERVER COMPANION</h3><p>Node is for a Node host. PHP is for a PHP host such as DreamHost.</p></div><div><label><input type="radio" name="youtubeTransport" value="node" ${transportConfig.kind !== 'php' ? 'checked' : ''}> NODE SERVER</label><br><label><input type="radio" name="youtubeTransport" value="php" ${transportConfig.kind === 'php' ? 'checked' : ''}> PHP SERVER</label><br><input data-youtube-php-endpoint aria-label="PHP YouTube endpoint" placeholder="https://your-domain.example/lirisq-api/plugins/youtube/youtube.php" value="${String(transportConfig.phpEndpoint || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"><button type="button" class="btn" data-save-youtube-transport>SAVE SERVER CHOICE</button></div></div><div class="twitch-server-guide"><a class="btn" data-youtube-server-guide target="_blank" rel="noreferrer"></a></div><p class="queue-note">Google OAuth and Live Chat transport are not live yet. Keep this adapter marked DEV until the chosen server is deployed and verified with an actual YouTube live chat.</p>`;
      const updateGuide = () => { const kind = serverSetup.querySelector('input[name="youtubeTransport"]:checked').value; const guide = serverSetup.querySelector('[data-youtube-server-guide]'); guide.href = kind === 'php' ? '/docs/YOUTUBE-PHP-SETUP.md' : '/docs/YOUTUBE-NODE-SETUP.md'; guide.textContent = kind === 'php' ? 'OPEN PHP YOUTUBE SETUP GUIDE' : 'OPEN NODE YOUTUBE SETUP GUIDE'; }; serverSetup.querySelectorAll('input[name="youtubeTransport"]').forEach(input => input.addEventListener('change', updateGuide)); updateGuide();
      serverSetup.querySelector('[data-save-youtube-transport]').addEventListener('click', () => { const kind = serverSetup.querySelector('input[name="youtubeTransport"]:checked').value; const phpEndpoint = serverSetup.querySelector('[data-youtube-php-endpoint]').value.trim(); if (kind === 'php' && !/^https:\/\//.test(phpEndpoint)) return say('ENTER A PUBLIC HTTPS PHP YOUTUBE ENDPOINT'); localStorage.setItem(youtubeTransportConfigurationKey, JSON.stringify({kind, phpEndpoint})); window[globalName]?.configure?.(platformAdapterConfiguration(id, links[id] || {})); say(`YOUTUBE ${kind === 'php' ? 'PHP' : 'NODE'} SERVER SELECTED`); });
      details.append(serverSetup);
      const transport = document.createElement('div'); transport.className = 'setting'; transport.innerHTML = '<div><h3>YOUTUBE LIVE CHAT TRANSPORT</h3><p>Connects the authorized channel, relays authenticated live-chat events to Bot Core, and sends approved Bot Core replies.</p></div><div><button type="button" class="btn hot" data-youtube-authorize>CONNECT YOUTUBE</button><p class="queue-note" data-youtube-transport-status>CHECKING SERVER READINESS…</p></div>';
      details.append(transport, vipEligibilitySetting('youtube'));
      const authorization = transport.querySelector('[data-youtube-authorize]'); const transportNote = transport.querySelector('[data-youtube-transport-status]');
      void fetch(youtubeEndpoint('status'), { cache:'no-store' }).then(response => response.ok ? response.json() : null).then(status => { if (!status) { authorization.disabled = true; return transportNote.textContent = 'YOUTUBE SERVER IS UNAVAILABLE.'; } authorization.disabled = !status.configured; authorization.textContent = status.authorized ? 'YOUTUBE CONNECTED' : 'CONNECT YOUTUBE'; transportNote.textContent = status.configured ? status.authorized ? status.liveChatId ? `${Number(status.receivedEvents) || 0} AUTHENTICATED LIVE CHAT EVENT${Number(status.receivedEvents) === 1 ? '' : 'S'} RECEIVED.` : 'YOUTUBE IS CONNECTED. START A LIVE STREAM WITH CHAT ENABLED TO ARM THE TRANSPORT.' : 'CONNECT THE YOUTUBE CHANNEL TO AUTHORIZE LIVE CHAT.' : 'SERVER SETUP REQUIRED — ADD GOOGLE CLIENT ID, CLIENT SECRET, AND REDIRECT URI.'; }).catch(() => { authorization.disabled = true; transportNote.textContent = 'YOUTUBE SERVER IS UNAVAILABLE.'; });
      authorization.addEventListener('click', () => { window.location.assign(youtubeEndpoint('authorize')); });
    } else if (id === 'lirisq.kick-live-adapter') {
      const setting = document.createElement('div'); setting.className = 'setting';
      setting.innerHTML = `<div><h3>KICK CHANNEL</h3><p>Save the channel identity that signed webhook events must match. Kick credentials and tokens stay on the server.</p></div><div><input data-platform-profile aria-label="Kick profile" placeholder="KICK PROFILE / DISPLAY NAME" value="${String(saved.profileName || '').replace(/"/g, '&quot;')}"> <input data-platform-channel aria-label="Kick channel ID" placeholder="KICK CHANNEL ID" value="${String(saved.channelId || saved.profileName || '').replace(/"/g, '&quot;')}"> <button type="button" class="btn">SAVE KICK CONFIGURATION</button><p class="queue-note"></p></div>`;
      const profile=setting.querySelector('[data-platform-profile]'),channel=setting.querySelector('[data-platform-channel]'),note=setting.querySelector('.queue-note');
      note.textContent=saved.channelId||saved.profileName?'CHANNEL ID SAVED LOCALLY.':'SET A KICK CHANNEL ID BEFORE AUTHORIZING THE SERVER.';
      setting.querySelector('button').addEventListener('click',()=>{links[id]={profileName:profile.value.trim(),channelId:channel.value.trim(),linkedToStreamer:true};localStorage.setItem(platformProfileLinksKey,JSON.stringify(links));window[globalName]?.configure?.(platformAdapterConfiguration(id,links[id]));note.textContent=links[id].channelId?`CHANNEL ID ${links[id].channelId.toUpperCase()} SAVED.`:'SET A KICK CHANNEL ID BEFORE AUTHORIZING THE SERVER.';say('KICK PLATFORM CONFIGURATION SAVED');});details.append(setting);
      const transport=document.createElement('div');transport.className='setting';transport.innerHTML='<div><h3>KICK SIGNED WEBHOOK TRANSPORT</h3><p>Uses server-owned OAuth with PKCE and verifies each webhook against Kick’s rotating public key. It does not enable chat replies yet.</p></div><div><button type="button" class="btn hot" data-kick-authorize>CONNECT KICK</button><p class="queue-note" data-kick-transport-status>CHECKING SERVER READINESS…</p></div>';details.append(transport,vipEligibilitySetting('kick'));
      const authorization=transport.querySelector('[data-kick-authorize]'),transportNote=transport.querySelector('[data-kick-transport-status]');void fetch('/api/kick/status',{cache:'no-store'}).then(response=>response.ok?response.json():null).then(status=>{if(!status){authorization.disabled=true;return transportNote.textContent='KICK SERVER IS UNAVAILABLE.';}authorization.disabled=!status.configured;authorization.textContent=status.authorized?'KICK CONNECTED':'CONNECT KICK';transportNote.textContent=status.configured?(status.authorized?`${Number(status.receivedEvents)||0} VERIFIED KICK WEBHOOK EVENT${Number(status.receivedEvents)===1?'':'S'} RECEIVED.`:'CONNECT KICK, THEN SET THE PUBLIC HTTPS WEBHOOK URL IN KICK DEVELOPER SETTINGS.'):'SERVER SETUP REQUIRED — ADD KICK CLIENT ID, CLIENT SECRET, REDIRECT URI, WEBHOOK CALLBACK URL, AND TOKEN ENCRYPTION KEY.';}).catch(()=>{authorization.disabled=true;transportNote.textContent='KICK SERVER IS UNAVAILABLE.';});authorization.addEventListener('click',()=>window.location.assign('/api/kick/authorize'));
    } else {
      const setting = document.createElement('div'); setting.className = 'setting';
      setting.innerHTML = `<div><h3>${t('adapter.channel',{platform:label})}</h3><p>Save the channel or room identity used by this adapter. ${platformRoleConfigurationNote(id)}</p></div><div><input data-platform-profile aria-label="${label} profile" placeholder="${t('adapter.profilePlaceholder',{platform:label})}" value="${String(saved.profileName || '').replace(/"/g, '&quot;')}"> <input data-platform-channel aria-label="${label} channel ID" placeholder="${t('adapter.channelPlaceholder',{platform:label})}" value="${String(saved.channelId || saved.profileName || '').replace(/"/g, '&quot;')}"> <label><input data-streamer-link type="checkbox" ${saved.linkedToStreamer !== false ? 'checked' : ''}> ${t('adapter.useStreamer')}</label> <button type="button" class="btn">${t('adapter.save')}</button><p class="queue-note"></p></div>`;
      const profile = setting.querySelector('[data-platform-profile]'); const channel = setting.querySelector('[data-platform-channel]'); const linked = setting.querySelector('[data-streamer-link]'); const note = setting.querySelector('.queue-note');
      note.textContent = saved.channelId || saved.profileName ? `CHANNEL ID SAVED LOCALLY AS ${(saved.channelId || saved.profileName).toUpperCase()}${linked.checked ? ' AND LINKED TO THE STREAMER PROFILE.' : '.'}` : 'SET A CHANNEL OR ROOM ID TO BIND THIS PLATFORM CONFIGURATION.';
      setting.querySelector('button').addEventListener('click', () => { const profileName = profile.value.trim(); const channelId = channel.value.trim(); links[id] = { profileName, channelId, linkedToStreamer: linked.checked }; localStorage.setItem(platformProfileLinksKey, JSON.stringify(links)); window[globalName]?.configure?.(platformAdapterConfiguration(id, links[id])); note.textContent = channelId ? `CHANNEL ID ${channelId.toUpperCase()} SAVED${linked.checked ? ' AND LINKED TO THE STREAMER PROFILE.' : '.'}` : 'SET A CHANNEL OR ROOM ID TO BIND THIS PLATFORM CONFIGURATION.'; say(`${label} PLATFORM CONFIGURATION SAVED`); });
      details.append(setting); if (id === 'lirisq.kick-live-adapter') details.append(vipEligibilitySetting('kick'));
    }
    details.append(botPluginLifecycleControls(id));
    platformDetails.push(details);
  }
  const featureDetails = document.createElement('details'); featureDetails.className = 'optional-addons'; featureDetails.open = localStorage.getItem(chatbotFeaturesExpandedKey) === 'true';
  featureDetails.innerHTML = `<summary>${t('chat.features')}</summary><p class="queue-note">${t('chat.featuresDescription')}</p>`;
  featureDetails.addEventListener('toggle', () => localStorage.setItem(chatbotFeaturesExpandedKey, String(featureDetails.open)));
  const botFeatureIds = botPluginDefinitions.filter(([, , category]) => category !== 'PLATFORM ADAPTERS').map(([globalName]) => window[globalName]?.id).filter(Boolean);
  for (const id of botFeatureIds) {
    const plugin = bundledPluginById.get(id); if (!plugin) continue;
    const card = document.createElement('div'); card.className = 'setting';
    card.innerHTML = `<div><h3>${localizedPluginName(plugin)}</h3><p>${localizedPluginDescription(plugin)}</p></div>`;
    if (developmentPluginIds.has(id)) appendDevBadge(card.querySelector('h3'));
    card.append(botPluginLifecycleControls(id));
    featureDetails.append(card);
  }
  const commandDetails = document.createElement('details'); commandDetails.className = 'optional-addons'; commandDetails.open = true;
  commandDetails.innerHTML = `<summary>${t('chat.commands')}</summary><p class="queue-note">${t('chat.commandsDescription')}</p>`;
  const commandSettings = storedJson(chatbotCommandSettingsKey, {}); const core = window.LirisQBotCorePlugin; const commandTable = core?.commandTable || {};
  if (!localStorage.getItem(chatbotModeratorDefaultsKey)) { for (const [name, permission] of Object.entries(commandTable)) if (permission === 'broadcaster') commandSettings[name] = false; localStorage.setItem(chatbotCommandSettingsKey, JSON.stringify(commandSettings)); localStorage.setItem(chatbotModeratorDefaultsKey, 'applied'); }
  const moderatorAccess = storedJson(chatbotModeratorAccessKey, {}); const commandGroups = { viewer: document.createElement('section'), broadcaster: document.createElement('section') };
  commandGroups.viewer.innerHTML = `<h3>${t('chat.viewerCommands')}</h3><p class="queue-note">${t('chat.viewerDescription')}</p>`;
  commandGroups.broadcaster.innerHTML = `<h3>${t('chat.broadcasterCommands')}</h3><p class="queue-note">${t('chat.broadcasterDescription')}</p>`;
  for (const [name, permission] of Object.entries(commandTable)) {
    const setting = document.createElement('div'); setting.className = 'setting'; const requestDependent = ['myrequest', 'remove', 'approval', 'deny'].includes(name); const enabled = (commandSettings[name] ?? defaultCommandEnabled(name, permission)) && (!requestDependent || (commandSettings.request ?? true)); const variables = commandVariables(name);
    setting.innerHTML = `<div><h3>!${name.toUpperCase()}</h3><p>${commandDescription(name)} ${variables ? t('chat.variables',{variables}) : t('chat.noVariables')}</p></div><div class="command-controls"><label><input type="checkbox" ${enabled ? 'checked' : ''} ${requestDependent && !(commandSettings.request ?? true) ? 'disabled' : ''}> ${t('chat.enableCommand')}</label>${permission === 'broadcaster' ? `<label><input type="checkbox" data-moderator-access ${moderatorAccess[name] ? 'checked' : ''}> ${t('chat.allowModerators')}</label>` : ''}</div>`;
    setting.querySelector('input').addEventListener('change', event => { commandSettings[name] = event.target.checked; if (name === 'request' && !event.target.checked) { commandSettings.myrequest = false; commandSettings.remove = false; commandSettings.approval = false; commandSettings.deny = false; } localStorage.setItem(chatbotCommandSettingsKey, JSON.stringify(commandSettings)); const enabledCommands = Object.entries(commandTable).filter(([command, role]) => commandSettings[command] ?? defaultCommandEnabled(command, role)).map(([command]) => command); core?.configure?.({ enabledCommands, moderatorAccess }); renderPlatformPluginConfigurations(); say(`!${name.toUpperCase()} ${event.target.checked ? 'ENABLED' : 'DISABLED'}`); });
    setting.querySelector('[data-moderator-access]')?.addEventListener('change', event => { moderatorAccess[name] = event.target.checked; localStorage.setItem(chatbotModeratorAccessKey, JSON.stringify(moderatorAccess)); core?.configure?.({ moderatorAccess }); say(`MODERATOR ACCESS FOR !${name.toUpperCase()} ${event.target.checked ? 'ENABLED' : 'DISABLED'}`); });
    (commandGroups[permission] || commandGroups.viewer).append(setting);
  }
  const rulesSetting = document.createElement('section'); rulesSetting.className = 'setting';
  rulesSetting.innerHTML = `<div><h3>${t('chat.rules')}</h3><p>Viewers use <code>!rules</code>. A verified broadcaster—or an allowed moderator—can use <code>!rules add &lt;text&gt;</code>, <code>!rules replace &lt;text&gt;</code>, or <code>!rules delete</code>. Add appends a new line; replace overwrites the saved message.</p><textarea id="chatbotRulesMessage" maxlength="1500" placeholder="Example: Keep requests stream-safe, use a playable link, and limit one request per viewer."></textarea><button type="button" class="btn" id="saveChatbotRules">${t('chat.saveRules')}</button></div><div class="command-controls"><label><input id="rulesModeratorAccess" type="checkbox"> ${t('chat.allowModerators')}</label></div>`;
  const rulesInput = rulesSetting.querySelector('#chatbotRulesMessage'); rulesInput.value = localStorage.getItem(chatbotRulesKey) || '';
  const rulesModeratorAccess = rulesSetting.querySelector('#rulesModeratorAccess'); rulesModeratorAccess.checked = moderatorAccess.rules !== false;
  rulesModeratorAccess.addEventListener('change', event => { moderatorAccess.rules = event.target.checked; localStorage.setItem(chatbotModeratorAccessKey, JSON.stringify(moderatorAccess)); core?.configure?.({ moderatorAccess }); say(`MODERATOR RULE EDITING ${event.target.checked ? 'ENABLED' : 'DISABLED'}`); });
  rulesSetting.querySelector('#saveChatbotRules').addEventListener('click', () => { localStorage.setItem(chatbotRulesKey, rulesInput.value.trim()); say('CHAT BOT RULES SAVED'); });
  commandGroups.broadcaster.append(rulesSetting);
  commandDetails.append(commandGroups.viewer, commandGroups.broadcaster);
  const aliasDetails = renderCommandAliases(commandTable); if (aliasDetails) commandDetails.append(aliasDetails);
  const enabledCommands = Object.entries(commandTable).filter(([command, permission]) => commandSettings[command] ?? defaultCommandEnabled(command, permission)).map(([command]) => command); core?.configure?.({ enabledCommands, moderatorAccess });
  applyCommandAliases();
  const platformGroup = document.createElement('details'); platformGroup.className = 'optional-addons'; platformGroup.open = true;
  platformGroup.innerHTML = `<summary>${t('adapter.platforms')}</summary><p class="queue-note">${t('adapter.platformsDescription')}</p>`;
  platformDetails.forEach(details => platformGroup.append(details));
  chatBotConfigurationPanel.append(commandDetails, featureDetails);
  platformPluginConfigurationPanel.append(platformGroup);
  renderStreamerIdentity();
}
function showConfigurationIntegration(view) {
  document.querySelectorAll('[data-configuration-integration]').forEach(panel => { panel.hidden = panel.dataset.configurationIntegration !== view; });
  document.querySelectorAll('[data-configuration-category]').forEach(button => button.classList.toggle('active', button.dataset.configurationCategory === view));
  if (view === 'plugins') renderOptionalAddonManager();
  if (view === 'skins') renderSkinPacks();
 if (view === 'botplugins') renderBotPlugins();
}
function mountConfigurationIntegrations() {
  const settings = document.querySelector('#settings .settings'); if (!settings || document.querySelector('#configurationIntegrations')) return;
  const category = document.createElement('section'); category.id = 'configurationIntegrations'; category.className = 'optional-addons';
  category.innerHTML = '<div class="fields" id="configurationIntegrationTabs"></div><div id="configurationIntegrationPanels"></div>';
  const tabs = category.querySelector('#configurationIntegrationTabs'); const panels = category.querySelector('#configurationIntegrationPanels');
  for (const [view, pluginId] of Object.entries(configurationIntegrationPlugins)) {
    const source = view === 'main' ? mainConfigurationPanel : view === 'plugins' ? document.querySelector('#optionalAddonManager') : view === 'skins' ? skinPackSetting : document.querySelector(`#${view}`); if (!source) continue;
    const label = { main: 'MAIN', plugins: 'PLUGINS', skins: 'SKINS', botplugins: 'CHAT BOT' }[view];
    const button = document.createElement('button'); button.type = 'button'; button.className = 'btn'; button.dataset.configurationCategory = view; if (pluginId) button.dataset.optional = ''; button.textContent = label;
    if (developmentPluginIds.has(pluginId)) appendDevBadge(button);
    button.hidden = false;
    button.disabled = Boolean(pluginId && !pluginIsEnabled(pluginId) && view !== 'botplugins');
    button.addEventListener('click', () => showConfigurationIntegration(view)); tabs.append(button);
    const panel = document.createElement('section'); panel.dataset.configurationIntegration = view; panel.hidden = true;
    if (view === 'main' || view === 'plugins' || view === 'skins') {
      panel.append(source);
    } else if (view === 'botplugins') {
      chatBotConfigurationPanel = document.createElement('section');
      chatBotConfigurationPanel.id = 'chatBotConfiguration';
      panel.append(chatBotConfigurationPanel);
      renderPlatformPluginConfigurations();
    } else while (source.firstChild) panel.append(source.firstChild);
    if (view !== 'main' && view !== 'plugins' && view !== 'skins') source.remove(); panels.append(panel);
  }
  settings.append(category);
}
if (playbackMode === 'random') primeRandomPlayback();
render();
renderOptionalAddonManager();
renderSkinPacks();
renderObsConfiguration();
mountConfigurationIntegrations();
function renderObsOverlay(payload) {
  const playing = payload?.playing;
  const nowPlaying = playing?.song ? `${playing.song}${playing.artist ? ` — ${playing.artist}` : ''}` : 'WAITING FOR PLAYBACK';
  const playerSong = document.querySelector('#obsPlayerSong'); const playerArtist = document.querySelector('#obsPlayerArtist');
  if (playerSong) playerSong.textContent = playing?.song || 'WAITING FOR PLAYBACK';
  if (playerArtist) playerArtist.textContent = playing?.artist || '';
  const queueNow = document.querySelector('#obsQueueNow');
  if (queueNow) queueNow.textContent = nowPlaying;
  const list = (id, entries) => { const target = document.querySelector(id); if (target) target.replaceChildren(...(entries.length ? entries : [{ song:'Queue is empty', artist:'' }]).map(entry => { const item = document.createElement('li'); item.className = 'row'; const line = document.createElement('div'); line.className = 'songline'; const song = document.createElement('span'); song.className = 'song'; song.textContent = entry.song || 'Untitled'; line.append(song); if (entry.artist) { const artist = document.createElement('span'); artist.className = 'artist'; artist.textContent = ` — ${entry.artist}`; line.append(artist); } item.append(line); return item; })); };
  list('#obsQueueVip', Array.isArray(payload?.queue?.vip) ? payload.queue.vip : []);
  list('#obsQueueStandard', Array.isArray(payload?.queue?.standard) ? payload.queue.standard : []);
}
if (obsOverlayView) {
  const refreshObsOverlay = () => void fetch('/api/obs/overlay', { cache:'no-store' }).then(response => response.ok ? response.json() : null).then(renderObsOverlay).catch(() => {});
  refreshObsOverlay(); setInterval(refreshObsOverlay, 1000);
}
showPage(obsOverlayView || routeView());
void reconcileBundledPlugins().then(() => { renderOptionalAddonManager(); renderSkinPacks(); renderBotPlugins(); renderPlatformPluginConfigurations(); renderCalendarExport(); renderNotifications(); if (document.body.dataset.audience === 'viewer') renderViewerShow(shows.filter(show => showOccurs(show, new Date(`${selectedCalendarDate}T00:00:00`))), selectedCalendarDate); });
loadPackageDefaultFiles();
