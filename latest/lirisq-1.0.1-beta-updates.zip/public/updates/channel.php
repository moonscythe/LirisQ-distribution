<?php
declare(strict_types=1);
// Private update-channel reader. Development and beta share the same access
// boundary and artifact validation; only their isolated private directories differ.
$_GET['action'] = $_GET['action'] ?? 'manifest';
$channel = (string)($_GET['channel'] ?? 'development');
if (!in_array($channel, ['development', 'beta'], true)) { http_response_code(404); exit; }
$_GET['channel'] = $channel;
require __DIR__ . '/development.php';
