<?php
declare(strict_types=1);

function lirisq_session_start(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start(['cookie_httponly' => true, 'cookie_secure' => true, 'cookie_samesite' => 'Lax']);
    }
}

function lirisq_server_owner(PDO $pdo): ?array {
    $pdo->exec('CREATE TABLE IF NOT EXISTS lirisq_server_owner (singleton TINYINT NOT NULL PRIMARY KEY, twitch_user_id VARCHAR(64) NOT NULL, twitch_login VARCHAR(100) NOT NULL, claimed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)');
    $owner = $pdo->query('SELECT twitch_user_id, twitch_login FROM lirisq_server_owner WHERE singleton = 1')->fetch();
    if ($owner) return $owner;
    $legacy = $pdo->query('SELECT broadcaster_user_id, broadcaster_login FROM lirisq_twitch_authorization WHERE singleton = 1')->fetch();
    if (!$legacy) return null;
    $statement = $pdo->prepare('INSERT INTO lirisq_server_owner (singleton,twitch_user_id,twitch_login) VALUES (1,?,?)');
    $statement->execute([(string)$legacy['broadcaster_user_id'], (string)$legacy['broadcaster_login']]);
    return ['twitch_user_id' => (string)$legacy['broadcaster_user_id'], 'twitch_login' => (string)$legacy['broadcaster_login']];
}

function lirisq_require_streamer(): void {
    lirisq_session_start();
    if (($_SESSION['lirisq_role'] ?? '') !== 'streamer') respond(403, ['error' => 'Streamer authentication is required']);
}
