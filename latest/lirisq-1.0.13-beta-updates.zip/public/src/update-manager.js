/* Update metadata is descriptive only. Only built-in migration IDs may change local state. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQUpdateManager = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const SCHEMA = 'lirisq-distribution/v1';
  function parseVersion(value) {
    const match = String(value || '').match(/^(\d+)\.(\d+)\.(\d+)$/);
    if (!match) throw new Error('Invalid LirisQ version');
    return match.slice(1).map(Number);
  }
  function compareVersions(left, right) { const a = parseVersion(left), b = parseVersion(right); for (let i = 0; i < 3; i += 1) if (a[i] !== b[i]) return a[i] - b[i]; return 0; }
  function validateManifest(manifest) {
    if (!manifest || manifest.schema !== SCHEMA || manifest.product !== 'LirisQ') throw new Error('Unrecognized update manifest');
    parseVersion(manifest.latestVersion);
    if (!Array.isArray(manifest.releaseNotes)) throw new Error('Invalid update manifest releases');
    const seen = new Set();
    const releases = manifest.releaseNotes.map(release => {
      if (!release || typeof release !== 'object') throw new Error('Invalid release');
      parseVersion(release.version); if (seen.has(release.version)) throw new Error('Duplicate release version'); seen.add(release.version);
      if (!Array.isArray(release.changes) || !Array.isArray(release.migrations)) throw new Error('Invalid release details');
      const packageRecord = value => {
        if (!value || typeof value !== 'object' || typeof value.url !== 'string' || !/^https:\/\//.test(value.url) || !/^sha256:[a-f0-9]{64}$/i.test(String(value.sha256 || ''))) throw new Error('Invalid release package');
        return Object.freeze({ url:value.url, sha256:String(value.sha256).toLowerCase(), size:Number.isInteger(value.size) && value.size > 0 ? value.size : null, from:typeof value.from === 'string' ? value.from : null });
      };
      const full = release.full ? packageRecord(release.full) : null;
      const deltas = Array.isArray(release.deltas) ? release.deltas.map(packageRecord) : [];
      if (deltas.some(item => !item.from || !/^\d+\.\d+\.\d+$/.test(item.from))) throw new Error('Invalid release delta');
      return Object.freeze({ version:release.version, date:String(release.date || ''), summary:String(release.summary || ''), changes:release.changes.map(String), migrations:release.migrations.map(String), full, deltas });
    }).sort((a, b) => compareVersions(a.version, b.version));
    return Object.freeze({ latestVersion:manifest.latestVersion, releases });
  }
  function planUpdate(currentVersion, manifest) { parseVersion(currentVersion); const safe = validateManifest(manifest); const releases = safe.releases.filter(release => compareVersions(release.version, currentVersion) > 0); return Object.freeze({ currentVersion, latestVersion:safe.latestVersion, available:compareVersions(safe.latestVersion, currentVersion) > 0, releases }); }
  function packagePlan(currentVersion, manifest) {
    const plan = planUpdate(currentVersion, manifest); if (!plan.available) return Object.freeze({ ...plan, packages:[], executable:true });
    let cursor = currentVersion; const packages = [];
    for (const release of plan.releases) {
      const delta = release.deltas.find(item => item.from === cursor);
      const selected = delta || release.full;
      if (!selected) return Object.freeze({ ...plan, packages:[], executable:false, error:`No verified package path from ${cursor} to ${release.version}` });
      packages.push(Object.freeze({ version:release.version, kind:delta ? 'delta' : 'full', ...selected })); cursor = release.version;
    }
    return Object.freeze({ ...plan, packages:Object.freeze(packages), executable:true });
  }
  function applyMigrations(storage, plan, handlers, appliedKey = 'lirisq-applied-updates-v1') {
    if (!storage || typeof storage.getItem !== 'function' || typeof storage.setItem !== 'function') throw new Error('Persistent storage is required');
    const applied = new Set(JSON.parse(storage.getItem(appliedKey) || '[]')); const snapshot = {};
    for (let i = 0; i < storage.length; i += 1) { const key = storage.key(i); if (key && key.startsWith('lirisq-')) snapshot[key] = storage.getItem(key); }
    try { for (const release of plan.releases) for (const migration of release.migrations) { if (applied.has(migration)) continue; const handler = handlers[migration]; if (typeof handler !== 'function') throw new Error(`Unsupported local migration: ${migration}`); handler(storage); applied.add(migration); } storage.setItem(appliedKey, JSON.stringify([...applied].sort())); return Object.freeze({ version:plan.latestVersion, applied:[...applied].sort() }); }
    catch (error) { for (const key of Object.keys(snapshot)) storage.setItem(key, snapshot[key]); throw error; }
  }
  return Object.freeze({ SCHEMA, compareVersions, validateManifest, planUpdate, packagePlan, applyMigrations });
});
