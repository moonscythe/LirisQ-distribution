/* LirisQ platform adapter kit v1.2.0.
 * Offline-first: adapters normalize/replay events; live transports are injected separately.
 */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.LirisQPlatformAdapterKit=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const PLATFORMS=new Set(['twitch','youtube','douyin','bilibili','x','kick','tiktok']);
 const TYPES=new Set(['stream.status','chat.message','chat.command','queue.request','viewer.follow','viewer.subscription','viewer.subscription.end','viewer.support']);
 const ROLES=new Set(['viewer','moderator','broadcaster']);
 const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
 function boundedString(v,n,name){if(typeof v!=='string'||!v.trim()||v.length>n)throw Error(name+' must be a non-empty string of at most '+n+' characters');return v;}
 function normalize(input){
  if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Event must be an object');
  const platform=boundedString(input.platform,32,'platform').toLowerCase();if(!PLATFORMS.has(platform))throw Error('Unsupported platform');
  const type=boundedString(input.type,48,'type');if(!TYPES.has(type))throw Error('Unsupported event type');
  const id=boundedString(String(input.externalEventId||''),200,'externalEventId');
  const occurredAt=input.occurredAt||new Date().toISOString();if(Number.isNaN(Date.parse(occurredAt)))throw Error('occurredAt must be an ISO timestamp');
  const payload=input.payload;if(!payload||typeof payload!=='object'||Array.isArray(payload))throw Error('payload must be an object');
  if((type==='chat.message'||type==='chat.command')&&Object.hasOwn(payload,'role')&&!ROLES.has(payload.role))throw Error('chat role must be viewer, moderator, or broadcaster');
  const encoded=JSON.stringify(payload);if(encoded.length>65536)throw Error('payload exceeds 64 KiB');
  return Object.freeze({schema:'lirisq.platform-event/v1',source:input.source||'adapter',platform,type,externalEventId:id,occurredAt:new Date(occurredAt).toISOString(),verified:input.verified===true, payload:Object.freeze({...payload})});
 }
 function createDeduper(limit){const seen=new Set();return{accept(e){const key=e.platform+':'+e.externalEventId;if(seen.has(key))return false;seen.add(key);if(seen.size>limit)seen.delete(seen.values().next().value);return true;},clear(){seen.clear();}};}
 function createReplay(events,{publish=()=>{},source='fixture'}={}){
  const list=Array.isArray(events)?events:[];return async function replay(){let count=0;for(const raw of list){const e=normalize({...raw,source,verified:false});if(await publish(e)!==false)count++;}return count;};
 }
 return Object.freeze({PLATFORMS,TYPES,ROLES,normalize,createDeduper,createReplay});
});
