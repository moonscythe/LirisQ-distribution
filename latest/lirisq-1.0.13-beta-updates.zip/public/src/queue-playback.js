/* Deterministic queue progression policy. The app supplies a random source for testability. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LirisQQueuePlayback = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const artistKey = item => String(item?.artist || '').trim().toLocaleLowerCase();
  const copy = state => ({ vip: [...(state.vip || [])], standard: [...(state.standard || [])] });
  function chooseStandard(standard, lastArtist = '', random = Math.random) {
    if (!standard.length) return null;
    const differentArtist = standard.filter(item => artistKey(item) !== lastArtist);
    const candidates = differentArtist.length ? differentArtist : standard;
    return candidates[Math.min(candidates.length - 1, Math.max(0, Math.floor(random() * candidates.length)))];
  }
  function moveToFront(items, item) { const index = items.indexOf(item); if (index > 0) items.splice(index, 1), items.unshift(item); }
  function primeRandom(state, lastArtist = '', random = Math.random) {
    const next = copy(state);
    if (next.vip.length || !next.standard.length) return { state: next, lastArtist };
    const picked = chooseStandard(next.standard, lastArtist, random);
    moveToFront(next.standard, picked);
    return { state: next, lastArtist: artistKey(picked) };
  }
  function advance(state, { mode = 'queue', lastArtist = '', random = Math.random } = {}) {
    const next = copy(state);
    if (next.vip.length) next.vip.shift();
    else if (next.standard.length) next.standard.shift();
    if (mode !== 'random' || next.vip.length || !next.standard.length) return { state: next, lastArtist };
    const picked = chooseStandard(next.standard, lastArtist, random);
    moveToFront(next.standard, picked);
    return { state: next, lastArtist: artistKey(picked) };
  }
  return Object.freeze({ chooseStandard, primeRandom, advance });
});
