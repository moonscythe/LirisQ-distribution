<?php
declare(strict_types=1);

$runtimeRoot = null;
foreach ([dirname(__DIR__), dirname(__DIR__, 2)] as $candidate) {
    if (is_file($candidate . '/runtime-guard.php')) { $runtimeRoot = $candidate; break; }
}
if ($runtimeRoot === null) { http_response_code(500); exit('LirisQ runtime guard is unavailable.'); }
require_once $runtimeRoot . '/runtime-guard.php';
lirisq_require_secure_php();

function updateRespond(int $status, array $body): never {
    http_response_code($status);
    header('content-type: application/json; charset=utf-8');
    header('cache-control: no-store');
    exit(json_encode($body, JSON_UNESCAPED_SLASHES));
}
function updateConfig(string $root): array {
    $config = is_file($root . '/private/lirisq-hosted-config.php') ? require $root . '/private/lirisq-hosted-config.php' : null;
    if (!is_array($config) || empty($config['database'])) updateRespond(503, ['error' => 'Hosted LirisQ configuration is unavailable']);
    return $config;
}
function updatePdo(array $config): PDO {
    return new PDO($config['database']['dsn'], $config['database']['username'], $config['database']['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
}
function updateAuthorized(PDO $pdo): bool {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start(['cookie_httponly' => true, 'cookie_secure' => true, 'cookie_samesite' => 'Lax']);
    if (($_SESSION['lirisq_role'] ?? '') === 'streamer') return true;
    $id = (string)($_SESSION['lirisq_user_id'] ?? '');
    if ($id === '') return false;
    $pdo->exec('CREATE TABLE IF NOT EXISTS lirisq_development_update_collaborator (twitch_user_id VARCHAR(64) NOT NULL PRIMARY KEY, twitch_login VARCHAR(100) NOT NULL, granted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
    $statement = $pdo->prepare('SELECT 1 FROM lirisq_development_update_collaborator WHERE twitch_user_id = ?');
    $statement->execute([$id]);
    return (bool)$statement->fetchColumn();
}

$config = updateConfig($runtimeRoot);
$pdo = updatePdo($config);
if (!updateAuthorized($pdo)) updateRespond(403, ['error' => 'Development update access requires an authorized streamer or collaborator session']);

$action = (string)($_GET['action'] ?? 'manifest');
$channel = (string)($_GET['channel'] ?? 'development');
if (!in_array($channel, ['development', 'beta'], true)) updateRespond(404, ['error' => 'Unknown private update channel']);
$updateRoot = $runtimeRoot . '/private/' . $channel . '-updates';
if ($action === 'manifest') {
    $path = $updateRoot . '/manifest.json';
    if (!is_file($path)) updateRespond(404, ['error' => 'No development update has been published']);
    header('content-type: application/json; charset=utf-8');
    header('cache-control: no-store');
    readfile($path);
    exit;
}
if ($action === 'artifact') {
    $file = (string)($_GET['file'] ?? '');
    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*\.zip$/', $file)) updateRespond(400, ['error' => 'Invalid development artifact']);
    $path = $updateRoot . '/artifacts/' . $file;
    if (!is_file($path)) updateRespond(404, ['error' => 'Development artifact is unavailable']);
    header('content-type: application/zip');
    header('content-disposition: attachment; filename="' . $file . '"');
    header('content-length: ' . (string)filesize($path));
    header('cache-control: no-store');
    readfile($path);
    exit;
}
updateRespond(404, ['error' => 'Unknown development update action']);
