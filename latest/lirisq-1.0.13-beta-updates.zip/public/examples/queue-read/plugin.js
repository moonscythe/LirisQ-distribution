/* Queue Read v0.1.0 — Bot Core capability provider. */
(function(root, factory) { const plugin = factory(root); if (typeof module === 'object' && module.exports) module.exports = plugin; else root.LirisQQueueReadPlugin = plugin; })(typeof globalThis !== 'undefined' ? globalThis : this, function(root) {
  let active = false, unregister = null;
  function service() { const value = root.LIRISQ_QUEUE_COMMAND_SERVICE; if (!value) throw Error('Queue service unavailable'); return value; }
  function execute(command) { const queue = service(); if (command.name === 'queue') return queue.snapshot(); if (command.name === 'vip') return { vip: queue.snapshot().vip, standard: [] }; if (command.name === 'nowplaying') return { nowPlaying: queue.nowPlaying() }; throw Error('Unsupported Queue Read command'); }
  return Object.freeze({ id:'lirisq.queue-read', name:'Queue Read', version:'0.2.0', permissions:['queue.read'], description:'Provides Bot Core with read-only queue, current-song and queue-rule data.', factory() { active = true; unregister = root.LirisQBotCapabilityRegistry.register('lirisq.queue-read', 'queue.read', { execute }); return { stop() { active = false; unregister?.(); unregister = null; } }; }, status() { return { active, available: active && !!root.LIRISQ_QUEUE_COMMAND_SERVICE }; } });
});
