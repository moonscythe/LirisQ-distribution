/* Queue Administration v0.1.0 — guarded Bot Core administration provider. */
(function(root,factory){const plugin=factory(root);if(typeof module==='object'&&module.exports)module.exports=plugin;else root.LirisQQueueAdministrationPlugin=plugin;})(typeof globalThis!=='undefined'?globalThis:this,function(root){
  const auditKey='lirisq-queue-admin-audit-v1', limit=100;
  let active=false,unregister=null,pendingClear=null;
  const service=()=>{if(!root.LIRISQ_QUEUE_COMMAND_SERVICE)throw Error('Queue service unavailable');return root.LIRISQ_QUEUE_COMMAND_SERVICE;};
  const load=()=>{try{const value=JSON.parse(root.localStorage?.getItem(auditKey)||'[]');return Array.isArray(value)?value:[];}catch{return[];}};
  let audit=load();
  function persist(){try{root.localStorage?.setItem(auditKey,JSON.stringify(audit));}catch{ /* Local audit persistence is best effort. */ }}
  function entry(command,context,outcome,detail){audit.unshift({at:new Date().toISOString(),command,actorId:String(context?.actor?.id||''),platform:String(context?.actor?.platform||''),channelId:String(context?.actor?.channelId||''),eventId:String(context?.invocation?.event?.externalEventId||''),outcome,detail:String(detail||'').slice(0,200)});audit.length=Math.min(audit.length,limit);persist();}
  function clearToken(){const bytes=new Uint32Array(1);root.crypto?.getRandomValues?.(bytes);return (bytes[0]||Math.floor(Math.random()*0xffffffff)).toString(36).slice(0,8).toUpperCase();}
  function execute(command,context={}){
    const queue=service();
    if(command.name==='clear'){
      const supplied=String(command.tokens[0]||'').toUpperCase();
      if(!pendingClear||pendingClear.expiresAt<Date.now()||supplied!==pendingClear.token){pendingClear={token:clearToken(),expiresAt:Date.now()+60000};entry('clear',context,'confirmation-required','');return{confirmationRequired:true,token:pendingClear.token,expiresInSeconds:60};}
      pendingClear=null;const result=queue.clearAll();entry('clear',context,'completed',String(result.removed));return result;
    }
    if(command.name==='queue-mode'){
      const mode=String(command.tokens[0]||'').toLowerCase();const result=queue.setMode(mode);entry('queue-mode',context,'completed',mode);return result;
    }
    if(command.name==='queue-limit'){
      const value=Number(command.tokens[0]);if(!Number.isInteger(value)||value<1||value>999)throw Error('Use !queue-limit <1-999>.');const result=queue.setLimit(value);entry('queue-limit',context,'completed',String(value));return result;
    }
    throw Error('Unsupported Queue Administration command');
  }
  return Object.freeze({id:'lirisq.queue-administration',name:'Queue Administration',version:'0.1.0',permissions:['queue.admin'],description:'Lets verified broadcasters make guarded queue administration changes through Bot Core.',factory(){active=true;unregister=root.LirisQBotCapabilityRegistry.register('lirisq.queue-administration','queue.admin',{execute});return{stop(){active=false;pendingClear=null;unregister?.();unregister=null;}};},status(){return{active,available:active&&!!root.LIRISQ_QUEUE_COMMAND_SERVICE,pendingClear:Boolean(pendingClear),auditEntries:audit.length};},audit:()=>audit.map(item=>({...item})),clearAudit(){audit=[];persist();}});
});
