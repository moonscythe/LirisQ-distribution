/* Opt-in advisory Queue Voting plugin: never mutates FIFO or VIP ordering. */
(function (root, factory) {
  const plugin = factory();
  if (typeof module === 'object' && module.exports) module.exports = plugin;
  else root.LirisQQueueVotingPlugin = plugin;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  let enabled = false;
  const songs = new Map();
  const votes = new Map();
  function normalize(value, label) {
    if (typeof value !== 'string' || !/^[a-zA-Z0-9._:-]{1,128}$/.test(value)) throw new Error('Invalid ' + label);
    return value;
  }
  function reset() { songs.clear(); votes.clear(); }
  return Object.freeze({
    id: 'lirisq.queue-voting',
    description: 'Collects advisory votes for queued songs without changing VIP priority or queue order.',
    version: '0.1.0',
    permissions: ['queue.read'],
    factory(api) {
      enabled = true;
      const unsubscribe = api.on('song.queued', payload => {
        if (payload && typeof payload.id === 'string') {
          try { songs.set(normalize(payload.id, 'song ID'), { title: String(payload.title || '').slice(0, 300), artist: String(payload.artist || '').slice(0, 300) }); }
          catch (_) { /* Ignore malformed queue events. */ }
        }
      });
      return { stop() { enabled = false; unsubscribe(); reset(); } };
    },
    vote(songId, voterId) {
      if (!enabled) throw new Error('Enable Queue Voting first');
      songId = normalize(songId, 'song ID');
      voterId = normalize(voterId, 'voter ID');
      if (!songs.has(songId)) throw new Error('Unknown queued song');
      let voters = votes.get(songId);
      if (!voters) { voters = new Set(); votes.set(songId, voters); }
      if (voters.has(voterId)) return false;
      voters.add(voterId);
      return true;
    },
    retract(songId, voterId) {
      if (!enabled) throw new Error('Enable Queue Voting first');
      const voters = votes.get(normalize(songId, 'song ID'));
      return Boolean(voters && voters.delete(normalize(voterId, 'voter ID')));
    },
    results() {
      return [...songs].map(([songId, song]) => ({ songId, ...song, votes: votes.get(songId)?.size || 0 }))
        .sort((a, b) => b.votes - a.votes || a.songId.localeCompare(b.songId));
    },
    reset
  });
});
