/* command-aliases v0.1.0 — opt-in LirisQ Bot Core feature. */
(function(root, factory) {
  const plugin = factory();
  if (typeof module === 'object' && module.exports) module.exports = plugin;
  else root.LirisQCommandAliasesPlugin = plugin;
})(typeof globalThis !== 'undefined' ? globalThis : this, function make() {
  let active = false;
  let aliases = {};

  function configure(value = {}) {
    const requested = value.aliases && typeof value.aliases === 'object' ? value.aliases : {};
    aliases = Object.fromEntries(Object.entries(requested)
      .filter(([alias, command]) => /^[a-z][a-z0-9_-]*$/i.test(alias) && typeof command === 'string')
      .map(([alias, command]) => [alias.toLowerCase(), command.toLowerCase()]));
    return { aliases: { ...aliases } };
  }

  return Object.freeze({
    id: 'lirisq.command-aliases',
    name: 'Command Aliases',
    version: '0.1.0',
    permissions: [],
    description: 'Lets you give an existing Bot Core command an additional chat command name. Aliases stay local to this LirisQ install.',
    factory() { active = true; return { stop() { active = false; } }; },
    status() { return { active, aliases: { ...aliases } }; },
    configure
  });
});
