/* Discord Integration v0.11.0: single Discord platform plugin and opt-in webhook delivery. */
(function (root, factory) {
  const plugin = factory();
  if (typeof module === 'object' && module.exports) module.exports = plugin;
  else root.LirisQDiscordIntegrationPlugin = plugin;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const MAX_MESSAGES = 100;
  const TRANSPORT_KEY = 'lirisq-discord-transport-v1';
  function endpoint(action) {
    try {
      const saved = JSON.parse(root.localStorage?.getItem(TRANSPORT_KEY) || 'null');
      if (saved?.kind === 'php' && /^https:\/\//.test(String(saved.phpEndpoint || ''))) {
        const url = new URL(String(saved.phpEndpoint)); url.searchParams.set('action', action); return url.toString();
      }
    } catch (_) {}
    return `/api/discord/${action}`;
  }
  const messages = [];
  const deliveries = [];
  let deliveryId = 0;
  function addDelivery(kind, content) {
    const entry = { id: ++deliveryId, kind, content: String(content).slice(0, 1000), state: 'pending', createdAt: new Date().toISOString(), detail: '' };
    deliveries.push(entry);
    if (deliveries.length > 100) deliveries.shift();
    return entry;
  }
  function failDelivery(entry, error) {
    entry.state = 'failed';
    entry.detail = String(error.message || error);
    failed++;
    lastError = entry.detail;
  }
  const seen = new Set();
  let active = false;
  let autoPost = false;
  let lastError = null;
  let sent = 0;
  let pending = 0;
  let failed = 0;
  let deliveryChain = Promise.resolve();
  let generation = 0;
  const SETTINGS_KEY = 'lirisq-discord-event-settings-v1';
  const eventSettings = { 'song.queued': true, 'song.started': true, 'song.finished': false };
  try {
    const saved = JSON.parse(root.localStorage?.getItem(SETTINGS_KEY) || 'null');
    if (saved && typeof saved === 'object' && !Array.isArray(saved)) {
      for (const event of Object.keys(eventSettings)) {
        if (typeof saved[event] === 'boolean') eventSettings[event] = saved[event];
      }
    }
  } catch (_) { /* Unavailable or invalid local preferences: retain defaults. */ }
  function saveEventSettings() {
    try { root.localStorage?.setItem(SETTINGS_KEY, JSON.stringify(eventSettings)); }
    catch (_) { /* In-memory preferences still work if storage is blocked. */ }
  }
  const TEMPLATE_KEY = 'lirisq-discord-templates-v1';
  const defaults = {
    'song.queued': '🎵 {queue} request: **{title}** — {artist}',
    'song.started': '▶️ Now playing: **{title}** — {artist}',
    'song.finished': '⏹️ Finished: **{title}** — {artist}'
  };
  const templates = { ...defaults };
  try {
    const saved = JSON.parse(root.localStorage?.getItem(TEMPLATE_KEY) || 'null');
    if (saved && typeof saved === 'object' && !Array.isArray(saved)) {
      for (const event of Object.keys(defaults)) {
        if (typeof saved[event] === 'string' && saved[event].trim() && saved[event].length <= 500) templates[event] = saved[event];
      }
    }
  } catch (_) {}
  function saveTemplates() {
    try { root.localStorage?.setItem(TEMPLATE_KEY, JSON.stringify(templates)); } catch (_) {}
  }
  function clean(value, max = 180) {
    return String(value == null ? '' : value)
      .replace(/[\r\n\t]+/g, ' ')
      .replace(/@/g, '@\u200b')
      .replace(/<(?=[@#!&])/g, '<\u200b')
      .trim().slice(0, max);
  }
  function format(event, payload) {
    if (!Object.prototype.hasOwnProperty.call(templates, event)) return '';
    const fields = {
      title: clean(payload.title || payload.song || 'Untitled song'),
      artist: clean(payload.artist || 'Unknown artist'),
      queue: payload.queue === 'vip' ? 'VIP' : payload.queue === 'standard' ? 'Standard' : 'Queue'
    };
    return templates[event].replace(/\\{(title|artist|queue)\\}/g, (_, field) => fields[field]).slice(0, 1000);
  }
  async function deliver(content, batch, entry) {
    if (!active || !autoPost || batch !== generation) { entry.state = 'cancelled'; return; }
    pending++;
    try {
      const response = await fetch(endpoint('announce'), {
        method: 'POST', headers: { 'content-type': 'application/json' },
        credentials: 'same-origin', body: JSON.stringify({ content })
      });
      if (!response.ok) throw new Error(response.status === 429 ? 'Discord rate limit reached (HTTP 429). Wait before sending again.' : 'Discord delivery failed (HTTP ' + response.status + ')');
      entry.state = 'sent';
      sent++;
      lastError = null;
    } catch (error) { failDelivery(entry, error); }
    finally { pending--; }
  }
  function record(event, payload) {
    if (!payload || typeof payload !== 'object') return;
    const id = payload.id || payload.songId;
    if (typeof id !== 'string' || !id || id.length > 128) return;
    const key = event + ':' + id;
    if (seen.has(key)) return;
    const content = format(event, payload);
    if (!content) return;
    seen.add(key);
    messages.push({ event, songId: id, content, createdAt: new Date().toISOString() });
    if (active && autoPost && eventSettings[event] === true) {
      const batch = generation;
      const entry = addDelivery(event, content);
      deliveryChain = deliveryChain.then(() => deliver(content, batch, entry));
    }
    while (messages.length > MAX_MESSAGES) {
      const removed = messages.shift();
      seen.delete(removed.event + ':' + removed.songId);
    }
  }
  return Object.freeze({
    id: 'lirisq.discord-integration',
    version: '0.11.0',
    permissions: ['queue.read'],
    factory(api) {
      active = true;
      const unsubscribers = [
        api.on('song.queued', payload => record('song.queued', payload)),
        api.on('song.started', payload => record('song.started', payload)),
        api.on('song.finished', payload => record('song.finished', payload))
      ];
      return { stop() {
        active = false;
        autoPost = false;
        generation++;
        for (const unsubscribe of unsubscribers) unsubscribe();
        messages.length = 0;
        seen.clear();
      } };
    },
    status() { return { active, autoPost, count: messages.length, sent, failed, pending, lastError, delivery: 'server-webhook' }; },
    setAutoPost(value) {
      const next = active && value === true;
      if (!next) generation++;
      autoPost = next;
      return autoPost;
    },
    async sendManual(content) {
      if (!active) throw new Error('Enable the Discord plugin first');
      if (typeof content !== 'string' || !content.trim() || content.length > 1000) throw new Error('Message must contain 1–1000 characters');
      const safe = content.replace(/@/g, '@\\u200b').replace(/<(?=[@#!&])/g, '<\\u200b');
      const entry = addDelivery('manual', safe);
      pending++;
      try {
        const response = await fetch(endpoint('announce'), {
          method: 'POST', headers: { 'content-type': 'application/json' },
          credentials: 'same-origin', body: JSON.stringify({ content: safe })
        });
        if (!response.ok) throw new Error(response.status === 429 ? 'Discord rate limit reached (HTTP 429). Wait before sending again.' : 'Manual Discord delivery failed (HTTP ' + response.status + ')');
        entry.state = 'sent';
        sent++;
        lastError = null;
        return true;
      } catch (error) {
        failDelivery(entry, error);
        throw error;
      } finally { pending--; }
    },
    async sendTest() {
      if (!active) throw new Error('Enable the Discord plugin first');
      const entry = addDelivery('test', 'LirisQ Discord connection check — test announcement.');
      pending++;
      try {
        const response = await fetch(endpoint('announce'), {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify({ content: 'LirisQ Discord connection check — test announcement.' })
        });
        if (!response.ok) throw new Error(response.status === 429 ? 'Discord rate limit reached (HTTP 429). Wait before sending again.' : 'Discord test delivery failed (HTTP ' + response.status + ')');
        entry.state = 'sent';
        sent++;
        lastError = null;
        return true;
      } catch (error) {
        failDelivery(entry, error);
        throw error;
      } finally { pending--; }
    },
    templates() { return { ...templates }; },
    setTemplate(event, value) {
      if (!Object.prototype.hasOwnProperty.call(templates, event)) throw new Error('Unknown Discord announcement event');
      if (typeof value !== 'string' || !value.trim() || value.length > 500) throw new Error('Template must contain 1–500 characters');
      const tokens = value.match(/\\{[^{}]*\\}/g) || [];
      if (tokens.some(token => !['{title}', '{artist}', '{queue}'].includes(token))) throw new Error('Unknown template placeholder');
      templates[event] = value;
      saveTemplates();
      return { ...templates };
    },
    resetTemplates() {
      Object.assign(templates, defaults);
      saveTemplates();
      return { ...templates };
    },
    preview(event, template) {
      if (template !== undefined) {
        if (typeof template !== 'string') throw new TypeError('Template must be a string');
        const original = templates[event];
        if (original === undefined) throw new Error('Unknown event');
        const fields = { title: 'Example Song', artist: 'Example Artist', queue: 'VIP' };
        return template.replace(/\\{(title|artist|queue)\\}/g, (_, field) => fields[field]).slice(0, 1000);
      }
      return format(event, { title: 'Example Song', artist: 'Example Artist', queue: 'vip' });
    },
    eventSettings() { return { ...eventSettings }; },
    setEventEnabled(event, enabled) {
      if (!Object.prototype.hasOwnProperty.call(eventSettings, event)) throw new Error('Unknown Discord announcement event');
      if (typeof enabled !== 'boolean') throw new TypeError('Expected boolean');
      eventSettings[event] = enabled;
      saveEventSettings();
      return { ...eventSettings };
    },
    async retryDelivery(id) {
      if (!active) throw new Error('Enable the Discord plugin first');
      const original = deliveries.find(entry => entry.id === id);
      if (!original || original.state !== 'failed') throw new Error('Only failed deliveries can be retried');
      if (original.retrying) throw new Error('Retry already in progress');
      original.retrying = true;
      try {
        const entry = addDelivery('retry: ' + original.kind, original.content);
        entry.retryOf = original.id;
        pending++;
        try {
          const response = await fetch(endpoint('announce'), {
            method: 'POST', headers: { 'content-type': 'application/json' },
            credentials: 'same-origin', body: JSON.stringify({ content: original.content })
          });
          if (!response.ok) throw new Error(response.status === 429 ? 'Discord rate limit reached (HTTP 429). Wait before retrying.' : 'Discord retry failed (HTTP ' + response.status + ')');
          entry.state = 'sent';
          sent++;
          lastError = null;
          return true;
        } catch (error) {
          failDelivery(entry, error);
          throw error;
        } finally { pending--; }
      } finally { original.retrying = false; }
    },
    deliveryHistory() { return deliveries.map(entry => ({ ...entry })); },
    drafts() { return messages.map(message => ({ ...message })); },
    clear() { messages.length = 0; seen.clear(); }
  });
});
