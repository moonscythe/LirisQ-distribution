/* Stream Notifications v1.0.0: local source-of-truth outbox and event producers. */
(function (root, factory) {
  const plugin = factory();
  if (typeof module === 'object' && module.exports) module.exports = plugin;
  else root.LirisQStreamNotificationsPlugin = plugin;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const id='lirisq.stream-notifications', key='lirisq-stream-notifications-v1';
  const description='Central local notification outbox for show changes and song requests. Deduplicates events, supports approval and manual delivery, and prepares reusable messages for existing X and Discord channels without silently publishing.';
  let active=false;
  function read(){try{const raw=JSON.parse(globalThis.localStorage?.getItem(key)||'{}');return {outbox:Array.isArray(raw.outbox)?raw.outbox:[],snapshots:raw.snapshots&&typeof raw.snapshots==='object'?raw.snapshots:{},queue:raw.queue&&typeof raw.queue==='object'?raw.queue:{}};}catch(_){return {outbox:[],snapshots:{},queue:{}};}}
  let state=read();
  const RULES_KEY='lirisq-stream-notification-rules-v1';
  const DEFAULT_RULES=[1440,60,15];
  let reminderMinutes=DEFAULT_RULES;
  try { const value=JSON.parse(globalThis.localStorage?.getItem(RULES_KEY)||'null'); if(Array.isArray(value)&&value.every(n=>Number.isInteger(n)&&n>=1&&n<=10080)&&value.length<=12) reminderMinutes=[...new Set(value)].sort((a,b)=>b-a); } catch(_) {}
  function setReminderMinutes(value){if(!Array.isArray(value)||value.length>12||!value.every(n=>Number.isInteger(n)&&n>=1&&n<=10080))throw new Error('Enter up to 12 reminder offsets between 1 and 10080 minutes');reminderMinutes=[...new Set(value)].sort((a,b)=>b-a);try{globalThis.localStorage?.setItem(RULES_KEY,JSON.stringify(reminderMinutes));}catch(_){}return [...reminderMinutes];}
  function reminders(){return [...reminderMinutes];}
  function schedulePreview(shows,zone,now=new Date()){
    if(!Array.isArray(shows))throw new Error('Show list required');
    const calendar=globalThis.LirisQShowCalendarPlugin;
    if(!calendar||typeof calendar.occurrences!=='function')throw new Error('Calendar Export plugin required for schedule calculations');
    const items=[];
    for(const show of shows){
      let dates=[];
      try { dates=calendar.occurrences(show,new Date(now.getTime()-10080*60000),30,zone); } catch(_){continue;}
      for(const date of dates){
        let start;
        try {start=calendar.instantFor(date,show.time,zone);}catch(_){continue;}
        for(const minutes of reminderMinutes){
          const due=new Date(start.getTime()-minutes*60000);
          if(due.getTime()<now.getTime())continue;
          items.push({showId:String(show.id),title:String(show.title||'Show'),date,minutes,dueAt:due.toISOString(),startAt:start.toISOString()});
        }
      }
    }
    return items.sort((a,b)=>a.dueAt.localeCompare(b.dueAt)).slice(0,100);
  }
  function prepareDue(shows,zone,now=new Date(),lookbackMinutes=5){
    if(!active)return [];
    if(!Number.isInteger(lookbackMinutes)||lookbackMinutes<0||lookbackMinutes>60)throw new Error('Invalid lookback');
    const calendar=globalThis.LirisQShowCalendarPlugin;
    if(!calendar)throw new Error('Calendar Export plugin required');
    const rows=[];
    for(const show of shows||[]){
      let dates=[];
      try {dates=calendar.occurrences(show,new Date(now.getTime()-10080*60000),30,zone);}catch(_){continue;}
      for(const date of dates){
        let start;try{start=calendar.instantFor(date,show.time,zone);}catch(_){continue;}
        for(const minutes of reminderMinutes){
          const due=start.getTime()-minutes*60000;
          if(due>now.getTime()||due<now.getTime()-lookbackMinutes*60000)continue;
          const fingerprint=date+':'+show.time+':'+zone+':'+minutes;
          const row=enqueue('show.reminder','shows',String(show.id),'Reminder: '+show.title+' starts on '+date+' at '+show.time+' ('+zone+') in '+minutes+' minutes.',fingerprint);
          if(row)rows.push(row);
        }
      }
    }
    return rows;
  }
  function persist(){try{globalThis.localStorage?.setItem(key,JSON.stringify(state));}catch(_){}}
  function compact(show){return {id:String(show.id),title:String(show.title||'Show'),date:String(show.date||''),time:String(show.time||''),recurrence:String(show.recurrence||'once'),repeatDays:JSON.stringify(show.repeatDays||[]),noShowDates:JSON.stringify(show.noShowDates||[])};}
  function enqueue(type,source,sourceId,message,fingerprint){
    if(!active||settings.types[type]===false)return null;
    const key=[type,sourceId,fingerprint].join(':');
    if(state.outbox.some(row=>row.dedupeKey===key))return null;
    const row={id:'notification-'+Date.now()+'-'+Math.random().toString(36).slice(2,10),type,source,sourceId,dedupeKey:key,message:String(message).slice(0,1000),status:'draft',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),channel:null};
    state.outbox.unshift(row);state.outbox=state.outbox.slice(0,500);persist();return {...row};
  }
  function reconcileShows(shows){
    if(!active)return [];
    if(!Array.isArray(shows))throw new Error('Show list required');
    const changes=[],next={};
    for(const show of shows){
      if(!show||show.id==null)continue;
      const current=compact(show),previous=state.snapshots[current.id];
      next[current.id]=current;
      if(!previous)continue; // existing schedules form the baseline, not an unsolicited alert
      if(JSON.stringify(previous)===JSON.stringify(current))continue;
      const changed=Object.keys(current).filter(k=>current[k]!==previous[k]);
      const cancelled=changed.length===1&&changed[0]==='noShowDates';
      const message=(cancelled?'Show availability updated: ':'Show schedule updated: ')+current.title+' — '+current.date+' '+current.time+'. Changed: '+changed.join(', ')+'.';
      const row=enqueue(cancelled?'show.availability.changed':'show.schedule.changed','shows',current.id,message,JSON.stringify(current));
      if(row)changes.push(row);
    }
    for(const [showId,previous] of Object.entries(state.snapshots)){
      if(next[showId])continue;
      const row=enqueue('show.deleted','shows',showId,'Show removed: '+previous.title+'.',JSON.stringify(previous));
      if(row)changes.push(row);
    }
    state.snapshots=next;persist();return changes;
  }
  function reconcileQueue(showId,queue){
    if(!active)return [];
    if(!queue||!Array.isArray(queue.vip)||!Array.isArray(queue.standard))throw new Error('Queue lanes required');
    const id=String(showId||'default');
    const current={};
    for(const lane of ['vip','standard'])for(const song of queue[lane]){
      if(!song||song.id==null)continue;
      current[String(song.id)]={song:String(song.song||'Song'),artist:String(song.artist||''),viewer:String(song.viewer||''),lane};
    }
    const previous=state.queue[id];
    const rows=[];
    if(previous)for(const [songId,song] of Object.entries(current)){
      if(!previous[songId]){const row=enqueue('song.requested','queue',id+':'+songId,'New song request: '+song.song+' — '+song.artist+' ('+song.viewer+').',JSON.stringify(song));if(row)rows.push(row);}
      else if(previous[songId].lane!==song.lane){const row=enqueue('song.lane.changed','queue',id+':'+songId,'Request moved to '+song.lane.toUpperCase()+': '+song.song+' — '+song.artist+'.',JSON.stringify(song));if(row)rows.push(row);}
    }
    state.queue[id]=current;persist();return rows;
  }
  const SETTINGS_KEY='lirisq-stream-notifications-settings-v1';
  const DEFAULT_SETTINGS={timezone:'',autoPrepare:false,types:{'show.schedule.changed':true,'show.availability.changed':true,'show.deleted':true,'song.requested':true,'song.lane.changed':true,'show.reminder':true}};
  let settings={...DEFAULT_SETTINGS,types:{...DEFAULT_SETTINGS.types}};
  try {const saved=JSON.parse(globalThis.localStorage?.getItem(SETTINGS_KEY)||'null');if(saved&&typeof saved==='object'){settings.autoPrepare=saved.autoPrepare===true;if(typeof saved.timezone==='string')settings.timezone=saved.timezone;for(const type of Object.keys(settings.types))if(typeof saved.types?.[type]==='boolean')settings.types[type]=saved.types[type];}}catch(_){}
  function configuration(){return {...settings,types:{...settings.types}};}
  function configure(patch){
    if(!patch||typeof patch!=='object')throw new Error('Invalid notification settings');
    if(patch.timezone!==undefined){if(typeof patch.timezone!=='string'||!patch.timezone.trim())throw new Error('Select a show time zone');if(patch.timezone.length>80)throw new Error('Invalid time zone');try{new Intl.DateTimeFormat('en-US',{timeZone:patch.timezone});}catch(_){throw new Error('Invalid IANA time zone');}settings.timezone=patch.timezone;}
    if(patch.autoPrepare!==undefined)settings.autoPrepare=patch.autoPrepare===true;
    if(patch.types){for(const [type,enabled] of Object.entries(patch.types)){if(!(type in settings.types)||typeof enabled!=='boolean')throw new Error('Invalid notification type');settings.types[type]=enabled;}}
    try{globalThis.localStorage?.setItem(SETTINGS_KEY,JSON.stringify(settings));}catch(_){}
    return configuration();
  }
  const inFlight=new Set();
  async function sendDiscord(notificationId,discord){
    if(!active)throw new Error('Enable Stream Notifications first');
    if(!discord||typeof discord.sendManual!=='function'||!discord.status?.().active)throw new Error('Enable Discord Integration first');
    const row=state.outbox.find(item=>item.id===notificationId);
    if(!row)throw new Error('Notification not found');
    if(row.status!=='approved'&&row.status!=='failed')throw new Error('Approve the notification before Discord delivery');
    if(inFlight.has(notificationId))throw new Error('Delivery already in progress');
    inFlight.add(notificationId);
    row.status='sending';row.channel='discord';row.updatedAt=new Date().toISOString();persist();
    try {
      await discord.sendManual(row.message);
      row.status='delivered';row.deliveredAt=new Date().toISOString();row.updatedAt=row.deliveredAt;
      row.lastError=null;persist();return {...row};
    } catch(error){
      row.status='failed';row.lastError=String(error?.message||error).slice(0,300);row.updatedAt=new Date().toISOString();persist();throw error;
    } finally {inFlight.delete(notificationId);}
  }
  function update(id,status,channel=null){
    const allowed=['draft','approved','delivered','failed','cancelled'];
    if(!allowed.includes(status))throw new Error('Unknown notification status');
    const row=state.outbox.find(item=>item.id===id);
    if(!row)throw new Error('Notification not found');
    if(row.status==='sending')throw new Error('Cannot change a notification while delivery is in progress');
    if(row.status==='delivered'&&status!=='delivered')throw new Error('Delivered notifications are immutable');
    if(row.status==='cancelled'&&status!=='cancelled')throw new Error('Cancelled notifications cannot be reopened');
    if(status==='delivered'&&row.status!=='approved')throw new Error('Approve a notification before marking it delivered');
    if(status==='approved'&&!['draft','failed','approved'].includes(row.status))throw new Error('Only drafts or failed deliveries may be approved');
    row.status=status;row.channel=channel;row.updatedAt=new Date().toISOString();persist();return {...row};
  }
  return Object.freeze({
    id,name:'Stream Notifications',description,version:'1.0.1',permissions:[],
    factory(){active=true;for(const row of state.outbox)if(row.status==='sending'){row.status='failed';row.lastError='Delivery interrupted; verify Discord before retrying.';}persist();return {stop(){active=false;}};},
    status(){return {active,count:state.outbox.length};},
    configuration,configure,reconcileShows,reconcileQueue,enqueue,update,sendDiscord,reminders,setReminderMinutes,schedulePreview,prepareDue,
    outbox(){return state.outbox.map(row=>({...row}));},
    exportHistory(){return JSON.stringify({schemaVersion:1,exportedAt:new Date().toISOString(),notifications:state.outbox.map(row=>({...row}))},null,2);},
    clearHistory(){if(!active)throw new Error('Enable plugin first');if(inFlight.size)throw new Error('Cannot clear history during delivery');const count=state.outbox.length;state.outbox=[];persist();return count;},
    createDraft(message){if(typeof message!=='string'||!message.trim()||message.length>1000)throw new Error('Enter 1–1000 characters');return enqueue('manual','streamer','manual',message.trim(),Date.now()+':'+Math.random());},
    resetBaseline(shows,queues={}){if(!active)throw new Error('Enable plugin first');state.snapshots=Object.fromEntries((shows||[]).filter(s=>s&&s.id!=null).map(s=>[String(s.id),compact(s)]));state.queue=queues;persist();}
  });
});
