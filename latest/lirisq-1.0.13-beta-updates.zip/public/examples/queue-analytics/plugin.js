/* Queue Analytics v0.5.2: local session song activity and aggregate retention. */
(function (root, factory) {
  const plugin = factory();
  if (typeof module === 'object' && module.exports) module.exports = plugin;
  else root.LirisQQueueAnalyticsPlugin = plugin;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const MAX_TRACKED = 2000;
  const KEY = 'lirisq-analytics-history-v1';
  const CHECKPOINT_KEY = 'lirisq-analytics-checkpoint-v1';
  const allowedDays = [0, 7, 30, 90];
  let retentionDays = 0;
  let sessions = [];
  let checkpointTimer = null;
  function checkpoint() {
    if (!retentionDays || !enabled || startedAt === null) return;
    try {
      localStorage.setItem(CHECKPOINT_KEY, JSON.stringify({
        ...snapshot(), checkpointAt: Date.now()
      }));
    } catch (_) {}
  }
  function removeCheckpoint() {
    try { localStorage.removeItem(CHECKPOINT_KEY); } catch (_) {}
  }
  function recoverCheckpoint() {
    try {
      const saved = JSON.parse(localStorage.getItem(CHECKPOINT_KEY) || 'null');
      if (retentionDays && saved && Number.isFinite(saved.startedAt) &&
          Number.isFinite(saved.checkpointAt) && Number.isFinite(saved.requests) &&
          Number.isFinite(saved.starts) && Number.isFinite(saved.finishes) &&
          saved.startedAt <= saved.checkpointAt && saved.checkpointAt <= Date.now()) {
        sessions.push({
          enabled: false, startedAt: saved.startedAt, endedAt: saved.checkpointAt,
          requests: saved.requests, starts: saved.starts, finishes: saved.finishes,
          averageWaitMs: Number.isFinite(saved.averageWaitMs) ? saved.averageWaitMs : null,
          maxWaitMs: Number.isFinite(saved.maxWaitMs) ? saved.maxWaitMs : null,
          waitSamples: Number.isFinite(saved.waitSamples) ? saved.waitSamples : 0,
          requestsByHour: Array.isArray(saved.requestsByHour) ? saved.requestsByHour.slice(0, 2000) : [],
          lanes: saved.lanes || null, trackedStarts: saved.trackedStarts ?? null,
          trackedFinishes: saved.trackedFinishes ?? null,
          completionRatePercent: saved.completionRatePercent ?? null,
          recovered: true
        });
      }
    } catch (_) {}
    removeCheckpoint();
    prune();
  }
  function prune() {
    const now = Date.now();
    sessions = retentionDays ? sessions.filter(x => x && Number.isFinite(x.endedAt) && x.endedAt <= now && x.endedAt >= now - retentionDays * 86400000).slice(-100) : [];
    try {
      if (retentionDays) localStorage.setItem(KEY, JSON.stringify({ retentionDays, sessions }));
      else localStorage.removeItem(KEY);
    } catch (_) {}
  }
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (saved && allowedDays.includes(saved.retentionDays) && Array.isArray(saved.sessions)) {
      retentionDays = saved.retentionDays;
      sessions = saved.sessions;
    }
    recoverCheckpoint();
  } catch (_) {}

  const queued = new Map();
  const completed = new Set();
  let enabled = false;
  let startedAt = null;
  let requests = 0;
  let starts = 0;
  let finishes = 0;
  let waitTotalMs = 0;
  let waitSamples = 0;
  let maxWaitMs = 0;
  const hours = new Map();
  const lanes = { vip: { requests: 0, starts: 0, finishes: 0 }, standard: { requests: 0, starts: 0, finishes: 0 }, unknown: { requests: 0, starts: 0, finishes: 0 } };
  const startedIds = new Set();
  const finishedIds = new Set();
  const songs = [];
  function laneOf(payload) {
    const value = payload && (payload.queue || payload.lane);
    return value === 'vip' || value === 'standard' ? value : 'unknown';
  }
  function completionStats() {
    const trackedStarts = startedIds.size;
    const trackedFinishes = [...finishedIds].filter(id => startedIds.has(id)).length;
    return { trackedStarts, trackedFinishes, completionRatePercent: trackedStarts ? Math.round(trackedFinishes / trackedStarts * 1000) / 10 : null };
  }
  function idOf(payload) {
    const id = payload && (payload.id || payload.songId);
    return typeof id === 'string' && id.length <= 128 ? id : null;
  }
  function reset() {
    queued.clear(); completed.clear(); hours.clear(); startedIds.clear(); finishedIds.clear(); songs.length = 0;
    for (const lane of Object.values(lanes)) lane.requests = lane.starts = lane.finishes = 0;
    requests = starts = finishes = waitTotalMs = waitSamples = maxWaitMs = 0;
    startedAt = enabled ? Date.now() : null;
  }
  function onQueued(payload) {
    const id = idOf(payload);
    if (!id || queued.has(id) || completed.has(id)) return;
    const now = Date.now();
    queued.set(id, { time: now, started: false, lane: laneOf(payload) });
    lanes[laneOf(payload)].requests++;
    if (queued.size > MAX_TRACKED) queued.delete(queued.keys().next().value);
    requests++;
    const hour = new Date(now).toISOString().slice(0, 13);
    hours.set(hour, (hours.get(hour) || 0) + 1);
    checkpoint();
  }
  function onLaneChanged(payload) {
    const id = idOf(payload);
    const entry = id && queued.get(id);
    if (!entry) return;
    const next = laneOf(payload);
    if (next === entry.lane) return;
    lanes[entry.lane].requests = Math.max(0, lanes[entry.lane].requests - 1);
    lanes[next].requests++;
    if (entry.started) {
      lanes[entry.lane].starts = Math.max(0, lanes[entry.lane].starts - 1);
      lanes[next].starts++;
    }
    entry.lane = next;
    checkpoint();
  }
  function onStarted(payload) {
    const id = idOf(payload);
    if (!id) return;
    const entry = queued.get(id);
    if (entry?.started) return;
    starts++;
    if (startedIds.size < MAX_TRACKED) startedIds.add(id);
    lanes[entry ? entry.lane : laneOf(payload)].starts++;
    if (entry) {
      entry.started = true;
      const wait = Math.max(0, Date.now() - entry.time);
      waitTotalMs += wait; waitSamples++; maxWaitMs = Math.max(maxWaitMs, wait);
    }
    const title = String(payload.title || payload.song || 'Untitled song').slice(0, 300);
    const artist = String(payload.artist || 'Unknown artist').slice(0, 300);
    const row = songs.find(song => song.id === id);
    if (row) { row.startedAt ||= Date.now(); row.title = title; row.artist = artist; row.source = String(payload.source || row.source || 'queue'); }
    else songs.push({ id, title, artist, source: String(payload.source || 'queue'), startedAt: Date.now(), finishedAt: null });
    while (songs.length > 300) songs.shift();
    checkpoint();
  }
  function onFinished(payload) {
    const id = idOf(payload);
    if (!id || completed.has(id)) return;
    completed.add(id);
    finishes++;
    if (finishedIds.size < MAX_TRACKED) finishedIds.add(id);
    lanes[queued.get(id)?.lane || laneOf(payload)].finishes++;
    queued.delete(id);
    const row = songs.find(song => song.id === id);
    if (row) row.finishedAt = Date.now();
    else songs.push({ id, title: String(payload.title || payload.song || 'Untitled song').slice(0, 300), artist: String(payload.artist || 'Unknown artist').slice(0, 300), source: String(payload.source || 'queue'), startedAt: null, finishedAt: Date.now() });
    while (songs.length > 300) songs.shift();
    if (completed.size > MAX_TRACKED) completed.delete(completed.values().next().value);
    checkpoint();
  }
  function snapshot() {
    return { enabled, startedAt, requests, starts, finishes,
      averageWaitMs: waitSamples ? Math.round(waitTotalMs / waitSamples) : null,
      maxWaitMs: waitSamples ? maxWaitMs : null, waitSamples,
      requestsByHour: [...hours].map(([hour, count]) => ({ hour, count })),
      lanes: Object.fromEntries(Object.entries(lanes).map(([name, value]) => [name, { ...value }])),
      songs: songs.map(song => ({ ...song })),
      ...completionStats() };
  }
  return Object.freeze({
    id: 'lirisq.queue-analytics',
    description: 'Measures local queue and playback activity, with optional browser-local session retention and export.',
    version: '0.5.2',
    permissions: ['queue.read'],
    factory(api) {
      enabled = true;
      startedAt = Date.now();
      checkpoint();
      checkpointTimer = setInterval(checkpoint, 30000);
      const unsubscribers = [
        api.on('song.queued', onQueued),
        api.on('song.lane.changed', onLaneChanged),
        api.on('song.started', onStarted),
        api.on('song.finished', onFinished)
      ];
      const current = globalThis.LIRISQ_QUEUE_COMMAND_SERVICE?.nowPlaying?.();
      if (current?.id) onStarted({ id: current.id, title: current.title || current.song, artist: current.artist, source: current.source || (String(current.id).startsWith('mgb-') ? 'mgb' : 'queue') });
      return { stop() {
        for (const off of unsubscribers) off();
        if (checkpointTimer !== null) { clearInterval(checkpointTimer); checkpointTimer = null; }
        if (retentionDays && startedAt !== null) {
          sessions.push({ ...snapshot(), endedAt: Date.now() });
          prune();
        }
        enabled = false;
        removeCheckpoint();
        reset();
      } };
    },
    snapshot,
    songActivity() { return songs.map(song => ({ ...song })); },
    history() { prune(); return sessions.map(x => ({ ...x, requestsByHour: (x.requestsByHour || []).map(y => ({ ...y })) })); },
    retention() { return retentionDays; },
    setRetention(days) {
      if (!allowedDays.includes(days)) throw new Error('Invalid retention');
      retentionDays = days;
      if (!days) removeCheckpoint();
      else checkpoint();
      prune();
      return retentionDays;
    },
    clear() { reset(); sessions = []; removeCheckpoint(); prune(); },
    exportCsv() {
      const columns = ['startedAt','endedAt','recovered','requests','starts','finishes','averageWaitMs','maxWaitMs','waitSamples','trackedStarts','trackedFinishes','completionRatePercent','vipRequests','vipStarts','vipFinishes','standardRequests','standardStarts','standardFinishes','unknownRequests','unknownStarts','unknownFinishes'];
      const quote = value => '"' + String(value == null ? '' : value).replace(/"/g, '""') + '"';
      const rows = sessions.slice().map(item => columns.map(key => quote(/^(vip|standard|unknown)(Requests|Starts|Finishes)$/.test(key) ? item.lanes?.[key.match(/^(vip|standard|unknown)/)[0]]?.[key.match(/(Requests|Starts|Finishes)$/)[0].toLowerCase()] : item[key])).join(','));
      return [columns.join(','), ...rows].join('\\r\\n') + '\\r\\n';
    }
  });
});
