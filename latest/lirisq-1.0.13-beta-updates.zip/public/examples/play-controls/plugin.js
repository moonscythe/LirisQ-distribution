/* Play Controls v0.1.0 — Bot Core playback-control capability provider. */
(function(root,factory){const plugin=factory(root);if(typeof module==='object'&&module.exports)module.exports=plugin;else root.LirisQPlayControlsPlugin=plugin;})(typeof globalThis!=='undefined'?globalThis:this,function(root){
 let active=false,unregister=null;
 const service=()=>{if(!root.LIRISQ_QUEUE_COMMAND_SERVICE)throw Error('Queue service unavailable');return root.LIRISQ_QUEUE_COMMAND_SERVICE;};
 function execute(command){if(!['play','pause','next'].includes(command.name))throw Error('Unsupported Play Controls command');return service().playback(command.name);}
 return Object.freeze({id:'lirisq.play-controls',name:'Play Controls',version:'0.1.0',permissions:['playback.control'],description:'Lets authorized chat commands start, pause, or advance the LirisQ queue player.',factory(){active=true;unregister=root.LirisQBotCapabilityRegistry.register('lirisq.play-controls','playback.control',{execute});return{stop(){active=false;unregister?.();unregister=null;}};},status(){return{active,available:active&&!!root.LIRISQ_QUEUE_COMMAND_SERVICE};}});
});
