/* Show Calendar Export v1.0.0: standards-oriented local ICS files; no calendar account access. */
(function (root, factory) {
  const plugin = factory();
  if (typeof module === 'object' && module.exports) module.exports = plugin;
  else root.LirisQShowCalendarPlugin = plugin;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  let active = false;
  const id = 'lirisq.show-calendar-export';
  const description = 'Export LirisQ shows to portable .ics calendar files, with recurring occurrence selection, time-zone-aware event times, estimated duration, reminders, cancellation exclusions and multi-event downloads. No calendar login, account permissions or automatic synchronization.';
  function escapeText(value) { return String(value ?? '').replace(/\\/g,'\\\\').replace(/\r\n|\r|\n/g,'\\n').replace(/[,;]/g, m=>'\\'+m); }
  function validateZone(zone) {
    if (typeof zone !== 'string' || !zone || zone.length>80 || !/^[A-Za-z0-9_+./-]+$/.test(zone)) throw new Error('Enter a valid IANA time zone');
    try { new Intl.DateTimeFormat('en-US',{timeZone:zone}); } catch (_) { throw new Error('Enter a valid IANA time zone'); }
    return zone;
  }
  function parts(date,time) {
    if(!/^\d{4}-\d{2}-\d{2}$/.test(date||'') || !/^\d{2}:\d{2}$/.test(time||'')) throw new Error('Show date and time are required');
    const [year,month,day]=date.split('-').map(Number),[hour,minute]=time.split(':').map(Number);
    const d=new Date(Date.UTC(year,month-1,day,hour,minute));
    if(d.getUTCFullYear()!==year || d.getUTCMonth()+1!==month || d.getUTCDate()!==day || hour>23 || minute>59)throw new Error('Invalid show date or time');
    return {year,month,day,hour,minute};
  }
  function zoneParts(instant,zone) {
    return Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(instant).filter(p=>p.type!=='literal').map(p=>[p.type,Number(p.value)]));
  }
  function instantFor(date,time,zone) {
    validateZone(zone);
    const p=parts(date,time), target=Date.UTC(p.year,p.month-1,p.day,p.hour,p.minute);
    let guess=target;
    for(let i=0;i<5;i++){
      const z=zoneParts(new Date(guess),zone);
      const delta=target-Date.UTC(z.year,z.month-1,z.day,z.hour,z.minute);
      if(!delta)break;
      guess+=delta;
    }
    const z=zoneParts(new Date(guess),zone);
    if(['year','month','day','hour','minute'].some(k=>z[k]!==p[k]))throw new Error('Show time does not exist in the selected time zone (DST change)');
    return new Date(guess);
  }
  function utcStamp(d) { return d.toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,''); }
  function fold(line) {
    const bytes=new TextEncoder().encode(line);
    if(bytes.length<=75)return line;
    let result='',count=0;
    for(const char of line){
      const size=new TextEncoder().encode(char).length;
      if(count+size>75){result+='\r\n ';count=1;}
      result+=char;count+=size;
    }
    return result;
  }
  function makeEvent(show,date,zone,duration,reminderMinutes) {
    if(!show||typeof show!=='object')throw new Error('Select a show');
    if(!Number.isInteger(duration)||duration<15||duration>720)throw new Error('Duration must be 15–720 minutes');
    if(!Number.isInteger(reminderMinutes)||reminderMinutes<0||reminderMinutes>10080)throw new Error('Reminder must be 0–10080 minutes');
    const start=instantFor(date,show.time,zone);
    const end=new Date(start.getTime()+duration*60000);
    const safeId=encodeURIComponent(String(show.id||show.title||'show')).replace(/%/g,'-');
    const lines=['BEGIN:VEVENT','UID:'+safeId+'-'+date.replace(/-/g,'')+'@lirisq.local',
      'DTSTAMP:'+utcStamp(new Date()),'DTSTART:'+utcStamp(start),'DTEND:'+utcStamp(end),
      'SUMMARY:'+escapeText(show.title||'LirisQ show'),
      'DESCRIPTION:'+escapeText(show.notes||''),
      'X-LIRISQ-SHOW-TIMEZONE:'+zone];
    if(reminderMinutes>0)lines.push('BEGIN:VALARM','ACTION:DISPLAY','DESCRIPTION:'+escapeText('Upcoming: '+(show.title||'LirisQ show')),'TRIGGER:-PT'+reminderMinutes+'M','END:VALARM');
    lines.push('END:VEVENT');
    return lines;
  }
  function calendar(show,dates,zone,duration=120,reminderMinutes=30) {
    if(!active)throw new Error('Enable Show Calendar Export first');
    validateZone(zone);
    if(!Array.isArray(dates)||!dates.length||dates.length>100||new Set(dates).size!==dates.length)throw new Error('Choose 1–100 unique show occurrences');
    const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//LirisQ//Show Calendar Export 1.0.0//EN','CALSCALE:GREGORIAN','METHOD:PUBLISH','X-WR-CALNAME:'+escapeText((show?.title||'LirisQ')+' shows')];
    for(const date of dates) {
      if(Array.isArray(show.noShowDates)&&show.noShowDates.includes(date))throw new Error('Cannot export a No Show date');
      lines.push(...makeEvent(show,date,zone,duration,reminderMinutes));
    }
    lines.push('END:VCALENDAR');
    return lines.map(fold).join('\r\n')+'\r\n';
  }
  function occurrences(show,from=new Date(),limit=12,zone=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC') {
    if(!show)return [];
    const start=parts(show.date,show.time),startUtc=Date.UTC(start.year,start.month-1,start.day);
    if(!Number.isInteger(limit)||limit<1||limit>100)throw new Error('Invalid occurrence count');
    const startDay=new Date(start.year,start.month-1,start.day);
    const weekdays=Array.isArray(show.repeatDays)&&show.repeatDays.length?show.repeatDays.map(Number):[startDay.getDay()];
    const excluded=new Set(show.noShowDates||[]),results=[];
    for(let i=0;i<730&&results.length<limit;i++){
      const day=new Date(from.getFullYear(),from.getMonth(),from.getDate()+i);
      const date=day.getFullYear()+'-'+String(day.getMonth()+1).padStart(2,'0')+'-'+String(day.getDate()).padStart(2,'0');
      const utc=Date.UTC(day.getFullYear(),day.getMonth(),day.getDate());
      if(utc<startUtc||excluded.has(date))continue;
      const weeks=Math.floor((utc-startUtc)/604800000);
      const occurs=(show.recurrence||'once')==='once'?date===show.date:
        show.recurrence==='weekly'?weekdays.includes(day.getDay()):
        show.recurrence==='biweekly'?weekdays.includes(day.getDay())&&weeks%2===0:
        show.recurrence==='monthly'?day.getDate()===start.day:false;
      if(!occurs)continue;
      try{if(instantFor(date,show.time,zone).getTime()<from.getTime())continue;}catch(_){continue;}
      results.push(date);
    }
    return results;
  }
  return Object.freeze({
    id,name:'Calendar Export',description,version:'1.0.1',permissions:[],
    factory(){active=true;return {stop(){active=false;}};},status(){return {active};},
    occurrences,instantFor,exportEvent(show,date,zone,duration=120,reminderMinutes=30){return calendar(show,[date],zone,duration,reminderMinutes);},
    exportEvents:calendar
  });
});
