/* LirisQ chatbot/queue router v0.3.4.
 * Routes normalized platform chat to Bot Core. Platform transport stays with adapters.
 */
(function(root,factory){const plugin=factory(root);if(typeof module==='object'&&module.exports)module.exports=plugin;else root.LirisQChatbotQueueRouterPlugin=plugin;})(typeof globalThis!=='undefined'?globalThis:this,function(root){
 let active=false,reply=null;const seen=new Set();
 const commandText=event=>String(event?.payload?.text||event?.payload?.message||'').trim();
 const actorFor=event=>({id:String(event.payload?.viewerId||event.payload?.userId||event.payload?.username||event.payload?.author||'').trim(),channelId:String(event.payload?.channelId||event.payload?.channel||'').trim(),platform:event.platform,role:['viewer','moderator','broadcaster'].includes(event.payload?.role)?event.payload.role:'viewer',verified:event.verified===true});
 function replyText(result){
  if(result.message)return result.message;
  const data=result.data||{};
  if(result.command?.name==='queue')return `VIP: ${(data.vip||[]).length} · Standard: ${(data.standard||[]).length}`;
  if(result.command?.name==='vip')return `VIP Queue: ${(data.vip||[]).length} song${(data.vip||[]).length===1?'':'s'} waiting.`;
  if(result.command?.name==='nowplaying')return data.nowPlaying?`Now playing: ${data.nowPlaying.song} — ${data.nowPlaying.artist}`:'Nothing is playing right now.';
  if(result.command?.name==='rules'){const details=`Queue mode: ${String(data.mode||'queue').replace(/\b\w/g,c=>c.toUpperCase())} · VIP plays first.`;return data.text?`${data.text} ${details}`:details;}
  if(result.command?.name==='request')return `Your request is pending approval. ID: ${data.requestId}.`;
  if(result.command?.name==='myrequest'){const requests=data.requests||[];return requests.length?requests.map(request=>`${request.requestId}: ${request.song} — ${request.artist}`).join(' · '):'You do not have a queued request.';}
  if(result.command?.name==='remove')return 'Your request was removed.';
  if(result.command?.name==='approval'){if(data.pending)return data.pending.length?data.pending.map(request=>`${request.id}: ${request.song} — ${request.artist}`).join(' · '):'There are no pending requests.';return `Request ${data.requestId} approved into the ${data.queue==='vip'?'VIP':'Standard'} Queue.`;}
  if(result.command?.name==='deny')return `Request ${data.requestId} was denied.`;
  if(result.command?.name==='play')return 'Playback started.';
  if(result.command?.name==='pause')return 'Playback paused.';
  if(result.command?.name==='next')return data.advanced?'Skipped to the next song.':'There is no next song.';
  if(result.command?.name==='promote')return `Request ${data.requestId} moved to the VIP Queue.`;
  if(result.command?.name==='demote')return `Request ${data.requestId} moved to the Standard Queue.`;
  return 'Command completed.';
 }
 function factory(options={}){active=true;reply=typeof options.reply==='function'?options.reply:null;return{stop(){active=false;reply=null;}};}
 async function handle(event){
  if(!active)throw Error('Enable chatbot queue router first');
  if(!event||event.schema!=='lirisq.platform-event/v1')throw Error('Normalized platform event required');
  const key=event.platform+':'+event.externalEventId;if(seen.has(key))return{handled:false,reason:'duplicate'};seen.add(key);if(seen.size>1000)seen.delete(seen.values().next().value);
  if(!['chat.command','chat.message'].includes(event.type))return{handled:false,reason:'not-chat'};
  const text=commandText(event);if(!text.startsWith('!'))return{handled:false,reason:'not-command'};
  const core=root.LirisQBotCorePlugin;if(!core?.status?.().active)return{handled:false,reason:'bot-core-unavailable'};
  const result=await core.dispatch({command:text,actor:actorFor(event),platform:event.platform,event});
  const message=replyText(result);const delivery={platform:event.platform,event,command:result.command||core.normalizeCommand(text),result,message};
  if(typeof reply==='function')await reply(delivery);
  if(typeof root.LIRISQ_PLATFORM_REPLY==='function')await root.LIRISQ_PLATFORM_REPLY(delivery);
  return{handled:true,action:`command:${delivery.command?.name||'unknown'}`,command:delivery.command,result,message};
 }
 return Object.freeze({id:'lirisq.chatbot-queue-router',name:'Chatbot Queue Router',version:'0.3.1',permissions:[],description:'Dispatches normalized platform chat commands through Bot Core and returns a platform-neutral reply.',factory,handle,status:()=>({active}),capabilities:()=>({queueRequests:true,platformAwareReplies:true,automaticPosting:false,commandDispatch:true})});
});
