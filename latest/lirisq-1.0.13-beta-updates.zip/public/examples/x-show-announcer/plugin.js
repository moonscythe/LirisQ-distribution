/* X Show Announcer v1.0.0: local drafts and user-confirmed composer only. */
(function (root, factory) {
  const plugin = factory();
  if (typeof module === 'object' && module.exports) module.exports = plugin;
  else root.LirisQXShowAnnouncerPlugin = plugin;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const id = 'lirisq.x-show-announcer';
  const description = 'Create, preview, copy and manually publish X announcements for LirisQ shows, including recurring dates, time zones, viewer-local time links, reusable templates and show links. No X account access or automatic posting.';
  const KEY = 'lirisq-x-show-template-v1', LINK_KEY = 'lirisq-x-show-link-v1', ZONE_KEY = 'lirisq-x-show-timezone-v1';
  const DEFAULT = 'Join me for {title} on {date} at {time}! {link}';
  const PRESETS = Object.freeze({ upcoming: DEFAULT, reminder: 'Reminder: {title} is coming up on {date} at {time}! {link}', starting: 'We are going live with {title} now! Join us: {link}' });
  let active = false;
  function stored(key, fallback) { try { return globalThis.localStorage?.getItem(key) || fallback; } catch (_) { return fallback; } }
  function persist(key, value) { try { globalThis.localStorage?.setItem(key, value); } catch (_) {} }
  let template = stored(KEY, DEFAULT), defaultLink = stored(LINK_KEY, '');
  let timezone = stored(ZONE_KEY, Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC');
  function zoneValid(zone) {
    if (typeof zone !== 'string' || !zone || zone.length > 80 || !/^[A-Za-z0-9_+./-]+$/.test(zone)) throw new Error('Enter a valid IANA time zone');
    try { new Intl.DateTimeFormat('en-US', { timeZone: zone }); } catch (_) { throw new Error('Enter a valid IANA time zone'); }
    return zone;
  }
  function setTimezone(zone) { timezone = zoneValid(zone); persist(ZONE_KEY, timezone); return timezone; }
  try { zoneValid(timezone); } catch (_) { timezone = 'UTC'; }
  function validateTemplate(value) {
    if (typeof value !== 'string' || !value.trim() || value.length > 280) throw new Error('Template must be 1–280 characters');
    if ((value.match(/\{[^{}]*\}/g) || []).some(token => !['{title}','{date}','{time}','{link}','{viewerTime}'].includes(token))) throw new Error('Unknown template placeholder');
    return value;
  }
  function setTemplate(value) { template = validateTemplate(value); persist(KEY, template); return template; }
  try { validateTemplate(template); } catch (_) { template = DEFAULT; }
  function setDefaultLink(value) {
    if (typeof value !== 'string' || (value && (!/^https?:\/\/\S+$/i.test(value) || value.length > 300))) throw new Error('Show link must be an HTTP(S) URL of up to 300 characters');
    defaultLink = value; persist(LINK_KEY, value); return value;
  }
  function dateParts(date, time = '00:00') {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date || '') || !/^\d{2}:\d{2}$/.test(time || '')) throw new Error('Invalid show date or time');
    const [year, month, day] = date.split('-').map(Number), [hour, minute] = time.split(':').map(Number);
    const d = new Date(Date.UTC(year, month - 1, day, hour, minute));
    if (d.getUTCFullYear() !== year || d.getUTCMonth() + 1 !== month || d.getUTCDate() !== day || hour > 23 || minute > 59) throw new Error('Invalid show date or time');
    return { year, month, day, hour, minute };
  }
  function keyOf(date) { return date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2,'0') + '-' + String(date.getDate()).padStart(2,'0'); }
  function zonedParts(instant, zone) {
    const parts = new Intl.DateTimeFormat('en-US', { timeZone: zone, year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23' }).formatToParts(instant);
    const v = Object.fromEntries(parts.filter(p => p.type !== 'literal').map(p => [p.type, Number(p.value)]));
    return v;
  }
  function instantFor(show, zone = timezone) {
    zoneValid(zone);
    const target = dateParts(show.date, show.time);
    const wall = Date.UTC(target.year,target.month-1,target.day,target.hour,target.minute);
    let guess = wall;
    for (let i=0;i<5;i++) {
      const p = zonedParts(new Date(guess), zone);
      const actual = Date.UTC(p.year,p.month-1,p.day,p.hour,p.minute);
      const diff = wall - actual;
      if (!diff) break;
      guess += diff;
    }
    const actual = zonedParts(new Date(guess),zone);
    if (['year','month','day','hour','minute'].some(k => actual[k] !== target[k])) throw new Error('This local time does not exist in the selected time zone (DST change)');
    return new Date(guess);
  }
  function timeDetails(show, zone = timezone) {
    const instant = instantFor(show, zone);
    const label = new Intl.DateTimeFormat('en-US', {timeZone:zone,timeZoneName:'short'}).formatToParts(instant).find(p=>p.type==='timeZoneName')?.value || zone;
    const readable = new Intl.DateTimeFormat('en-US', {timeZone:zone,year:'numeric',month:'short',day:'numeric',hour:'numeric',minute:'2-digit',timeZoneName:'short'}).format(instant);
    const viewerLink = 'https://www.timeanddate.com/worldclock/converter.html?iso=' + instant.toISOString().slice(0,16).replace(/[-:]/g,'') + '00';
    return { instant: instant.toISOString(), label, readable, zone, viewerLink };
  }
  function occurrences(show, from = new Date(), limit = 8, zone = timezone) {
    if (!show) return [];
    const start = dateParts(show.date, show.time || '00:00');
    if (!Number.isInteger(limit) || limit < 1 || limit > 100) throw new Error('Invalid occurrence limit');
    const startUtc = Date.UTC(start.year,start.month-1,start.day);
    const startDay = new Date(start.year,start.month-1,start.day);
    const excluded = new Set(Array.isArray(show.noShowDates) ? show.noShowDates : []);
    const days = Array.isArray(show.repeatDays) && show.repeatDays.length ? show.repeatDays.map(Number) : [startDay.getDay()];
    const output = [];
    for (let offset=0;offset<730 && output.length<limit;offset++) {
      const day = new Date(from.getFullYear(),from.getMonth(),from.getDate()+offset);
      const key = keyOf(day), dayUtc = Date.UTC(day.getFullYear(),day.getMonth(),day.getDate());
      if (dayUtc < startUtc || excluded.has(key)) continue;
      const weeks = Math.floor((dayUtc-startUtc)/604800000);
      const match = (show.recurrence || 'once') === 'once' ? key === show.date :
        show.recurrence === 'weekly' ? days.includes(day.getDay()) :
        show.recurrence === 'biweekly' ? days.includes(day.getDay()) && weeks % 2 === 0 :
        show.recurrence === 'monthly' ? day.getDate() === start.day : false;
      if (!match) continue;
      try { if (instantFor({date:key,time:show.time},zone).getTime() < from.getTime()) continue; } catch (_) { continue; }
      output.push(key);
    }
    return output;
  }
  function compose(show, link = defaultLink, chosenTemplate = template) {
    if (!show || typeof show !== 'object') throw new Error('Choose a show');
    validateTemplate(chosenTemplate);
    const details = timeDetails(show);
    const url = link || '';
    if (url && (!/^https?:\/\/\S+$/i.test(url) || url.length > 300)) throw new Error('Invalid show link');
    const values = { title: String(show.title || 'Upcoming show').replace(/[\r\n]/g,' ').slice(0,100),date:show.date,time:show.time + ' ' + details.label,link:url,viewerTime:details.viewerLink };
    return chosenTemplate.replace(/\{(title|date|time|link|viewerTime)\}/g,(_,k)=>values[k]).replace(/\s+/g,' ').trim();
  }
  function characterCount(value) { return [...String(value)].length; }
  function validateDraft(value) {
    if (typeof value !== 'string' || !value.trim() || characterCount(value)>280) throw new Error('Post must be 1–280 characters');
    return value;
  }
  return Object.freeze({
    id, name:'X Show Announcer', description, version:'1.0.0', permissions:[],
    factory() { active=true; return {stop(){active=false;}}; },
    status(){return {active,mode:'user-confirmed-x-composer'};},
    template(){return template;},setTemplate,resetTemplate(){return setTemplate(DEFAULT);},
    defaultLink(){return defaultLink;},setDefaultLink,timezone(){return timezone;},setTimezone,
    showTime(show){return show.time + ' ' + timeDetails(show).label;},timeDetails,instantFor,
    presetNames(){return Object.keys(PRESETS);},presetTemplate(name){if(!Object.prototype.hasOwnProperty.call(PRESETS,name))throw new Error('Unknown preset');return PRESETS[name];},
    occurrences,compose,characterCount,validateDraft,
    intentUrl(message){if(!active)throw new Error('Enable the X Show Announcer plugin first');return 'https://twitter.com/intent/tweet?text='+encodeURIComponent(validateDraft(message));}
  });
});
