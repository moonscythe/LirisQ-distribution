/* Optional Song History plugin. Shares Queue Analytics' current-session song ledger when available. */
(function (root, factory) {
  const plugin = factory();
  if (typeof module === 'object' && module.exports) module.exports = plugin;
  else root.LirisQSongHistoryPlugin = plugin;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const MAX_ENTRIES = 100;
  const entries = [];
  const seen = new Set();
  function record(event, payload) {
    if (!payload || typeof payload !== 'object') return;
    const id = String(payload.id || payload.songId || '').slice(0, 128);
    if (!id) return;
    const key = event + ':' + id;
    if (seen.has(key)) return;
    seen.add(key);
    entries.push(Object.freeze({
      event, songId: id,
      title: String(payload.title || '').slice(0, 300),
      artist: String(payload.artist || '').slice(0, 300),
      recordedAt: new Date().toISOString()
    }));
    while (entries.length > MAX_ENTRIES) {
      const removed = entries.shift();
      seen.delete(removed.event + ':' + removed.songId);
    }
  }
  return Object.freeze({
    id: 'lirisq.song-history',
    description: 'Keeps a local in-memory list of up to 100 started and finished songs for this session.',
    version: '0.1.1',
    permissions: ['queue.read'],
    factory(api) {
      const unsubscribers = [
        api.on('song.started', payload => record('started', payload)),
        api.on('song.finished', payload => record('finished', payload))
      ];
      return {
        stop() { for (const unsubscribe of unsubscribers) unsubscribe(); },
      };
    },
    history() {
      const analytics = globalThis.LirisQQueueAnalyticsPlugin;
      const activity = analytics?.status?.().active ? analytics.songActivity?.() : null;
      if (Array.isArray(activity)) return activity.flatMap(song => {
        const common = { songId: song.id, title: song.title, artist: song.artist, source: song.source || 'queue' };
        return [song.startedAt && { ...common, event: 'started', recordedAt: new Date(song.startedAt).toISOString() }, song.finishedAt && { ...common, event: 'finished', recordedAt: new Date(song.finishedAt).toISOString() }].filter(Boolean);
      });
      return entries.map(entry => ({ ...entry }));
    },
    clear() { entries.length = 0; seen.clear(); }
  });
});
