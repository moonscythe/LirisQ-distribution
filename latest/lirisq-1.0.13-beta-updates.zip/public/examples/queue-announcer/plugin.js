/* Trusted Queue Announcer example plugin; install/activation is separate. */
(function (root, factory) {
  const plugin = factory();
  if (typeof module === 'object' && module.exports) module.exports = plugin;
  else root.LirisQQueueAnnouncerPlugin = plugin;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  return Object.freeze({
    id: 'lirisq.queue-announcer',
    description: 'Logs the current song whenever playback starts. It does not post messages or change the queue.',
    version: '0.1.0',
    permissions: ['queue.read'],
    factory(api) {
      let off;
      return {
        start() {
          off = api.on('song.started', song => {
            const title = typeof song?.title === 'string' ? song.title : 'Unknown song';
            api.log('Now playing: ' + title);
          });
        },
        stop() { if (off) off(); }
      };
    }
  });
});
